#!/data/data/com.termux/files/usr/bin/bash

VPS_HOST="root@43.156.142.66"
VPS_DIR="/root/sunset"

echo "[1/3] Upload token baru ke VPS..."
scp -O refresh-tokens.json "${VPS_HOST}:${VPS_DIR}/token_baru.json"

if [ $? -ne 0 ]; then
  echo "Upload gagal."
  exit 1
fi

echo "[2/3] Merge token di VPS..."
ssh "${VPS_HOST}" "cd ${VPS_DIR} && python3 merge_tokens.py"

if [ $? -ne 0 ]; then
  echo "Merge gagal."
  exit 1
fi

echo "[3/3] Restart bot di VPS..."
ssh "${VPS_HOST}" "systemctl restart bot-esim.service"

echo "Selesai. Token baru sudah masuk ke VPS."