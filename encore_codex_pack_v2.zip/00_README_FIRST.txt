ENCORE-STYLE CODEx PACK V2 (IMPROVED)

Includes:
- Full phase prompts (1–12)
- API compatibility (balance, history)
- Progress model (stage, label, etc)
- Failure taxonomy
- Duplicate handling
- Docs templates (API, deployment, runbook)
- Setup instructions

Use:
1. Extract
2. Setup repo
3. Run phase prompts sequentially
