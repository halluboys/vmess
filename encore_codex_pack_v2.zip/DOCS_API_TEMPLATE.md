# API Documentation

## Endpoints
Describe:
- request
- response
- errors

## Notes
- never expose sensitive data
- always structured responses
