PAKET PROMPT CODEX - PROJECT ENCORE-STYLE NON-GCP

Tujuan:
Paket ini berisi:
1. prompt global untuk Codex
2. AGENTS.md starter
3. README.md starter
4. .env.example starter
5. docker-compose.yml starter
6. Phase 1 sampai Phase 12 prompt
7. review prompts
8. patch prompts
9. workflow step-by-step dari nol sampai jadi platform production-grade

Cara pakai:
- buat repo kosong
- copy file starter ke repo
- jalankan prompt phase satu per satu ke Codex
- jangan skip urutan
- setelah tiap phase, jalankan review prompt

Urutan kerja:
01. buat repo dan file starter
02. jalankan phase 1
03. review hasil phase 1
04. lanjut phase 2
...
12. lanjut phase 12
13. lakukan hardening terakhir
