# AGENTS.md

## Project Overview
This repository contains a distributed automation backend platform inspired by ENCOREPVT-style systems, but designed to be:
- cloud-agnostic
- modular
- maintainable
- production-oriented

## Core Architecture
Services:
- api_gateway -> HTTP interface (FastAPI)
- job_orchestrator -> queue consumer and lifecycle manager
- worker -> execution engine (provider-based)
- telegram_bot -> frontend client only

Libraries:
- contracts -> shared schemas
- storage -> PostgreSQL access
- queue -> Redis abstraction
- config -> environment validation
- logging -> structured logs

## Engineering Rules

### 1. Separation of Concerns
- API layer must NOT contain business logic
- Worker must NOT access API layer
- Queue logic must NOT be embedded in route handlers
- Telegram bot must ONLY call API and never DB or Redis

### 2. File Size and Modularity
- Avoid files larger than 400-500 lines
- Split logic into modules/services
- Prefer composition over monolith functions

### 3. State Management
- Persistent state -> PostgreSQL
- Transient state -> Redis
- NO hidden global state
- NO in-memory critical state in production logic

### 4. Contracts
- All request/response models must live in libs/contracts
- Do NOT duplicate schemas across services

### 5. Config System
- All configs must come from environment variables
- Must be validated at startup
- App must fail fast on invalid config

### 6. Logging
- Use structured JSON logging
- Always include:
  - service_name
  - job_id if available
  - stage
  - error_code
- Never log:
  - passwords
  - TOTP secrets
  - raw tokens

### 7. Error Handling
- Use structured errors
- Do NOT expose stack traces in API responses
- Always map internal errors to safe public responses

### 8. Security Rules
- No plaintext credential storage
- Sensitive fields must be encrypted or separated
- No secrets in logs
- API must sanitize all responses

### 9. Queue and Job Processing
- Jobs must follow lifecycle:
  - queued -> running -> success/failed
- Must support:
  - retry
  - timeout
  - failure classification
- Worker must be idempotent

### 10. Provider Architecture
- Use abstraction:
  - BaseExecutionProvider
- Providers must implement:
  - prepare()
  - execute()
  - collect_result()
  - cleanup()

### 11. Testing
- Every module should be testable
- Add tests for:
  - API
  - storage
  - queue logic
- Avoid untestable code

### 12. Docker Rules
- Use slim base images
- No root user in containers
- Deterministic builds

## Commands
### Run services
docker compose up --build

### Run API locally
uvicorn services.api_gateway.main:app --reload

### Run tests
pytest -q

## Folder Structure Expected
services/
  api_gateway/
  job_orchestrator/
  worker/
  telegram_bot/

libs/
  contracts/
  storage/
  queue/
  config/
  logging/

infra/
  docker/

tests/
docs/

## Development Philosophy
- Clarity > cleverness
- Explicit flow > hidden behavior
- Maintainability > shortcuts
- Production mindset from day 1

## What NOT to do
- Do not introduce monolithic god files
- Do not mix layers (API, DB, queue)
- Do not bypass contracts
- Do not add unnecessary abstractions
- Do not implement policy-violating logic

## Goal
Build a system that is:
- scalable
- debuggable
- observable
- safe
- easy to extend
