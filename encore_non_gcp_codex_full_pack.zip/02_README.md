# Automation Backend Platform (ENCORE-style, non-GCP)

## Overview
This project is a distributed automation backend platform inspired by ENCOREPVT architecture, designed to run without cloud vendor lock-in.

It provides:
- API for submitting jobs
- Queue-based job processing
- Worker-based execution engine
- Result retrieval
- Telegram bot interface (optional)

## Architecture
Client (Telegram/API)
        ->
   API Gateway
        ->
   PostgreSQL (state)
        ->
      Redis (queue)
        ->
 Job Orchestrator
        ->
      Worker
        ->
   Execution Provider

## Core Features
- Async job processing
- Queue with priority
- Worker execution model
- Structured logging
- Retry and timeout handling
- Result storage
- Health and metrics endpoints

## Tech Stack
- FastAPI
- PostgreSQL
- Redis
- Docker Compose
- Pydantic
- SQLAlchemy or SQLModel

## API Endpoints
GET /api/health
POST /api/jobs
GET /api/jobs/{job_id}
GET /api/result?email=...
GET /api/queue

## Project Structure
services/
  api_gateway/
  job_orchestrator/
  worker/
  telegram_bot/
libs/
  contracts/
  storage/
  queue/
  config/
  logging/
infra/
  docker/
tests/
docs/

## Getting Started
1. cp .env.example .env
2. docker compose up --build

## Environment Variables
APP_ENV=development
API_KEY=your-api-key
POSTGRES_URL=postgresql://user:pass@db:5432/app
REDIS_URL=redis://redis:6379
ENCRYPTION_KEY=base64_key_here

## Development Workflow
1. Follow phase-based development
2. Keep services modular
3. Do not mix concerns
4. Write tests for new features
5. Validate config before running
