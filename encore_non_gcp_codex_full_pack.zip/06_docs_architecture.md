# Architecture

## Overview
This project is a distributed automation backend platform with four main layers:
1. API Gateway
2. Job Orchestrator
3. Worker
4. Optional Telegram Bot frontend

Persistent state lives in PostgreSQL.
Transient queue/state coordination lives in Redis.

## Components

### API Gateway
Responsibilities:
- validate requests
- authenticate API key
- create jobs
- expose job/result/queue endpoints

### Job Orchestrator
Responsibilities:
- consume queued jobs
- manage lifecycle
- assign work to worker layer
- handle retries and timeouts

### Worker
Responsibilities:
- execute jobs
- use provider abstraction
- collect results
- save artifacts

### Contracts
Shared schemas/models live in libs/contracts.

### Storage
Database access code lives in libs/storage.

### Queue
Redis queue code lives in libs/queue.

## Job Lifecycle
- queued
- running
- success
- failed

## Design Principles
- no business logic in route handlers
- no direct DB access from bot frontend
- no hidden in-memory production state
- explicit contracts and structured errors
