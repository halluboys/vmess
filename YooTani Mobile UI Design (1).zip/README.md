
  # YooTani Mobile UI Design

  This is a code bundle for YooTani Mobile UI Design. The original project is available at https://www.figma.com/design/zMrl8j6PxqN1vxRkMN8p9I/YooTani-Mobile-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  