import React, { useState, useRef, useCallback } from "react";
import { toPng } from "html-to-image";
import JSZip from "jszip";
import { saveAs } from "file-saver";
import { SOURCE_FILES } from "./components/yootani/sourceBundle";
import { ActivationScreen } from "./components/yootani/screens/ActivationScreen";
import { SetupProfileScreen } from "./components/yootani/screens/SetupProfileScreen";
import { DashboardScreen } from "./components/yootani/screens/DashboardScreen";
import { DataTanamScreen } from "./components/yootani/screens/DataTanamScreen";
import { DetailTanamScreen } from "./components/yootani/screens/DetailTanamScreen";
import { BiayaProduksiScreen } from "./components/yootani/screens/BiayaProduksiScreen";
import { JadwalKegiatanScreen } from "./components/yootani/screens/JadwalKegiatanScreen";
import { HasilPanenScreen } from "./components/yootani/screens/HasilPanenScreen";
import { LaporanScreen } from "./components/yootani/screens/LaporanScreen";
import { BackupRestoreScreen } from "./components/yootani/screens/BackupRestoreScreen";
import { SettingsScreen } from "./components/yootani/screens/SettingsScreen";
import { DataLahanScreen } from "./components/yootani/screens/DataLahanScreen";
import { DataTanamanScreen } from "./components/yootani/screens/DataTanamanScreen";
import { HistoryMusimScreen } from "./components/yootani/screens/HistoryMusimScreen";
import { InfoLisensiScreen } from "./components/yootani/screens/InfoLisensiScreen";
import { C } from "./components/yootani/shared";

// ─── Screen map ──────────────────────────────────────────────────────────────
type ScreenKey =
  | "activation" | "setup-profile" | "dashboard" | "data-tanam"
  | "detail-tanam" | "biaya" | "jadwal" | "panen" | "laporan"
  | "backup" | "settings" | "data-lahan" | "data-tanaman"
  | "history" | "lisensi" | "profil" | "notifikasi" | "tentang";

// All 15 screens for export
const allScreens: { key: ScreenKey; filename: string }[] = [
  { key: "activation",    filename: "01_YooTani_Aktivasi-Lisensi" },
  { key: "setup-profile", filename: "02_YooTani_Setup-Profil" },
  { key: "dashboard",     filename: "03_YooTani_Dashboard" },
  { key: "data-tanam",    filename: "04_YooTani_Data-Tanam" },
  { key: "detail-tanam",  filename: "05_YooTani_Detail-Tanam" },
  { key: "biaya",         filename: "06_YooTani_Biaya-Produksi" },
  { key: "jadwal",        filename: "07_YooTani_Jadwal-Kegiatan" },
  { key: "panen",         filename: "08_YooTani_Hasil-Panen" },
  { key: "laporan",       filename: "09_YooTani_Laporan-Musim" },
  { key: "backup",        filename: "10_YooTani_Backup-Restore" },
  { key: "settings",      filename: "11_YooTani_Pengaturan" },
  { key: "data-lahan",    filename: "12_YooTani_Data-Lahan" },
  { key: "data-tanaman",  filename: "13_YooTani_Data-Tanaman" },
  { key: "history",       filename: "14_YooTani_History-Musim" },
  { key: "lisensi",       filename: "15_YooTani_Info-Lisensi" },
];

const screenGroups = [
  {
    group: "Onboarding",
    color: "#2D7A3A",
    screens: [
      { key: "activation", label: "1. Aktivasi Lisensi", emoji: "🔑" },
      { key: "setup-profile", label: "2. Data Petani", emoji: "👤" },
    ],
  },
  {
    group: "Utama",
    color: "#1565C0",
    screens: [
      { key: "dashboard", label: "3. Dashboard", emoji: "🏠" },
      { key: "data-tanam", label: "4. Data Tanam", emoji: "🌱" },
      { key: "detail-tanam", label: "5. Detail Tanam", emoji: "📋" },
    ],
  },
  {
    group: "Pencatatan",
    color: "#E8820A",
    screens: [
      { key: "biaya", label: "6. Biaya Produksi", emoji: "💰" },
      { key: "jadwal", label: "7. Jadwal Kegiatan", emoji: "📅" },
      { key: "panen", label: "8. Hasil Panen", emoji: "🌾" },
    ],
  },
  {
    group: "Laporan & Data",
    color: "#D32F2F",
    screens: [
      { key: "laporan", label: "9. Laporan Musim", emoji: "📊" },
      { key: "history", label: "14. History Musim", emoji: "🕐" },
    ],
  },
  {
    group: "Utilitas",
    color: "#7B1FA2",
    screens: [
      { key: "backup", label: "10. Backup & Restore", emoji: "💾" },
      { key: "settings", label: "11. Pengaturan", emoji: "⚙️" },
      { key: "data-lahan", label: "12. Data Lahan", emoji: "🗺️" },
      { key: "data-tanaman", label: "13. Data Tanaman", emoji: "🌿" },
      { key: "lisensi", label: "15. Info Lisensi", emoji: "🛡️" },
    ],
  },
];

// ─── Screen Renderer ─────────────────────────────────────────────────────────
function renderScreen(screen: ScreenKey, navigate: (s: string) => void) {
  const nav = (s: string) => navigate(s as ScreenKey);
  switch (screen) {
    case "activation":   return <ActivationScreen onActivated={() => nav("setup-profile")} />;
    case "setup-profile":return <SetupProfileScreen onSaved={() => nav("dashboard")} />;
    case "dashboard":    return <DashboardScreen onNavigate={nav} />;
    case "data-tanam":   return <DataTanamScreen onNavigate={nav} />;
    case "detail-tanam": return <DetailTanamScreen onNavigate={nav} />;
    case "biaya":        return <BiayaProduksiScreen onNavigate={nav} />;
    case "jadwal":       return <JadwalKegiatanScreen onNavigate={nav} />;
    case "panen":        return <HasilPanenScreen onNavigate={nav} />;
    case "laporan":      return <LaporanScreen onNavigate={nav} />;
    case "backup":       return <BackupRestoreScreen onNavigate={nav} />;
    case "settings":     return <SettingsScreen onNavigate={nav} />;
    case "data-lahan":   return <DataLahanScreen onNavigate={nav} />;
    case "data-tanaman": return <DataTanamanScreen onNavigate={nav} />;
    case "history":      return <HistoryMusimScreen onNavigate={nav} />;
    case "lisensi":      return <InfoLisensiScreen onNavigate={nav} />;
    default:             return <DashboardScreen onNavigate={nav} />;
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────
function sleep(ms: number) {
  return new Promise<void>((resolve) => setTimeout(resolve, ms));
}

async function captureElement(el: HTMLElement, filename: string) {
  const dataUrl = await toPng(el, {
    pixelRatio: 2,
    backgroundColor: "#F3F7F4",
    cacheBust: true,
  });
  const link = document.createElement("a");
  link.download = `${filename}.png`;
  link.href = dataUrl;
  link.click();
}

async function downloadSourceZip() {
  const zip = new JSZip();
  const folder = zip.folder("YooTani-Source")!;

  // Add bundled source files
  for (const file of SOURCE_FILES) {
    folder.file(file.path, file.content);
  }

  // Fetch actual screen files from the server
  const screenFiles = [
    "src/app/App.tsx",
    "src/app/components/yootani/screens/ActivationScreen.tsx",
    "src/app/components/yootani/screens/SetupProfileScreen.tsx",
    "src/app/components/yootani/screens/DashboardScreen.tsx",
    "src/app/components/yootani/screens/DataTanamScreen.tsx",
    "src/app/components/yootani/screens/DetailTanamScreen.tsx",
    "src/app/components/yootani/screens/BiayaProduksiScreen.tsx",
    "src/app/components/yootani/screens/JadwalKegiatanScreen.tsx",
    "src/app/components/yootani/screens/HasilPanenScreen.tsx",
    "src/app/components/yootani/screens/LaporanScreen.tsx",
    "src/app/components/yootani/screens/BackupRestoreScreen.tsx",
    "src/app/components/yootani/screens/SettingsScreen.tsx",
    "src/app/components/yootani/screens/DataLahanScreen.tsx",
    "src/app/components/yootani/screens/DataTanamanScreen.tsx",
    "src/app/components/yootani/screens/HistoryMusimScreen.tsx",
    "src/app/components/yootani/screens/InfoLisensiScreen.tsx",
  ];

  for (const filePath of screenFiles) {
    try {
      const res = await fetch(`/${filePath}`);
      if (res.ok) {
        const text = await res.text();
        folder.file(filePath, text);
      }
    } catch {
      // skip if fetch fails (dev env)
    }
  }

  const blob = await zip.generateAsync({ type: "blob", compression: "DEFLATE", compressionOptions: { level: 6 } });
  saveAs(blob, "YooTani-Source.zip");
}

// ─── Main App ────────────────────────────────────────────────────────────────
export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenKey>("activation");
  const [navOpen, setNavOpen] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState<{ current: number; total: number; label: string } | null>(null);
  const screenRef = useRef<HTMLDivElement>(null);

  function navigate(screen: string) {
    setCurrentScreen(screen as ScreenKey);
  }

  // Download current screen as PNG
  const downloadCurrent = useCallback(async () => {
    if (!screenRef.current) return;
    const entry = allScreens.find((s) => s.key === currentScreen);
    const filename = entry ? entry.filename : `YooTani_${currentScreen}`;
    await captureElement(screenRef.current, filename);
  }, [currentScreen]);

  // Export all 15 screens as individual PNGs
  const exportAll = useCallback(async () => {
    if (!screenRef.current || exporting) return;
    setExporting(true);
    const originalScreen = currentScreen;

    for (let i = 0; i < allScreens.length; i++) {
      const { key, filename } = allScreens[i];
      setCurrentScreen(key);
      setExportProgress({ current: i + 1, total: allScreens.length, label: filename });
      // Wait for React to re-render + fonts/images
      await sleep(700);
      if (screenRef.current) {
        await captureElement(screenRef.current, filename);
      }
      await sleep(200);
    }

    // Restore original screen
    setCurrentScreen(originalScreen as ScreenKey);
    setExporting(false);
    setExportProgress(null);
  }, [currentScreen, exporting]);

  const progressPct = exportProgress
    ? Math.round((exportProgress.current / exportProgress.total) * 100)
    : 0;

  return (
    <div
      style={{
        minHeight: "100vh",
        backgroundColor: "#E8F0EC",
        display: "flex",
        fontFamily: "'Inter', system-ui, sans-serif",
        backgroundImage: "radial-gradient(circle at 20% 20%, #C8E6C9 0%, transparent 60%), radial-gradient(circle at 80% 80%, #DCEDC8 0%, transparent 60%)",
      }}
    >
      {/* ─── Left Sidebar – Screen Navigator ─────────────────────────────── */}
      <div
        style={{
          width: navOpen ? 260 : 0,
          minWidth: navOpen ? 260 : 0,
          transition: "all 0.3s ease",
          overflowX: "hidden",
          backgroundColor: "#1B2D1E",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <div style={{ width: 260, height: "100%", display: "flex", flexDirection: "column" }}>
          {/* Logo */}
          <div style={{ padding: "20px 16px 16px", borderBottom: "1px solid rgba(255,255,255,0.1)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: C.green, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round">
                  <path d="M12 22V10M12 10C12 4 6 2 6 2s0 8 6 8zM12 10C12 4 18 2 18 2s0 8-6 8z" />
                </svg>
              </div>
              <div>
                <p style={{ color: "white", fontSize: 16, fontWeight: 700 }}>YooTani</p>
                <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 11 }}>UI Prototype</p>
              </div>
            </div>
          </div>

          {/* Screen list */}
          <div style={{ flex: 1, overflowY: "auto", padding: "12px 0" }}>
            {screenGroups.map((group) => (
              <div key={group.group} style={{ marginBottom: 4 }}>
                <p style={{ fontSize: 10, fontWeight: 700, color: "rgba(255,255,255,0.35)", letterSpacing: 1, padding: "8px 16px 4px" }}>
                  {group.group.toUpperCase()}
                </p>
                {group.screens.map((s) => {
                  const isActive = currentScreen === s.key;
                  return (
                    <button
                      key={s.key}
                      onClick={() => { navigate(s.key); setNavOpen(false); }}
                      style={{
                        width: "100%",
                        padding: "10px 16px",
                        display: "flex",
                        alignItems: "center",
                        gap: 10,
                        border: "none",
                        backgroundColor: isActive ? `${group.color}25` : "transparent",
                        borderLeft: isActive ? `3px solid ${group.color}` : "3px solid transparent",
                        cursor: "pointer",
                        textAlign: "left",
                      }}
                    >
                      <span style={{ fontSize: 16 }}>{s.emoji}</span>
                      <p style={{ fontSize: 13, color: isActive ? "white" : "rgba(255,255,255,0.6)", fontWeight: isActive ? 600 : 400 }}>
                        {s.label}
                      </p>
                    </button>
                  );
                })}
              </div>
            ))}
          </div>

          {/* Download buttons in sidebar */}
          <div style={{ padding: "12px 16px 20px", borderTop: "1px solid rgba(255,255,255,0.1)", display: "flex", flexDirection: "column", gap: 8 }}>
            <button
              onClick={downloadCurrent}
              disabled={exporting}
              style={{
                width: "100%", padding: "10px 0", borderRadius: 8,
                backgroundColor: "#2D7A3A", color: "white",
                fontSize: 13, fontWeight: 600, border: "none", cursor: exporting ? "not-allowed" : "pointer",
                opacity: exporting ? 0.5 : 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
              }}
            >
              <DownloadIcon /> Download Screen Ini
            </button>
            <button
              onClick={exportAll}
              disabled={exporting}
              style={{
                width: "100%", padding: "10px 0", borderRadius: 8,
                backgroundColor: exporting ? "#555" : "#1565C0", color: "white",
                fontSize: 13, fontWeight: 600, border: "none", cursor: exporting ? "not-allowed" : "pointer",
                display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
              }}
            >
              {exporting ? <SpinnerIcon /> : <PackageIcon />}
              {exporting ? `Exporting ${exportProgress?.current}/${exportProgress?.total}…` : "Export Semua 15 PNG"}
            </button>
            <button
              onClick={downloadSourceZip}
              style={{
                width: "100%", padding: "10px 0", borderRadius: 8,
                backgroundColor: "#7B1FA2", color: "white",
                fontSize: 13, fontWeight: 600, border: "none", cursor: "pointer",
                display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
              }}
            >
              <PackageIcon />
              Download Source Code
            </button>
          </div>
        </div>
      </div>

      {/* ─── Center – Phone Frame ──────────────────────────────────────────── */}
      <div
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: "24px 20px",
          gap: 20,
          minHeight: "100vh",
        }}
      >
        {/* Top bar */}
        <div style={{ display: "flex", alignItems: "center", gap: 10, width: "100%", maxWidth: 500 }}>
          <button
            onClick={() => setNavOpen(!navOpen)}
            style={{
              height: 40, paddingLeft: 14, paddingRight: 14,
              borderRadius: 10, backgroundColor: C.green, color: "white",
              fontSize: 13, fontWeight: 600, border: "none", cursor: "pointer",
              display: "flex", alignItems: "center", gap: 8, flexShrink: 0,
            }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round">
              <line x1="3" y1="12" x2="21" y2="12" />
              <line x1="3" y1="6" x2="21" y2="6" />
              <line x1="3" y1="18" x2="21" y2="18" />
            </svg>
            Screens
          </button>

          {/* Screen quick pills */}
          <div style={{ display: "flex", gap: 6, overflowX: "auto", flex: 1, paddingBottom: 2 }}>
            {[
              { key: "activation",   label: "🔑 Aktivasi" },
              { key: "setup-profile",label: "👤 Profil" },
              { key: "dashboard",    label: "🏠 Dashboard" },
              { key: "data-tanam",   label: "🌱 Tanam" },
              { key: "jadwal",       label: "📅 Jadwal" },
              { key: "laporan",      label: "📊 Laporan" },
              { key: "settings",     label: "⚙️ Lainnya" },
            ].map((s) => {
              const isActive = currentScreen === s.key;
              return (
                <button
                  key={s.key}
                  onClick={() => navigate(s.key)}
                  style={{
                    height: 32, paddingLeft: 12, paddingRight: 12,
                    borderRadius: 20,
                    backgroundColor: isActive ? C.green : "white",
                    color: isActive ? "white" : C.textMid,
                    fontSize: 12, fontWeight: isActive ? 600 : 400,
                    border: `1px solid ${isActive ? C.green : C.border}`,
                    cursor: "pointer", flexShrink: 0, whiteSpace: "nowrap",
                    boxShadow: isActive ? "0 2px 8px rgba(45,122,58,0.3)" : "none",
                  }}
                >
                  {s.label}
                </button>
              );
            })}
          </div>

          {/* Download current button (top bar) */}
          <button
            onClick={downloadCurrent}
            disabled={exporting}
            title="Download screen ini sebagai PNG"
            style={{
              height: 40, paddingLeft: 14, paddingRight: 14,
              borderRadius: 10, backgroundColor: "#fff",
              color: C.green, fontSize: 13, fontWeight: 600,
              border: `1.5px solid ${C.green}`, cursor: exporting ? "not-allowed" : "pointer",
              display: "flex", alignItems: "center", gap: 6, flexShrink: 0,
              opacity: exporting ? 0.5 : 1,
            }}
          >
            <DownloadIcon color={C.green} />
            PNG
          </button>

          {/* Export All button (top bar) */}
          <button
            onClick={exportAll}
            disabled={exporting}
            title="Export semua 15 screen sebagai PNG"
            style={{
              height: 40, paddingLeft: 14, paddingRight: 14,
              borderRadius: 10,
              backgroundColor: exporting ? "#888" : "#1565C0",
              color: "white", fontSize: 13, fontWeight: 600,
              border: "none", cursor: exporting ? "not-allowed" : "pointer",
              display: "flex", alignItems: "center", gap: 6, flexShrink: 0,
              whiteSpace: "nowrap",
            }}
          >
            {exporting ? <SpinnerIcon /> : <PackageIcon />}
            {exporting ? `${exportProgress?.current ?? 0}/${exportProgress?.total ?? 15}` : "Export All"}
          </button>
        </div>

        {/* Export progress bar */}
        {exporting && exportProgress && (
          <div style={{ width: "100%", maxWidth: 500 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
              <span style={{ fontSize: 12, color: "#1565C0", fontWeight: 600 }}>
                Mengexport: {exportProgress.label}.png
              </span>
              <span style={{ fontSize: 12, color: "#555" }}>
                {exportProgress.current} / {exportProgress.total}
              </span>
            </div>
            <div style={{ height: 6, backgroundColor: "#ddd", borderRadius: 3, overflow: "hidden" }}>
              <div
                style={{
                  height: "100%", backgroundColor: "#1565C0", borderRadius: 3,
                  width: `${progressPct}%`, transition: "width 0.4s ease",
                }}
              />
            </div>
          </div>
        )}

        {/* Phone mockup */}
        <div style={{ position: "relative", width: 390, flexShrink: 0 }}>
          {/* Phone outer shell */}
          <div
            style={{
              width: 390, backgroundColor: "#1A1A1A",
              borderRadius: 52, padding: "14px 8px",
              boxShadow: "0 40px 80px rgba(0,0,0,0.4), 0 0 0 1px #333, inset 0 0 0 1px rgba(255,255,255,0.05)",
            }}
          >
            {/* Camera punch hole */}
            <div style={{ display: "flex", justifyContent: "center", marginBottom: 8 }}>
              <div style={{ width: 14, height: 14, borderRadius: 7, backgroundColor: "#111", border: "1.5px solid #2a2a2a" }} />
            </div>

            {/* Screen — this is what gets captured */}
            <div
              ref={screenRef}
              style={{
                width: "100%", height: 780,
                borderRadius: 40, overflow: "hidden",
                backgroundColor: "#F3F7F4", position: "relative",
              }}
            >
              {renderScreen(currentScreen, navigate)}
            </div>

            {/* Home indicator */}
            <div style={{ display: "flex", justifyContent: "center", marginTop: 10 }}>
              <div style={{ width: 120, height: 5, borderRadius: 3, backgroundColor: "#444" }} />
            </div>
          </div>

          {/* Side buttons */}
          <div style={{ position: "absolute", left: -6, top: 100, width: 5, height: 32, backgroundColor: "#2a2a2a", borderRadius: "3px 0 0 3px" }} />
          <div style={{ position: "absolute", left: -6, top: 145, width: 5, height: 54, backgroundColor: "#2a2a2a", borderRadius: "3px 0 0 3px" }} />
          <div style={{ position: "absolute", left: -6, top: 210, width: 5, height: 54, backgroundColor: "#2a2a2a", borderRadius: "3px 0 0 3px" }} />
          <div style={{ position: "absolute", right: -6, top: 160, width: 5, height: 74, backgroundColor: "#2a2a2a", borderRadius: "0 3px 3px 0" }} />
        </div>

        {/* Screen label */}
        <div style={{ textAlign: "center" }}>
          <p style={{ fontSize: 13, color: "#5A7060", fontWeight: 500 }}>
            YooTani • Aplikasi Usaha Tani Digital
          </p>
          <p style={{ fontSize: 12, color: "#8FAE96", marginTop: 2 }}>
            High-fidelity Mobile UI Prototype • 390 × 780px
          </p>
          <p style={{ fontSize: 11, color: "#aaa", marginTop: 4 }}>
            Klik <strong>PNG</strong> untuk download screen aktif • Klik <strong>Export All</strong> untuk download semua 15 screen sekaligus
          </p>
        </div>
      </div>

      {/* Overlay when nav open on small screens */}
      {navOpen && (
        <div
          onClick={() => setNavOpen(false)}
          style={{ position: "fixed", inset: 0, backgroundColor: "rgba(0,0,0,0.3)", zIndex: 10, display: "none" }}
        />
      )}
    </div>
  );
}

// ─── Inline icon components ───────────────────────────────────────────────────
function DownloadIcon({ color = "white" }: { color?: string }) {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
      <polyline points="7 10 12 15 17 10" />
      <line x1="12" y1="15" x2="12" y2="3" />
    </svg>
  );
}

function PackageIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="16 16 12 12 8 16" />
      <line x1="12" y1="12" x2="12" y2="21" />
      <path d="M20.39 18.39A5 5 0 0018 9h-1.26A8 8 0 103 16.3" />
    </svg>
  );
}

function SpinnerIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
      <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83">
        <animateTransform attributeName="transform" type="rotate" from="0 12 12" to="360 12 12" dur="0.8s" repeatCount="indefinite" />
      </path>
    </svg>
  );
}