import React from "react";

// ─── Color tokens ───────────────────────────────────────────────────────────
export const C = {
  green: "#2D7A3A",
  greenMid: "#3E9A4D",
  greenLight: "#6DBF7A",
  greenSoft: "#E8F5EB",
  greenBg: "#F1F8F2",
  bg: "#F3F7F4",
  card: "#FFFFFF",
  border: "#E0EDE2",
  textDark: "#1B2D1E",
  textMid: "#4A6652",
  textLight: "#7FA888",
  orange: "#E8820A",
  orangeSoft: "#FFF4E5",
  red: "#D32F2F",
  redSoft: "#FFEBEE",
  blue: "#1565C0",
  blueSoft: "#E3F2FD",
  yellow: "#F9A825",
  yellowSoft: "#FFFDE7",
  white: "#FFFFFF",
};

// ─── StatusBar ───────────────────────────────────────────────────────────────
export function StatusBar({ dark = false }: { dark?: boolean }) {
  const now = new Date();
  const h = now.getHours().toString().padStart(2, "0");
  const m = now.getMinutes().toString().padStart(2, "0");
  const textColor = dark ? "text-white" : "text-white";
  return (
    <div
      className={`flex items-center justify-between px-5 py-2 ${textColor}`}
      style={{ height: 28, backgroundColor: "transparent" }}
    >
      <span style={{ fontSize: 13, fontWeight: 600 }}>
        {h}:{m}
      </span>
      <div className="flex items-center gap-1">
        {/* Signal */}
        <svg width="16" height="12" viewBox="0 0 16 12" fill="currentColor">
          <rect x="0" y="8" width="3" height="4" rx="0.5" opacity="1" />
          <rect x="4.5" y="5" width="3" height="7" rx="0.5" opacity="1" />
          <rect x="9" y="2" width="3" height="10" rx="0.5" opacity="1" />
          <rect x="13.5" y="0" width="2.5" height="12" rx="0.5" opacity="0.4" />
        </svg>
        {/* WiFi */}
        <svg width="16" height="12" viewBox="0 0 16 12" fill="currentColor">
          <path d="M8 9.5a1.5 1.5 0 110 3 1.5 1.5 0 010-3z" />
          <path d="M8 6C5.8 6 3.8 6.9 2.3 8.3l1.4 1.4C4.9 8.6 6.3 8 8 8s3.1.6 4.3 1.7l1.4-1.4C12.2 6.9 10.2 6 8 6z" opacity="0.7" />
          <path d="M8 2C4.7 2 1.7 3.4 0 5.7l1.5 1.3C3 5 5.4 3.7 8 3.7s5 1.3 6.5 3.3L16 5.7C14.3 3.4 11.3 2 8 2z" opacity="0.4" />
        </svg>
        {/* Battery */}
        <svg width="22" height="12" viewBox="0 0 22 12" fill="currentColor">
          <rect x="0" y="1.5" width="18" height="9" rx="2" stroke="currentColor" strokeWidth="1.2" fill="none" />
          <rect x="1.2" y="2.7" width="13" height="6.6" rx="1" />
          <path d="M19 4v4a2 2 0 000-4z" />
        </svg>
      </div>
    </div>
  );
}

// ─── Header ──────────────────────────────────────────────────────────────────
interface HeaderProps {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  rightElement?: React.ReactNode;
}
export function Header({ title, subtitle, onBack, rightElement }: HeaderProps) {
  return (
    <div
      className="flex items-center gap-3 px-4 pb-4"
      style={{ backgroundColor: C.green, paddingTop: 8 }}
    >
      {onBack && (
        <button
          onClick={onBack}
          className="flex items-center justify-center rounded-full"
          style={{ width: 36, height: 36, backgroundColor: "rgba(255,255,255,0.15)" }}
        >
          <svg width="20" height="20" viewBox="0 0 20 20" fill="white">
            <path d="M12.5 15L7.5 10l5-5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
          </svg>
        </button>
      )}
      <div className="flex-1">
        <h1 style={{ color: "white", fontSize: 18, fontWeight: 700, lineHeight: 1.3 }}>{title}</h1>
        {subtitle && (
          <p style={{ color: "rgba(255,255,255,0.8)", fontSize: 13, marginTop: 1 }}>{subtitle}</p>
        )}
      </div>
      {rightElement && <div>{rightElement}</div>}
    </div>
  );
}

// ─── GreenHeader (with StatusBar built in) ───────────────────────────────────
interface GreenHeaderProps {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  rightElement?: React.ReactNode;
}
export function GreenHeader({ title, subtitle, onBack, rightElement }: GreenHeaderProps) {
  return (
    <div style={{ backgroundColor: C.green }}>
      <StatusBar dark />
      <Header title={title} subtitle={subtitle} onBack={onBack} rightElement={rightElement} />
    </div>
  );
}

// ─── BottomNav ────────────────────────────────────────────────────────────────
interface BottomNavProps {
  active: string;
  onNavigate: (screen: string) => void;
}
export function BottomNav({ active, onNavigate }: BottomNavProps) {
  const items = [
    { key: "dashboard", label: "Beranda", icon: HomeIcon },
    { key: "data-tanam", label: "Tanam", icon: SeedIcon },
    { key: "jadwal", label: "Jadwal", icon: CalendarIcon },
    { key: "laporan", label: "Laporan", icon: ReportIcon },
    { key: "settings", label: "Lainnya", icon: MenuIcon },
  ];
  return (
    <div
      className="flex items-center"
      style={{
        backgroundColor: C.white,
        borderTop: `1px solid ${C.border}`,
        height: 64,
        paddingBottom: 8,
      }}
    >
      {items.map((item) => {
        const isActive = active === item.key;
        const Icon = item.icon;
        return (
          <button
            key={item.key}
            onClick={() => onNavigate(item.key)}
            className="flex-1 flex flex-col items-center justify-center gap-1"
            style={{ height: "100%" }}
          >
            <Icon
              size={22}
              color={isActive ? C.green : C.textLight}
              filled={isActive}
            />
            <span
              style={{
                fontSize: 11,
                fontWeight: isActive ? 600 : 400,
                color: isActive ? C.green : C.textLight,
              }}
            >
              {item.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}

// ─── Card ─────────────────────────────────────────────────────────────────────
interface CardProps {
  children: React.ReactNode;
  style?: React.CSSProperties;
  onClick?: () => void;
  className?: string;
}
export function Card({ children, style, onClick, className = "" }: CardProps) {
  return (
    <div
      onClick={onClick}
      className={`${onClick ? "cursor-pointer active:opacity-80" : ""} ${className}`}
      style={{
        backgroundColor: C.white,
        borderRadius: 12,
        padding: 16,
        boxShadow: "0 1px 4px rgba(0,0,0,0.07)",
        ...style,
      }}
    >
      {children}
    </div>
  );
}

// ─── Badge ────────────────────────────────────────────────────────────────────
interface BadgeProps {
  label: string;
  type?: "success" | "warning" | "danger" | "info" | "default";
}
export function Badge({ label, type = "default" }: BadgeProps) {
  const styles: Record<string, { bg: string; color: string }> = {
    success: { bg: C.greenSoft, color: C.green },
    warning: { bg: C.orangeSoft, color: C.orange },
    danger: { bg: C.redSoft, color: C.red },
    info: { bg: C.blueSoft, color: C.blue },
    default: { bg: "#F0F0F0", color: "#666" },
  };
  const s = styles[type];
  return (
    <span
      style={{
        backgroundColor: s.bg,
        color: s.color,
        fontSize: 11,
        fontWeight: 600,
        paddingLeft: 8,
        paddingRight: 8,
        paddingTop: 3,
        paddingBottom: 3,
        borderRadius: 20,
      }}
    >
      {label}
    </span>
  );
}

// ─── PrimaryButton ────────────────────────────────────────────────────────────
interface ButtonProps {
  label: string;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "danger" | "outline";
  icon?: React.ReactNode;
  disabled?: boolean;
  fullWidth?: boolean;
}
export function PrimaryButton({ label, onClick, variant = "primary", icon, disabled, fullWidth = true }: ButtonProps) {
  const styles = {
    primary: { bg: C.green, color: "white", border: "none" },
    secondary: { bg: C.greenSoft, color: C.green, border: "none" },
    danger: { bg: C.red, color: "white", border: "none" },
    outline: { bg: "transparent", color: C.green, border: `1.5px solid ${C.green}` },
  };
  const s = styles[variant];
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        backgroundColor: disabled ? "#ccc" : s.bg,
        color: disabled ? "#888" : s.color,
        border: s.border,
        borderRadius: 12,
        height: 52,
        width: fullWidth ? "100%" : "auto",
        paddingLeft: 20,
        paddingRight: 20,
        fontSize: 16,
        fontWeight: 600,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 8,
        cursor: disabled ? "not-allowed" : "pointer",
      }}
    >
      {icon && <span>{icon}</span>}
      {label}
    </button>
  );
}

// ─── Input ────────────────────────────────────────────────────────────────────
interface InputProps {
  label: string;
  placeholder?: string;
  value?: string;
  onChange?: (v: string) => void;
  type?: string;
  hint?: string;
  icon?: React.ReactNode;
  error?: string;
}
export function Input({ label, placeholder, value, onChange, type = "text", hint, icon, error }: InputProps) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <label style={{ fontSize: 14, fontWeight: 600, color: C.textMid }}>{label}</label>
      <div style={{ position: "relative" }}>
        {icon && (
          <div
            style={{
              position: "absolute",
              left: 14,
              top: "50%",
              transform: "translateY(-50%)",
              color: C.textLight,
            }}
          >
            {icon}
          </div>
        )}
        <input
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={(e) => onChange?.(e.target.value)}
          style={{
            width: "100%",
            height: 52,
            borderRadius: 10,
            border: `1.5px solid ${error ? C.red : C.border}`,
            backgroundColor: error ? C.redSoft : "#FAFCFB",
            paddingLeft: icon ? 44 : 16,
            paddingRight: 16,
            fontSize: 15,
            color: C.textDark,
            outline: "none",
            boxSizing: "border-box",
          }}
        />
      </div>
      {hint && <p style={{ fontSize: 12, color: C.textLight }}>{hint}</p>}
      {error && <p style={{ fontSize: 12, color: C.red }}>{error}</p>}
    </div>
  );
}

// ─── SectionTitle ─────────────────────────────────────────────────────────────
export function SectionTitle({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  return (
    <div className="flex items-center justify-between" style={{ marginBottom: 10 }}>
      <h3 style={{ fontSize: 15, fontWeight: 700, color: C.textDark }}>{title}</h3>
      {action && (
        <button onClick={onAction} style={{ fontSize: 13, color: C.green, fontWeight: 600 }}>
          {action}
        </button>
      )}
    </div>
  );
}

// ─── Divider ─────────────────────────────────────────────────────────────────
export function Divider() {
  return <div style={{ height: 1, backgroundColor: C.border, marginTop: 8, marginBottom: 8 }} />;
}

// ─── FAB ─────────────────────────────────────────────────────────────────────
interface FABProps {
  onClick?: () => void;
  label?: string;
}
export function FAB({ onClick, label }: FABProps) {
  return (
    <button
      onClick={onClick}
      style={{
        position: "absolute",
        bottom: 80,
        right: 16,
        backgroundColor: C.green,
        color: "white",
        borderRadius: 16,
        height: 52,
        paddingLeft: 20,
        paddingRight: 20,
        boxShadow: "0 4px 14px rgba(45,122,58,0.35)",
        display: "flex",
        alignItems: "center",
        gap: 8,
        fontSize: 15,
        fontWeight: 600,
      }}
    >
      <span style={{ fontSize: 22, lineHeight: 1 }}>+</span>
      {label && <span>{label}</span>}
    </button>
  );
}

// ─── EmptyState ───────────────────────────────────────────────────────────────
interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  subtitle?: string;
  action?: string;
  onAction?: () => void;
}
export function EmptyState({ icon, title, subtitle, action, onAction }: EmptyStateProps) {
  return (
    <div
      className="flex flex-col items-center justify-center"
      style={{ padding: "40px 24px", gap: 12 }}
    >
      {icon && (
        <div
          style={{
            width: 72,
            height: 72,
            borderRadius: 36,
            backgroundColor: C.greenSoft,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            marginBottom: 4,
          }}
        >
          {icon}
        </div>
      )}
      <p style={{ fontSize: 16, fontWeight: 600, color: C.textMid, textAlign: "center" }}>{title}</p>
      {subtitle && (
        <p style={{ fontSize: 14, color: C.textLight, textAlign: "center", lineHeight: 1.5 }}>{subtitle}</p>
      )}
      {action && (
        <button
          onClick={onAction}
          style={{
            marginTop: 8,
            backgroundColor: C.green,
            color: "white",
            borderRadius: 10,
            height: 44,
            paddingLeft: 24,
            paddingRight: 24,
            fontSize: 14,
            fontWeight: 600,
          }}
        >
          {action}
        </button>
      )}
    </div>
  );
}

// ─── SimpleIcons ─────────────────────────────────────────────────────────────
interface IconProps { size?: number; color?: string; filled?: boolean }

export function HomeIcon({ size = 24, color = "#2D7A3A", filled }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={filled ? color : "none"} stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
      <polyline points="9,22 9,12 15,12 15,22" />
    </svg>
  );
}

export function SeedIcon({ size = 24, color = "#2D7A3A", filled }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={filled ? color : "none"} stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 22V12" />
      <path d="M5 12C5 8.134 8.134 5 12 5c3.866 0 7 3.134 7 7" />
      <path d="M5 12c0-2.209 3.134-4 7-4 3.866 0 7 1.791 7 4" />
      <circle cx="12" cy="5" r="2" fill={filled ? color : "none"} />
    </svg>
  );
}

export function CalendarIcon({ size = 24, color = "#2D7A3A", filled }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={filled ? color : "none"} stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
    </svg>
  );
}

export function ReportIcon({ size = 24, color = "#2D7A3A", filled }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={filled ? color : "none"} stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" />
      <polyline points="14,2 14,8 20,8" />
      <line x1="16" y1="13" x2="8" y2="13" />
      <line x1="16" y1="17" x2="8" y2="17" />
      <polyline points="10,9 9,9 8,9" />
    </svg>
  );
}

export function MenuIcon({ size = 24, color = "#2D7A3A", filled }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round">
      <line x1="3" y1="12" x2="21" y2="12" />
      <line x1="3" y1="6" x2="21" y2="6" />
      <line x1="3" y1="18" x2="21" y2="18" />
    </svg>
  );
}

export function LeafIcon({ size = 24, color = "#2D7A3A" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M11 20A7 7 0 014 13V6a7 7 0 017 7v7z" />
      <path d="M20 6a7 7 0 00-7 7v7" />
    </svg>
  );
}

export function MoneyIcon({ size = 24, color = "#2D7A3A" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="5" width="20" height="14" rx="2" />
      <circle cx="12" cy="12" r="3" />
      <path d="M6 12h.01M18 12h.01" />
    </svg>
  );
}

export function HarvestIcon({ size = 24, color = "#2D7A3A" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 2a5 5 0 015 5c0 5-5 10-5 10S7 12 7 7a5 5 0 015-5z" />
      <path d="M12 22v-5" />
      <path d="M9 19h6" />
    </svg>
  );
}

export function BackupIcon({ size = 24, color = "#2D7A3A" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="1 4 1 10 7 10" />
      <path d="M3.51 15a9 9 0 102.13-9.36L1 10" />
    </svg>
  );
}

export function ShieldIcon({ size = 24, color = "#2D7A3A" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    </svg>
  );
}

export function LandIcon({ size = 24, color = "#2D7A3A" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2" />
      <path d="M3 9h18M3 15h18M9 3v18" />
    </svg>
  );
}

export function PlantIcon({ size = 24, color = "#2D7A3A" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 22V10" />
      <path d="M5 10C5 6.686 8.134 4 12 4c3.866 0 7 2.686 7 6H5z" />
    </svg>
  );
}

export function UserIcon({ size = 24, color = "#2D7A3A" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
}

export function BellIcon({ size = 24, color = "#2D7A3A" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9" />
      <path d="M13.73 21a2 2 0 01-3.46 0" />
    </svg>
  );
}

export function InfoIcon({ size = 24, color = "#2D7A3A" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="16" x2="12" y2="12" />
      <line x1="12" y1="8" x2="12.01" y2="8" />
    </svg>
  );
}

export function ChevronRightIcon({ size = 20, color = "#7FA888" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 20 20" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M7.5 5l5 5-5 5" />
    </svg>
  );
}

export function CheckIcon({ size = 20, color = "#2D7A3A" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 20 20" fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 10l5 5 7-9" />
    </svg>
  );
}

export function SprayIcon({ size = 24, color = "#2D7A3A" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 22l5-5" />
      <path d="M8 17l5-12" />
      <path d="M16 5h2a2 2 0 010 4h-2" />
      <path d="M13 5h3" />
      <circle cx="18" cy="5" r="1" fill={color} />
      <path d="M20 3l1-2M22 6h1M21 9l1 1" />
    </svg>
  );
}

export function PDFIcon({ size = 24, color = "#D32F2F" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" />
      <polyline points="14,2 14,8 20,8" />
      <text x="6" y="18" fill={color} stroke="none" fontSize="6" fontWeight="bold">PDF</text>
    </svg>
  );
}

export function HistoryIcon({ size = 24, color = "#2D7A3A" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="1 4 1 10 7 10" />
      <path d="M3.51 15a9 9 0 102.13-9.36L1 10" />
      <polyline points="12 7 12 12 16 14" />
    </svg>
  );
}

export function KeyIcon({ size = 24, color = "#2D7A3A" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="7" cy="17" r="4" />
      <path d="M10.5 13.5l8.5-8.5" />
      <path d="M17 7l2 2" />
      <path d="M14 7l2 2" />
    </svg>
  );
}

export function DownloadIcon({ size = 24, color = "#2D7A3A" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
      <polyline points="7 10 12 15 17 10" />
      <line x1="12" y1="15" x2="12" y2="3" />
    </svg>
  );
}

export function UploadIcon({ size = 24, color = "#2D7A3A" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
      <polyline points="17 8 12 3 7 8" />
      <line x1="12" y1="3" x2="12" y2="15" />
    </svg>
  );
}

export function PlusIcon({ size = 24, color = "#2D7A3A" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}

export function EditIcon({ size = 20, color = "#7FA888" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 20 20" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14.5 2.5a2.121 2.121 0 013 3L6 17H3v-3L14.5 2.5z" />
    </svg>
  );
}

export function TrashIcon({ size = 20, color = "#D32F2F" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 20 20" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="5 5 15 5" />
      <path d="M7 5V3h6v2" />
      <rect x="5" y="5" width="10" height="12" rx="1" />
      <line x1="8" y1="9" x2="8" y2="14" />
      <line x1="12" y1="9" x2="12" y2="14" />
    </svg>
  );
}

// ─── formatRupiah ─────────────────────────────────────────────────────────────
export function formatRupiah(n: number) {
  return "Rp " + n.toLocaleString("id-ID");
}
