import React from "react";
import { C, GreenHeader, BottomNav, LandIcon, PlantIcon, UserIcon, BellIcon, BackupIcon, ShieldIcon, InfoIcon, HistoryIcon, ChevronRightIcon } from "../shared";

interface Props {
  onNavigate: (screen: string) => void;
}

const menuItems = [
  {
    section: "Data Master",
    items: [
      { key: "data-lahan", label: "Data Lahan", desc: "Kelola lahan pertanian Anda", icon: LandIcon, color: C.green, bg: C.greenSoft },
      { key: "data-tanaman", label: "Data Tanaman", desc: "Kelola jenis tanaman", icon: PlantIcon, color: C.blue, bg: C.blueSoft },
    ],
  },
  {
    section: "Akun",
    items: [
      { key: "profil", label: "Profil Petani", desc: "Edit nama, HP, dan alamat", icon: UserIcon, color: "#7B1FA2", bg: "#F3E5F5" },
      { key: "notifikasi", label: "Notifikasi", desc: "Atur pengingat jadwal", icon: BellIcon, color: C.orange, bg: C.orangeSoft },
    ],
  },
  {
    section: "Data",
    items: [
      { key: "backup", label: "Backup & Restore", desc: "Amankan & pulihkan data", icon: BackupIcon, color: C.green, bg: C.greenSoft },
      { key: "history", label: "History Musim", desc: "Lihat musim yang sudah selesai", icon: HistoryIcon, color: C.blue, bg: C.blueSoft },
    ],
  },
  {
    section: "Lisensi & Info",
    items: [
      { key: "lisensi", label: "Info Lisensi", desc: "Status aktivasi lisensi", icon: ShieldIcon, color: C.green, bg: C.greenSoft },
      { key: "tentang", label: "Tentang Aplikasi", desc: "Versi & informasi YooTani", icon: InfoIcon, color: C.textMid, bg: C.bg },
    ],
  },
];

export function SettingsScreen({ onNavigate }: Props) {
  return (
    <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", backgroundColor: C.bg, fontFamily: "'Inter', system-ui, sans-serif" }}>
      {/* Header with profile */}
      <div style={{ background: `linear-gradient(135deg, ${C.green} 0%, #3E9A4D 100%)` }}>
        <div style={{ padding: "10px 20px 0", display: "flex", justifyContent: "space-between" }}>
          <span style={{ color: "white", fontSize: 13, fontWeight: 600 }}>09:41</span>
          <svg width="22" height="12" viewBox="0 0 22 12" fill="white">
            <rect x="0" y="1.5" width="18" height="9" rx="2" stroke="white" strokeWidth="1.2" fill="none" />
            <rect x="1.2" y="2.7" width="13" height="6.6" rx="1" fill="white" />
            <path d="M19 4v4a2 2 0 000-4z" fill="white" />
          </svg>
        </div>
        <div style={{ padding: "12px 20px 20px", display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ width: 60, height: 60, borderRadius: 30, backgroundColor: "rgba(255,255,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center", border: "2px solid rgba(255,255,255,0.4)", flexShrink: 0 }}>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round">
              <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
              <circle cx="12" cy="7" r="4" />
            </svg>
          </div>
          <div>
            <p style={{ color: "white", fontSize: 18, fontWeight: 700 }}>Pak Budi Santoso</p>
            <p style={{ color: "rgba(255,255,255,0.8)", fontSize: 13, marginTop: 2 }}>📱 0812-3456-7890</p>
            <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 12, marginTop: 1 }}>📍 Ds. Sukamaju, Ciwidey</p>
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px 100px" }}>
        {menuItems.map((section) => (
          <div key={section.section} style={{ marginBottom: 16 }}>
            <p style={{ fontSize: 12, fontWeight: 700, color: C.textLight, letterSpacing: 0.8, marginBottom: 8 }}>
              {section.section.toUpperCase()}
            </p>
            <div style={{ backgroundColor: C.white, borderRadius: 14, boxShadow: "0 1px 4px rgba(0,0,0,0.07)", overflow: "hidden" }}>
              {section.items.map((item, i) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.key}
                    onClick={() => onNavigate(item.key)}
                    style={{
                      width: "100%",
                      padding: "14px 16px",
                      display: "flex",
                      alignItems: "center",
                      gap: 14,
                      border: "none",
                      backgroundColor: "transparent",
                      borderBottom: i < section.items.length - 1 ? `1px solid ${C.border}` : "none",
                      cursor: "pointer",
                      textAlign: "left",
                    }}
                  >
                    <div style={{ width: 44, height: 44, borderRadius: 12, backgroundColor: item.bg, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                      <Icon size={22} color={item.color} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <p style={{ fontSize: 15, fontWeight: 600, color: C.textDark }}>{item.label}</p>
                      <p style={{ fontSize: 12, color: C.textLight, marginTop: 2 }}>{item.desc}</p>
                    </div>
                    <ChevronRightIcon size={20} color={C.textLight} />
                  </button>
                );
              })}
            </div>
          </div>
        ))}

        {/* App version */}
        <div style={{ textAlign: "center", paddingTop: 8 }}>
          <p style={{ fontSize: 12, color: C.textLight }}>YooTani v1.0.0 • Build 2024.04</p>
          <p style={{ fontSize: 11, color: C.textLight, marginTop: 2 }}>Aplikasi Usaha Tani Digital</p>
        </div>
      </div>

      <BottomNav active="settings" onNavigate={onNavigate} />
    </div>
  );
}
