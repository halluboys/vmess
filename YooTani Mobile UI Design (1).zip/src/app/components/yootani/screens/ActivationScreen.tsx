import React, { useState } from "react";
import { C, PrimaryButton, KeyIcon } from "../shared";

type ActivationState = "idle" | "loading" | "success" | "error-invalid" | "error-expired";

interface Props {
  onActivated: () => void;
}

export function ActivationScreen({ onActivated }: Props) {
  const [code, setCode] = useState("");
  const [state, setState] = useState<ActivationState>("idle");

  function handleActivate() {
    if (!code.trim()) return;
    setState("loading");
    setTimeout(() => {
      if (code.toUpperCase() === "EXPIRED") {
        setState("error-expired");
      } else if (code.length < 6) {
        setState("error-invalid");
      } else {
        setState("success");
        setTimeout(() => onActivated(), 1000);
      }
    }, 1400);
  }

  const isLoading = state === "loading";

  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        backgroundColor: "#FFFFFF",
        fontFamily: "'Inter', system-ui, sans-serif",
      }}
    >
      {/* Status Bar */}
      <div
        style={{
          backgroundColor: C.green,
          padding: "10px 20px 8px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <span style={{ color: "white", fontSize: 13, fontWeight: 600 }}>09:41</span>
        <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
          <svg width="16" height="12" viewBox="0 0 16 12" fill="white">
            <rect x="0" y="8" width="3" height="4" rx="0.5" />
            <rect x="4.5" y="5" width="3" height="7" rx="0.5" />
            <rect x="9" y="2" width="3" height="10" rx="0.5" />
          </svg>
          <svg width="16" height="12" viewBox="0 0 16 12" fill="white">
            <path d="M8 9.5a1.5 1.5 0 110 3 1.5 1.5 0 010-3z" />
            <path d="M8 6C5.8 6 3.8 6.9 2.3 8.3l1.4 1.4C4.9 8.6 6.3 8 8 8s3.1.6 4.3 1.7l1.4-1.4C12.2 6.9 10.2 6 8 6z" opacity="0.7" />
          </svg>
          <svg width="22" height="12" viewBox="0 0 22 12" fill="white">
            <rect x="0" y="1.5" width="18" height="9" rx="2" stroke="white" strokeWidth="1.2" fill="none" />
            <rect x="1.2" y="2.7" width="13" height="6.6" rx="1" fill="white" />
            <path d="M19 4v4a2 2 0 000-4z" fill="white" />
          </svg>
        </div>
      </div>

      {/* Hero Section */}
      <div
        style={{
          backgroundColor: C.green,
          paddingTop: 32,
          paddingBottom: 48,
          paddingLeft: 24,
          paddingRight: 24,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        {/* Logo */}
        <div
          style={{
            width: 80,
            height: 80,
            borderRadius: 20,
            backgroundColor: "white",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            boxShadow: "0 4px 20px rgba(0,0,0,0.15)",
            marginBottom: 16,
          }}
        >
          {/* Leaf logo */}
          <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
            <path d="M24 8C14 8 8 18 8 28c0 8 6 12 12 12 4 0 8-2 10-6 2 4 6 6 10 6 6 0 12-4 12-12 0-10-6-20-16-20 0 0 0 0-2 0z" fill={C.green} opacity="0.15" />
            <path d="M24 8C16 8 10 16 10 26c0 6 4 10 10 10 3 0 6-1.5 8-4 2 2.5 5 4 8 4 6 0 10-4 10-10 0-10-6-18-14-18h-8z" fill={C.greenLight} opacity="0.4" />
            <path d="M22 40V24M22 24C22 16 16 10 10 10" stroke={C.green} strokeWidth="3" strokeLinecap="round" />
            <path d="M22 24C22 16 28 10 36 10" stroke={C.green} strokeWidth="3" strokeLinecap="round" opacity="0.6" />
            <circle cx="22" cy="40" r="3" fill={C.green} />
          </svg>
        </div>
        <h1 style={{ color: "white", fontSize: 28, fontWeight: 800, letterSpacing: -0.5 }}>YooTani</h1>
        <p style={{ color: "rgba(255,255,255,0.85)", fontSize: 14, marginTop: 4 }}>
          Aplikasi Usaha Tani Digital
        </p>
      </div>

      {/* Wave separator */}
      <div style={{ marginTop: -1, lineHeight: 0 }}>
        <svg width="100%" height="36" viewBox="0 0 390 36" preserveAspectRatio="none" fill={C.green}>
          <path d="M0 0 Q97.5 36 195 18 Q292.5 0 390 36 L390 0 Z" />
        </svg>
      </div>

      {/* Form Section */}
      <div style={{ flex: 1, padding: "8px 24px 24px", overflowY: "auto" }}>
        {/* Info card */}
        <div
          style={{
            backgroundColor: C.blueSoft,
            borderRadius: 10,
            padding: "12px 14px",
            display: "flex",
            gap: 10,
            marginBottom: 24,
            alignItems: "flex-start",
          }}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={C.blue} strokeWidth="2" strokeLinecap="round" style={{ marginTop: 2, flexShrink: 0 }}>
            <circle cx="12" cy="12" r="10" />
            <line x1="12" y1="16" x2="12" y2="12" />
            <line x1="12" y1="8" x2="12.01" y2="8" />
          </svg>
          <p style={{ fontSize: 13, color: C.blue, lineHeight: 1.5 }}>
            Aktivasi awal membutuhkan koneksi internet. Masukkan kode lisensi yang diberikan admin.
          </p>
        </div>

        {/* Input */}
        <div style={{ marginBottom: 16 }}>
          <label style={{ fontSize: 14, fontWeight: 600, color: C.textMid, display: "block", marginBottom: 8 }}>
            Kode Lisensi
          </label>
          <div style={{ position: "relative" }}>
            <div style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)" }}>
              <KeyIcon size={20} color={C.textLight} />
            </div>
            <input
              value={code}
              onChange={(e) => {
                setCode(e.target.value);
                setState("idle");
              }}
              placeholder="Contoh: YTNI-2024-XXXX"
              style={{
                width: "100%",
                height: 56,
                borderRadius: 12,
                border: `2px solid ${
                  state === "error-invalid" || state === "error-expired"
                    ? C.red
                    : state === "success"
                    ? C.green
                    : C.border
                }`,
                backgroundColor: "#FAFCFB",
                paddingLeft: 48,
                paddingRight: 16,
                fontSize: 16,
                fontWeight: 600,
                color: C.textDark,
                outline: "none",
                letterSpacing: 1,
                boxSizing: "border-box",
              }}
            />
          </div>
        </div>

        {/* State messages */}
        {state === "error-invalid" && (
          <div
            style={{
              backgroundColor: C.redSoft,
              borderRadius: 8,
              padding: "10px 14px",
              display: "flex",
              gap: 8,
              marginBottom: 16,
              alignItems: "center",
            }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={C.red} strokeWidth="2.5" strokeLinecap="round">
              <circle cx="12" cy="12" r="10" />
              <line x1="15" y1="9" x2="9" y2="15" />
              <line x1="9" y1="9" x2="15" y2="15" />
            </svg>
            <p style={{ fontSize: 13, color: C.red, fontWeight: 500 }}>
              Kode lisensi tidak valid. Periksa kembali kode Anda.
            </p>
          </div>
        )}

        {state === "error-expired" && (
          <div
            style={{
              backgroundColor: C.orangeSoft,
              borderRadius: 8,
              padding: "10px 14px",
              display: "flex",
              gap: 8,
              marginBottom: 16,
              alignItems: "center",
            }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={C.orange} strokeWidth="2.5" strokeLinecap="round">
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
              <line x1="12" y1="16" x2="12.01" y2="16" />
            </svg>
            <p style={{ fontSize: 13, color: C.orange, fontWeight: 500 }}>
              Lisensi sudah kedaluwarsa. Hubungi admin untuk pembaruan.
            </p>
          </div>
        )}

        {state === "success" && (
          <div
            style={{
              backgroundColor: C.greenSoft,
              borderRadius: 8,
              padding: "10px 14px",
              display: "flex",
              gap: 8,
              marginBottom: 16,
              alignItems: "center",
            }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={C.green} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 11.08V12a10 10 0 11-5.93-9.14" />
              <polyline points="22 4 12 14.01 9 11.01" />
            </svg>
            <p style={{ fontSize: 13, color: C.green, fontWeight: 600 }}>
              Lisensi valid! Memproses...
            </p>
          </div>
        )}

        {/* Activate Button */}
        <button
          onClick={handleActivate}
          disabled={isLoading || !code.trim()}
          style={{
            width: "100%",
            height: 56,
            borderRadius: 14,
            backgroundColor: isLoading || !code.trim() ? "#B2DFBA" : C.green,
            color: "white",
            fontSize: 17,
            fontWeight: 700,
            border: "none",
            cursor: isLoading || !code.trim() ? "not-allowed" : "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 10,
            marginBottom: 16,
          }}
        >
          {isLoading ? (
            <>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" style={{ animation: "spin 1s linear infinite" }}>
                <path d="M21 12a9 9 0 11-6.2-8.55" />
              </svg>
              Memverifikasi...
            </>
          ) : (
            "Aktifkan Lisensi"
          )}
        </button>

        <p style={{ fontSize: 12, color: C.textLight, textAlign: "center", lineHeight: 1.6 }}>
          Butuh bantuan? Hubungi admin YooTani
        </p>
      </div>

      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
