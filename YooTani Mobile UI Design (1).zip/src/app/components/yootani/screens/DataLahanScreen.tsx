import React, { useState } from "react";
import { C, GreenHeader, LandIcon, PlusIcon, EditIcon, TrashIcon } from "../shared";

interface Props {
  onNavigate: (screen: string) => void;
}

const lahanData = [
  { id: 1, nama: "Lahan Sawah Barat", ukuran: "0.5 ha", lokasi: "Blok A, Ds. Sukamaju", musimAktif: 1 },
  { id: 2, nama: "Kebun Atas", ukuran: "0.25 ha", lokasi: "Blok B, Perbukitan", musimAktif: 1 },
  { id: 3, nama: "Lahan Sawah Timur", ukuran: "0.4 ha", lokasi: "Blok C, Ds. Sukamaju", musimAktif: 0 },
];

export function DataLahanScreen({ onNavigate }: Props) {
  const [showForm, setShowForm] = useState(false);
  const [nama, setNama] = useState("");
  const [ukuran, setUkuran] = useState("");
  const [lokasi, setLokasi] = useState("");

  return (
    <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", backgroundColor: C.bg, fontFamily: "'Inter', system-ui, sans-serif" }}>
      <GreenHeader
        title="Data Lahan"
        subtitle={`${lahanData.length} lahan terdaftar`}
        onBack={() => onNavigate("settings")}
        rightElement={
          <button onClick={() => setShowForm(true)} style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.2)", border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <PlusIcon size={20} color="white" />
          </button>
        }
      />

      <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px 24px" }}>

        {/* Add Form */}
        {showForm && (
          <div style={{ backgroundColor: C.white, borderRadius: 14, padding: 16, boxShadow: "0 2px 8px rgba(0,0,0,0.1)", marginBottom: 14 }}>
            <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark, marginBottom: 14 }}>Tambah Lahan Baru</p>
            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: C.textMid, display: "block", marginBottom: 6 }}>Nama Lahan <span style={{ color: C.red }}>*</span></label>
              <input value={nama} onChange={e => setNama(e.target.value)} placeholder="Contoh: Sawah Utara" style={{ width: "100%", height: 46, borderRadius: 8, border: `1.5px solid ${C.border}`, backgroundColor: "#FAFCFB", paddingLeft: 14, paddingRight: 14, fontSize: 14, color: C.textDark, outline: "none", boxSizing: "border-box" }} />
            </div>
            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: C.textMid, display: "block", marginBottom: 6 }}>Ukuran / Luas <span style={{ color: C.textLight, fontWeight: 400 }}>(opsional)</span></label>
              <input value={ukuran} onChange={e => setUkuran(e.target.value)} placeholder="Contoh: 0.3 ha" style={{ width: "100%", height: 46, borderRadius: 8, border: `1.5px solid ${C.border}`, backgroundColor: "#FAFCFB", paddingLeft: 14, paddingRight: 14, fontSize: 14, color: C.textDark, outline: "none", boxSizing: "border-box" }} />
            </div>
            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: C.textMid, display: "block", marginBottom: 6 }}>Lokasi <span style={{ color: C.textLight, fontWeight: 400 }}>(opsional)</span></label>
              <input value={lokasi} onChange={e => setLokasi(e.target.value)} placeholder="Blok / Desa / Keterangan" style={{ width: "100%", height: 46, borderRadius: 8, border: `1.5px solid ${C.border}`, backgroundColor: "#FAFCFB", paddingLeft: 14, paddingRight: 14, fontSize: 14, color: C.textDark, outline: "none", boxSizing: "border-box" }} />
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => setShowForm(false)} style={{ flex: 1, height: 46, borderRadius: 10, backgroundColor: C.bg, color: C.textMid, fontSize: 14, fontWeight: 600, border: `1px solid ${C.border}`, cursor: "pointer" }}>Batal</button>
              <button onClick={() => { setShowForm(false); setNama(""); setUkuran(""); setLokasi(""); }} style={{ flex: 2, height: 46, borderRadius: 10, backgroundColor: C.green, color: "white", fontSize: 14, fontWeight: 700, border: "none", cursor: "pointer" }}>Simpan Lahan</button>
            </div>
          </div>
        )}

        {/* Lahan List */}
        {lahanData.map((l) => (
          <div key={l.id} style={{ backgroundColor: C.white, borderRadius: 14, padding: "14px 16px", marginBottom: 10, boxShadow: "0 1px 4px rgba(0,0,0,0.07)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ width: 48, height: 48, borderRadius: 14, backgroundColor: C.greenSoft, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <LandIcon size={24} color={C.green} />
              </div>
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark }}>{l.nama}</p>
                {l.ukuran && <p style={{ fontSize: 13, color: C.textLight, marginTop: 1 }}>📐 {l.ukuran}</p>}
                {l.lokasi && <p style={{ fontSize: 12, color: C.textLight, marginTop: 1 }}>📍 {l.lokasi}</p>}
              </div>
              <div style={{ display: "flex", gap: 4 }}>
                <button style={{ width: 34, height: 34, borderRadius: 8, backgroundColor: C.bg, border: `1px solid ${C.border}`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <EditIcon size={16} color={C.textMid} />
                </button>
                <button style={{ width: 34, height: 34, borderRadius: 8, backgroundColor: C.redSoft, border: `1px solid #FFCDD2`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <TrashIcon size={16} color={C.red} />
                </button>
              </div>
            </div>
            {l.musimAktif > 0 && (
              <div style={{ marginTop: 10, paddingTop: 10, borderTop: `1px solid ${C.border}`, display: "flex", alignItems: "center", gap: 6 }}>
                <div style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: C.green }} />
                <p style={{ fontSize: 12, color: C.green, fontWeight: 500 }}>{l.musimAktif} musim aktif di lahan ini</p>
              </div>
            )}
          </div>
        ))}

        {/* Add button */}
        {!showForm && (
          <button
            onClick={() => setShowForm(true)}
            style={{ width: "100%", height: 52, borderRadius: 12, backgroundColor: C.greenSoft, color: C.green, fontSize: 15, fontWeight: 700, border: `1.5px dashed ${C.greenLight}`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 4 }}
          >
            <PlusIcon size={20} color={C.green} />
            Tambah Lahan
          </button>
        )}
      </div>
    </div>
  );
}
