import React, { useState } from "react";
import { C, GreenHeader, BottomNav, Badge, PlusIcon } from "../shared";

interface Props {
  onNavigate: (screen: string) => void;
}

const jadwalData = [
  { id: 1, kegiatan: "Semprot pestisida", jenis: "Semprot", lahan: "Sawah Barat", tanggal: "22 Apr 2024", jam: "07:00", done: false, prioritas: "tinggi" },
  { id: 2, kegiatan: "Pemupukan susulan NPK", jenis: "Pemupukan", lahan: "Sawah Barat", tanggal: "22 Apr 2024", jam: "10:00", done: false, prioritas: "normal" },
  { id: 3, kegiatan: "Pengecekan hama", jenis: "Monitoring", lahan: "Kebun Atas", tanggal: "23 Apr 2024", jam: "08:00", done: false, prioritas: "normal" },
  { id: 4, kegiatan: "Pengairan sawah", jenis: "Pengairan", lahan: "Sawah Barat", tanggal: "18 Apr 2024", jam: "06:00", done: true, prioritas: "normal" },
  { id: 5, kegiatan: "Semprot fungisida", jenis: "Semprot", lahan: "Kebun Atas", tanggal: "15 Apr 2024", jam: "07:30", done: true, prioritas: "tinggi" },
];

const jenisColors: Record<string, { bg: string; color: string; emoji: string }> = {
  Semprot: { bg: C.orangeSoft, color: C.orange, emoji: "💦" },
  Pemupukan: { bg: C.blueSoft, color: C.blue, emoji: "🧪" },
  Monitoring: { bg: C.yellowSoft, color: "#D4A017", emoji: "🔍" },
  Pengairan: { bg: "#E3F2FD", color: "#1976D2", emoji: "💧" },
};

export function JadwalKegiatanScreen({ onNavigate }: Props) {
  const [showForm, setShowForm] = useState(false);
  const [doneIds, setDoneIds] = useState<number[]>(jadwalData.filter(j => j.done).map(j => j.id));

  const belum = jadwalData.filter(j => !doneIds.includes(j.id));
  const selesai = jadwalData.filter(j => doneIds.includes(j.id));

  function toggleDone(id: number) {
    setDoneIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  }

  function JadwalCard({ j }: { j: typeof jadwalData[0] }) {
    const isDone = doneIds.includes(j.id);
    const js = jenisColors[j.jenis] || { bg: "#F5F5F5", color: "#666", emoji: "📌" };
    return (
      <div style={{ backgroundColor: C.white, borderRadius: 14, padding: "14px 16px", marginBottom: 8, display: "flex", gap: 12, boxShadow: "0 1px 3px rgba(0,0,0,0.06)", opacity: isDone ? 0.7 : 1 }}>
        <button
          onClick={() => toggleDone(j.id)}
          style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: isDone ? C.greenSoft : C.bg, border: `2px solid ${isDone ? C.green : C.border}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, cursor: "pointer" }}
        >
          {isDone && (
            <svg width="14" height="14" viewBox="0 0 20 20" fill="none" stroke={C.green} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 10l5 5 7-9" />
            </svg>
          )}
        </button>
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <p style={{ fontSize: 14, fontWeight: 600, color: isDone ? C.textLight : C.textDark, textDecoration: isDone ? "line-through" : "none" }}>{j.kegiatan}</p>
            {j.prioritas === "tinggi" && !isDone && (
              <span style={{ fontSize: 10, backgroundColor: C.redSoft, color: C.red, borderRadius: 6, padding: "2px 7px", fontWeight: 600 }}>Penting</span>
            )}
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 4, alignItems: "center", flexWrap: "wrap" }}>
            <span style={{ fontSize: 11, backgroundColor: js.bg, color: js.color, borderRadius: 6, padding: "2px 8px", fontWeight: 500 }}>{js.emoji} {j.jenis}</span>
            <p style={{ fontSize: 12, color: C.textLight }}>📍 {j.lahan}</p>
          </div>
          <p style={{ fontSize: 12, color: C.textLight, marginTop: 4 }}>🗓 {j.tanggal} • 🕐 {j.jam}</p>
        </div>
      </div>
    );
  }

  return (
    <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", backgroundColor: C.bg, fontFamily: "'Inter', system-ui, sans-serif" }}>
      <GreenHeader
        title="Jadwal Kegiatan"
        subtitle={`${belum.length} kegiatan belum selesai`}
        onBack={() => onNavigate("dashboard")}
        rightElement={
          <button onClick={() => setShowForm(true)} style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.2)", border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <PlusIcon size={20} color="white" />
          </button>
        }
      />

      <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px 24px" }}>

        {/* Add Form */}
        {showForm && (
          <div style={{ backgroundColor: C.white, borderRadius: 14, padding: 16, boxShadow: "0 2px 8px rgba(0,0,0,0.1)", marginBottom: 14 }}>
            <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark, marginBottom: 14 }}>Tambah Jadwal</p>
            {["Nama Kegiatan", "Jenis (Semprot/Pupuk...)", "Lahan", "Tanggal", "Jam"].map((label, i) => (
              <div key={i} style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 13, fontWeight: 600, color: C.textMid, display: "block", marginBottom: 6 }}>{label}</label>
                <input placeholder={label} style={{ width: "100%", height: 46, borderRadius: 8, border: `1.5px solid ${C.border}`, backgroundColor: "#FAFCFB", paddingLeft: 14, paddingRight: 14, fontSize: 14, color: C.textDark, outline: "none", boxSizing: "border-box" }} />
              </div>
            ))}
            <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
              <button onClick={() => setShowForm(false)} style={{ flex: 1, height: 46, borderRadius: 10, backgroundColor: C.bg, color: C.textMid, fontSize: 14, fontWeight: 600, border: `1px solid ${C.border}`, cursor: "pointer" }}>Batal</button>
              <button onClick={() => setShowForm(false)} style={{ flex: 2, height: 46, borderRadius: 10, backgroundColor: C.green, color: "white", fontSize: 14, fontWeight: 700, border: "none", cursor: "pointer" }}>Simpan</button>
            </div>
          </div>
        )}

        {/* Belum Selesai */}
        {belum.length > 0 && (
          <>
            <p style={{ fontSize: 13, fontWeight: 700, color: C.textMid, marginBottom: 8 }}>AKAN DATANG / BELUM SELESAI</p>
            {belum.map((j) => <JadwalCard key={j.id} j={j} />)}
          </>
        )}

        {/* Selesai */}
        {selesai.length > 0 && (
          <>
            <p style={{ fontSize: 13, fontWeight: 700, color: C.textLight, marginTop: 12, marginBottom: 8 }}>SUDAH SELESAI</p>
            {selesai.map((j) => <JadwalCard key={j.id} j={j} />)}
          </>
        )}
      </div>

      <BottomNav active="jadwal" onNavigate={onNavigate} />
    </div>
  );
}