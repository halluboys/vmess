import React from "react";
import { C, GreenHeader, BottomNav, Badge, LeafIcon, formatRupiah } from "../shared";

interface Props {
  onNavigate: (screen: string) => void;
}

const historyData = [
  {
    id: 1,
    tanaman: "Padi Ciherang",
    lahan: "Sawah Timur",
    mulai: "5 Nov 2023",
    selesai: "15 Feb 2024",
    totalBiaya: 1850000,
    totalPanen: "1.200 kg",
    pendapatan: 6600000,
    labaRugi: 4750000,
    status: "untung",
  },
  {
    id: 2,
    tanaman: "Tomat Cherry",
    lahan: "Kebun Bawah",
    mulai: "15 Sep 2023",
    selesai: "20 Nov 2023",
    totalBiaya: 950000,
    totalPanen: "450 kg",
    pendapatan: 1800000,
    labaRugi: 850000,
    status: "untung",
  },
  {
    id: 3,
    tanaman: "Cabai Hijau",
    lahan: "Kebun Tengah",
    mulai: "1 Jun 2023",
    selesai: "10 Sep 2023",
    totalBiaya: 1200000,
    totalPanen: "300 kg",
    pendapatan: 900000,
    labaRugi: -300000,
    status: "rugi",
  },
];

export function HistoryMusimScreen({ onNavigate }: Props) {
  return (
    <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", backgroundColor: C.bg, fontFamily: "'Inter', system-ui, sans-serif" }}>
      <GreenHeader title="History Musim" subtitle={`${historyData.length} musim selesai`} onBack={() => onNavigate("settings")} />

      <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px 24px" }}>

        {/* Summary */}
        <div style={{ backgroundColor: C.white, borderRadius: 14, padding: "14px 16px", boxShadow: "0 1px 4px rgba(0,0,0,0.07)", marginBottom: 16 }}>
          <p style={{ fontSize: 14, fontWeight: 700, color: C.textDark, marginBottom: 10 }}>Ringkasan Semua Musim</p>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
            {[
              { label: "Total Musim", value: "3", color: C.textDark },
              { label: "Total Untung", value: "2", color: C.green },
              { label: "Total Rugi", value: "1", color: C.red },
            ].map((s, i) => (
              <div key={i} style={{ backgroundColor: C.bg, borderRadius: 10, padding: "10px 8px", textAlign: "center" }}>
                <p style={{ fontSize: 18, fontWeight: 800, color: s.color }}>{s.value}</p>
                <p style={{ fontSize: 11, color: C.textLight, marginTop: 2 }}>{s.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* List */}
        <p style={{ fontSize: 13, fontWeight: 700, color: C.textMid, marginBottom: 10 }}>RIWAYAT MUSIM</p>
        {historyData.map((h) => (
          <button
            key={h.id}
            onClick={() => onNavigate("laporan")}
            style={{ width: "100%", backgroundColor: C.white, borderRadius: 14, padding: "16px", boxShadow: "0 1px 4px rgba(0,0,0,0.07)", marginBottom: 10, border: "none", cursor: "pointer", textAlign: "left" }}
          >
            {/* Header */}
            <div style={{ display: "flex", alignItems: "flex-start", gap: 12, marginBottom: 10 }}>
              <div style={{ width: 44, height: 44, borderRadius: 12, backgroundColor: "#F5F5F5", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <LeafIcon size={22} color={C.textLight} />
              </div>
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark }}>{h.tanaman}</p>
                <p style={{ fontSize: 13, color: C.textLight, marginTop: 1 }}>📍 {h.lahan}</p>
                <p style={{ fontSize: 12, color: C.textLight, marginTop: 1 }}>🗓 {h.mulai} – {h.selesai}</p>
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}>
                <Badge label="Selesai" type="default" />
                <Badge label={h.status === "untung" ? "✅ Untung" : "❌ Rugi"} type={h.status === "untung" ? "success" : "danger"} />
              </div>
            </div>

            {/* Stats */}
            <div style={{ backgroundColor: C.bg, borderRadius: 10, padding: "10px 12px" }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
                <div>
                  <p style={{ fontSize: 11, color: C.textLight }}>Total Biaya</p>
                  <p style={{ fontSize: 14, fontWeight: 700, color: C.red }}>{formatRupiah(h.totalBiaya)}</p>
                </div>
                <div>
                  <p style={{ fontSize: 11, color: C.textLight }}>Pendapatan</p>
                  <p style={{ fontSize: 14, fontWeight: 700, color: C.green }}>{formatRupiah(h.pendapatan)}</p>
                </div>
                <div>
                  <p style={{ fontSize: 11, color: C.textLight }}>Hasil Panen</p>
                  <p style={{ fontSize: 13, fontWeight: 600, color: C.textDark }}>{h.totalPanen}</p>
                </div>
                <div>
                  <p style={{ fontSize: 11, color: C.textLight }}>Laba/Rugi</p>
                  <p style={{ fontSize: 14, fontWeight: 700, color: h.labaRugi >= 0 ? C.green : C.red }}>
                    {h.labaRugi >= 0 ? "+" : ""}{formatRupiah(h.labaRugi)}
                  </p>
                </div>
              </div>
            </div>

            <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", marginTop: 10, gap: 4 }}>
              <p style={{ fontSize: 12, color: C.green, fontWeight: 600 }}>Lihat Laporan</p>
              <svg width="16" height="16" viewBox="0 0 20 20" fill="none" stroke={C.green} strokeWidth="2" strokeLinecap="round">
                <path d="M7.5 5l5 5-5 5" />
              </svg>
            </div>
          </button>
        ))}
      </div>

      <BottomNav active="settings" onNavigate={onNavigate} />
    </div>
  );
}
