import React, { useState } from "react";
import { C, GreenHeader, Badge, Card, formatRupiah, MoneyIcon, CalendarIcon, HarvestIcon, ReportIcon, LeafIcon } from "../shared";

interface Props {
  onNavigate: (screen: string) => void;
}

const tabs = ["Biaya", "Jadwal", "Panen", "Rekap", "Laporan"];

const biayaData = [
  { id: 1, kategori: "Bibit", nama: "Bibit Padi IR-64", jumlah: "5 kg", harga: 75000 },
  { id: 2, kategori: "Pupuk", nama: "Urea 50kg", jumlah: "2 sak", harga: 240000 },
  { id: 3, kategori: "Obat", nama: "Pestisida Regent", jumlah: "1 ltr", harga: 85000 },
  { id: 4, kategori: "Tenaga", nama: "Buruh tanam", jumlah: "3 org", harga: 360000 },
];

const jadwalData = [
  { id: 1, kegiatan: "Semprot pestisida", tanggal: "22 Apr 2024", done: false },
  { id: 2, kegiatan: "Pemupukan susulan", tanggal: "18 Apr 2024", done: true },
  { id: 3, kegiatan: "Pengairan sawah", tanggal: "10 Apr 2024", done: true },
];

const panenData = [
  { id: 1, tanggal: "15 Apr 2024", hasil: "180 kg", harga: 5500, total: 990000 },
  { id: 2, tanggal: "8 Apr 2024", hasil: "200 kg", harga: 5500, total: 1100000 },
];

const katColors: Record<string, { bg: string; color: string }> = {
  Bibit: { bg: C.greenSoft, color: C.green },
  Pupuk: { bg: C.blueSoft, color: C.blue },
  Obat: { bg: C.orangeSoft, color: C.orange },
  Tenaga: { bg: C.yellowSoft, color: "#D4A017" },
};

export function DetailTanamScreen({ onNavigate }: Props) {
  const [activeTab, setActiveTab] = useState(0);

  const totalBiaya = biayaData.reduce((s, b) => s + b.harga, 0);
  const totalPanen = panenData.reduce((s, p) => s + p.total, 0);
  const labaRugi = totalPanen - totalBiaya;

  return (
    <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", backgroundColor: C.bg, fontFamily: "'Inter', system-ui, sans-serif" }}>
      {/* Header */}
      <div style={{ background: `linear-gradient(135deg, ${C.green} 0%, #3E9A4D 100%)` }}>
        <div style={{ padding: "10px 20px 0", display: "flex", justifyContent: "space-between" }}>
          <span style={{ color: "white", fontSize: 13, fontWeight: 600 }}>09:41</span>
          <svg width="22" height="12" viewBox="0 0 22 12" fill="white">
            <rect x="0" y="1.5" width="18" height="9" rx="2" stroke="white" strokeWidth="1.2" fill="none" />
            <rect x="1.2" y="2.7" width="13" height="6.6" rx="1" fill="white" />
            <path d="M19 4v4a2 2 0 000-4z" fill="white" />
          </svg>
        </div>
        <div style={{ padding: "8px 16px 0", display: "flex", alignItems: "center", gap: 10 }}>
          <button onClick={() => onNavigate("data-tanam")} style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.2)", border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round">
              <path d="M12.5 15L7.5 10l5-5" />
            </svg>
          </button>
          <div style={{ flex: 1 }}>
            <h1 style={{ color: "white", fontSize: 17, fontWeight: 700 }}>Padi IR-64 – Sawah Barat</h1>
            <div style={{ display: "flex", gap: 6, marginTop: 4 }}>
              <Badge label="Aktif" type="success" />
              <span style={{ color: "rgba(255,255,255,0.8)", fontSize: 12 }}>🗓 Tanam: 10 Mar 2024 • 42 hst</span>
            </div>
          </div>
        </div>

        {/* Mini stat bar */}
        <div style={{ display: "flex", padding: "12px 16px 0", gap: 8 }}>
          {[
            { label: "Total Biaya", value: formatRupiah(totalBiaya), icon: "💸" },
            { label: "Total Panen", value: "380 kg", icon: "🌾" },
            { label: "Laba/Rugi", value: labaRugi >= 0 ? `+${formatRupiah(labaRugi)}` : formatRupiah(labaRugi), icon: "📊" },
          ].map((s, i) => (
            <div key={i} style={{ flex: 1, backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 10, padding: "8px 8px", border: "1px solid rgba(255,255,255,0.2)" }}>
              <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 10, textAlign: "center" }}>{s.icon} {s.label}</p>
              <p style={{ color: "white", fontSize: 13, fontWeight: 700, textAlign: "center", marginTop: 2 }}>{s.value}</p>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", marginTop: 12, paddingLeft: 16, paddingRight: 16 }}>
          {tabs.map((tab, i) => (
            <button
              key={tab}
              onClick={() => setActiveTab(i)}
              style={{
                flex: 1,
                height: 40,
                border: "none",
                backgroundColor: "transparent",
                color: activeTab === i ? "white" : "rgba(255,255,255,0.55)",
                fontSize: 13,
                fontWeight: activeTab === i ? 700 : 400,
                borderBottom: activeTab === i ? "3px solid white" : "3px solid transparent",
                cursor: "pointer",
                padding: 0,
              }}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px 24px" }}>

        {/* BIAYA */}
        {activeTab === 0 && (
          <>
            <div style={{ backgroundColor: C.green, borderRadius: 12, padding: "14px 16px", marginBottom: 14, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <p style={{ color: "rgba(255,255,255,0.8)", fontSize: 12 }}>Total Biaya Produksi</p>
                <p style={{ color: "white", fontSize: 22, fontWeight: 800, marginTop: 2 }}>{formatRupiah(totalBiaya)}</p>
              </div>
              <button onClick={() => onNavigate("biaya")} style={{ backgroundColor: "rgba(255,255,255,0.2)", color: "white", borderRadius: 8, padding: "6px 14px", border: "none", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
                + Tambah
              </button>
            </div>
            {biayaData.map((b) => {
              const ks = katColors[b.kategori] || { bg: "#F5F5F5", color: "#666" };
              return (
                <div key={b.id} style={{ backgroundColor: C.white, borderRadius: 12, padding: "14px 16px", marginBottom: 8, display: "flex", alignItems: "center", gap: 12, boxShadow: "0 1px 3px rgba(0,0,0,0.06)" }}>
                  <div style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: ks.bg, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                    <MoneyIcon size={20} color={ks.color} />
                  </div>
                  <div style={{ flex: 1 }}>
                    <p style={{ fontSize: 14, fontWeight: 600, color: C.textDark }}>{b.nama}</p>
                    <p style={{ fontSize: 12, color: C.textLight, marginTop: 1 }}>{b.jumlah} • {b.kategori}</p>
                  </div>
                  <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark }}>{formatRupiah(b.harga)}</p>
                </div>
              );
            })}
          </>
        )}

        {/* JADWAL */}
        {activeTab === 1 && (
          <>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
              <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark }}>Jadwal Kegiatan</p>
              <button onClick={() => onNavigate("jadwal")} style={{ backgroundColor: C.green, color: "white", borderRadius: 8, padding: "6px 14px", border: "none", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>+ Tambah</button>
            </div>
            {jadwalData.map((j) => (
              <div key={j.id} style={{ backgroundColor: C.white, borderRadius: 12, padding: "14px 16px", marginBottom: 8, display: "flex", alignItems: "center", gap: 12, boxShadow: "0 1px 3px rgba(0,0,0,0.06)" }}>
                <div style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: j.done ? C.greenSoft : C.bg, border: `2px solid ${j.done ? C.green : C.border}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  {j.done && <svg width="14" height="14" viewBox="0 0 20 20" fill="none" stroke={C.green} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M4 10l5 5 7-9" /></svg>}
                </div>
                <div style={{ flex: 1 }}>
                  <p style={{ fontSize: 14, fontWeight: 500, color: j.done ? C.textLight : C.textDark, textDecoration: j.done ? "line-through" : "none" }}>{j.kegiatan}</p>
                  <p style={{ fontSize: 12, color: C.textLight, marginTop: 2 }}>🗓 {j.tanggal}</p>
                </div>
                <Badge label={j.done ? "Selesai" : "Belum"} type={j.done ? "success" : "default"} />
              </div>
            ))}
          </>
        )}

        {/* PANEN */}
        {activeTab === 2 && (
          <>
            <div style={{ backgroundColor: "#FFF9E6", borderRadius: 12, padding: "14px 16px", marginBottom: 14, display: "flex", justifyContent: "space-between", alignItems: "center", border: `1px solid #FFEAA7` }}>
              <div>
                <p style={{ fontSize: 12, color: "#B8860B" }}>Total Pendapatan Panen</p>
                <p style={{ fontSize: 20, fontWeight: 800, color: "#7D5A00", marginTop: 2 }}>{formatRupiah(totalPanen)}</p>
                <p style={{ fontSize: 12, color: "#B8860B", marginTop: 2 }}>380 kg total hasil</p>
              </div>
              <button onClick={() => onNavigate("panen")} style={{ backgroundColor: "#F9A825", color: "white", borderRadius: 8, padding: "6px 14px", border: "none", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>+ Catat</button>
            </div>
            {panenData.map((p) => (
              <div key={p.id} style={{ backgroundColor: C.white, borderRadius: 12, padding: "14px 16px", marginBottom: 8, boxShadow: "0 1px 3px rgba(0,0,0,0.06)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <div>
                    <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark }}>🌾 {p.hasil}</p>
                    <p style={{ fontSize: 12, color: C.textLight, marginTop: 2 }}>🗓 {p.tanggal}</p>
                    <p style={{ fontSize: 12, color: C.textLight, marginTop: 1 }}>Harga: {formatRupiah(p.harga)}/kg</p>
                  </div>
                  <p style={{ fontSize: 16, fontWeight: 800, color: C.green }}>{formatRupiah(p.total)}</p>
                </div>
              </div>
            ))}
          </>
        )}

        {/* REKAP */}
        {activeTab === 3 && (
          <>
            <div style={{ backgroundColor: C.white, borderRadius: 14, padding: 16, boxShadow: "0 1px 4px rgba(0,0,0,0.07)", marginBottom: 12 }}>
              <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark, marginBottom: 12 }}>Ringkasan Musim</p>
              {[
                { label: "Total Biaya", value: formatRupiah(totalBiaya), color: C.red },
                { label: "Total Pendapatan", value: formatRupiah(totalPanen), color: C.green },
                { label: "Laba / Rugi", value: (labaRugi >= 0 ? "+" : "") + formatRupiah(labaRugi), color: labaRugi >= 0 ? C.green : C.red },
              ].map((r, i) => (
                <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: i < 2 ? `1px solid ${C.border}` : "none" }}>
                  <p style={{ fontSize: 14, color: C.textMid }}>{r.label}</p>
                  <p style={{ fontSize: 15, fontWeight: 700, color: r.color }}>{r.value}</p>
                </div>
              ))}
            </div>
            <div style={{ backgroundColor: C.white, borderRadius: 14, padding: 16, boxShadow: "0 1px 4px rgba(0,0,0,0.07)" }}>
              <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark, marginBottom: 12 }}>Rincian Biaya</p>
              {["Bibit", "Pupuk", "Obat", "Tenaga"].map((kat, i) => {
                const total = biayaData.filter(b => b.kategori === kat).reduce((s, b) => s + b.harga, 0);
                const ks = katColors[kat] || { bg: "#F5F5F5", color: "#666" };
                if (!total) return null;
                return (
                  <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 0", borderBottom: i < 3 ? `1px solid ${C.border}` : "none" }}>
                    <div style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: ks.color }} />
                    <p style={{ flex: 1, fontSize: 14, color: C.textMid }}>{kat}</p>
                    <p style={{ fontSize: 14, fontWeight: 600, color: C.textDark }}>{formatRupiah(total)}</p>
                  </div>
                );
              })}
            </div>
          </>
        )}

        {/* LAPORAN */}
        {activeTab === 4 && (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <div style={{ backgroundColor: C.white, borderRadius: 14, padding: 16, boxShadow: "0 1px 4px rgba(0,0,0,0.07)" }}>
              <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark, marginBottom: 4 }}>Laporan Musim Tanam</p>
              <p style={{ fontSize: 13, color: C.textLight }}>Padi IR-64 • Sawah Barat • 10 Mar – Sekarang</p>
              <div style={{ height: 1, backgroundColor: C.border, margin: "12px 0" }} />
              {[
                { label: "Total Biaya Produksi", value: formatRupiah(totalBiaya) },
                { label: "Total Hasil Panen", value: "380 kg" },
                { label: "Total Pendapatan", value: formatRupiah(totalPanen) },
                { label: "Laba / Rugi", value: (labaRugi >= 0 ? "+" : "") + formatRupiah(labaRugi) },
              ].map((r, i) => (
                <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: i < 3 ? `1px solid ${C.border}` : "none" }}>
                  <p style={{ fontSize: 14, color: C.textMid }}>{r.label}</p>
                  <p style={{ fontSize: 14, fontWeight: 700, color: C.textDark }}>{r.value}</p>
                </div>
              ))}
            </div>
            <button
              onClick={() => onNavigate("laporan")}
              style={{ width: "100%", height: 52, borderRadius: 12, backgroundColor: C.red, color: "white", fontSize: 15, fontWeight: 700, border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round">
                <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" />
                <polyline points="14,2 14,8 20,8" />
              </svg>
              Export PDF
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
