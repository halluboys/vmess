import React from "react";
import { C, GreenHeader, ShieldIcon, KeyIcon, Badge } from "../shared";

interface Props {
  onNavigate: (screen: string) => void;
}

export function InfoLisensiScreen({ onNavigate }: Props) {
  const daysLeft = 234;
  const totalDays = 365;
  const pct = Math.round((daysLeft / totalDays) * 100);

  return (
    <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", backgroundColor: C.bg, fontFamily: "'Inter', system-ui, sans-serif" }}>
      <GreenHeader title="Info Lisensi" subtitle="Status aktivasi perangkat" onBack={() => onNavigate("settings")} />

      <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px 24px" }}>

        {/* Status card */}
        <div style={{ background: `linear-gradient(135deg, ${C.green} 0%, #3E9A4D 100%)`, borderRadius: 18, padding: "24px 20px", marginBottom: 16, textAlign: "center" }}>
          <div style={{ width: 72, height: 72, borderRadius: 36, backgroundColor: "rgba(255,255,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 12px", border: "2.5px solid rgba(255,255,255,0.4)" }}>
            <ShieldIcon size={38} color="white" />
          </div>
          <p style={{ color: "rgba(255,255,255,0.85)", fontSize: 14 }}>Status Lisensi</p>
          <p style={{ color: "white", fontSize: 24, fontWeight: 800, marginTop: 4 }}>✅ AKTIF</p>
          <p style={{ color: "rgba(255,255,255,0.8)", fontSize: 13, marginTop: 6 }}>Lisensi Anda valid dan berjalan normal</p>

          {/* Progress bar */}
          <div style={{ backgroundColor: "rgba(255,255,255,0.2)", borderRadius: 8, height: 8, marginTop: 16, overflow: "hidden" }}>
            <div style={{ width: `${pct}%`, height: "100%", backgroundColor: "white", borderRadius: 8, transition: "width 0.5s" }} />
          </div>
          <p style={{ color: "rgba(255,255,255,0.8)", fontSize: 12, marginTop: 6 }}>{daysLeft} hari tersisa dari {totalDays} hari</p>
        </div>

        {/* Detail info */}
        <div style={{ backgroundColor: C.white, borderRadius: 14, padding: "16px", boxShadow: "0 1px 4px rgba(0,0,0,0.07)", marginBottom: 14 }}>
          <p style={{ fontSize: 14, fontWeight: 700, color: C.textDark, marginBottom: 12 }}>Detail Lisensi</p>
          {[
            { label: "Kode Lisensi", value: "YTNI-2024-B8K2", icon: "🔑" },
            { label: "Tanggal Aktivasi", value: "1 April 2024", icon: "📅" },
            { label: "Berlaku Hingga", value: "31 Maret 2025", icon: "⏳" },
            { label: "Durasi Lisensi", value: "1 Tahun (365 hari)", icon: "⌛" },
            { label: "Tipe Lisensi", value: "Personal – 1 Perangkat", icon: "📱" },
          ].map((r, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: i < 4 ? `1px solid ${C.border}` : "none", alignItems: "center" }}>
              <p style={{ fontSize: 13, color: C.textMid }}>{r.icon} {r.label}</p>
              <p style={{ fontSize: 13, fontWeight: 700, color: C.textDark }}>{r.value}</p>
            </div>
          ))}
        </div>

        {/* Device info */}
        <div style={{ backgroundColor: C.white, borderRadius: 14, padding: "16px", boxShadow: "0 1px 4px rgba(0,0,0,0.07)", marginBottom: 14 }}>
          <p style={{ fontSize: 14, fontWeight: 700, color: C.textDark, marginBottom: 12 }}>Info Perangkat</p>
          {[
            { label: "Nama Perangkat", value: "Samsung Galaxy A54" },
            { label: "ID Perangkat", value: "a4f9...b2c1" },
            { label: "Versi Aplikasi", value: "YooTani v1.0.0" },
          ].map((r, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: i < 2 ? `1px solid ${C.border}` : "none" }}>
              <p style={{ fontSize: 13, color: C.textMid }}>{r.label}</p>
              <p style={{ fontSize: 13, fontWeight: 600, color: C.textDark }}>{r.value}</p>
            </div>
          ))}
        </div>

        {/* Note */}
        <div style={{ backgroundColor: C.orangeSoft, borderRadius: 12, padding: "12px 14px", display: "flex", gap: 10, alignItems: "flex-start", marginBottom: 16 }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={C.orange} strokeWidth="2" strokeLinecap="round" style={{ marginTop: 1, flexShrink: 0 }}>
            <circle cx="12" cy="12" r="10" />
            <line x1="12" y1="16" x2="12" y2="12" />
            <line x1="12" y1="8" x2="12.01" y2="8" />
          </svg>
          <div>
            <p style={{ fontSize: 13, fontWeight: 600, color: C.orange, marginBottom: 4 }}>Penting</p>
            <p style={{ fontSize: 12, color: C.orange, lineHeight: 1.6 }}>
              1 lisensi hanya untuk 1 perangkat. Jika pindah perangkat, hubungi admin untuk lisensi baru dan gunakan fitur Restore untuk memulihkan data.
            </p>
          </div>
        </div>

        {/* Contact admin */}
        <button
          style={{ width: "100%", height: 52, borderRadius: 12, backgroundColor: C.white, color: C.green, fontSize: 15, fontWeight: 700, border: `1.5px solid ${C.green}`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={C.green} strokeWidth="2" strokeLinecap="round">
            <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81 19.79 19.79 0 01.01 1.18 2 2 0 012 0h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z" />
          </svg>
          Hubungi Admin
        </button>
      </div>
    </div>
  );
}
