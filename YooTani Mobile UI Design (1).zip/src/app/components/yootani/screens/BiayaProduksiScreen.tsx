import React, { useState } from "react";
import { C, GreenHeader, Badge, formatRupiah, MoneyIcon, PlusIcon } from "../shared";

interface Props {
  onNavigate: (screen: string) => void;
}

const biayaList = [
  { id: 1, kategori: "Bibit", nama: "Bibit Padi IR-64", tanggal: "10 Mar", jumlah: "5 kg", harga: 75000 },
  { id: 2, kategori: "Pupuk", nama: "Urea 50kg", tanggal: "15 Mar", jumlah: "2 sak", harga: 240000 },
  { id: 3, kategori: "Pupuk", nama: "SP-36", tanggal: "15 Mar", jumlah: "1 sak", harga: 130000 },
  { id: 4, kategori: "Obat", nama: "Pestisida Regent", tanggal: "22 Mar", jumlah: "1 ltr", harga: 85000 },
  { id: 5, kategori: "Tenaga", nama: "Buruh tanam", tanggal: "12 Mar", jumlah: "3 orang", harga: 360000 },
  { id: 6, kategori: "Alat", nama: "Tali rafia", tanggal: "11 Mar", jumlah: "2 gulung", harga: 18000 },
];

const katColors: Record<string, { bg: string; color: string; label: string; emoji: string }> = {
  Bibit: { bg: C.greenSoft, color: C.green, label: "Bibit", emoji: "🌱" },
  Pupuk: { bg: C.blueSoft, color: C.blue, label: "Pupuk", emoji: "🧪" },
  Obat: { bg: C.orangeSoft, color: C.orange, label: "Obat/Pestisida", emoji: "💊" },
  Tenaga: { bg: C.yellowSoft, color: "#D4A017", label: "Tenaga Kerja", emoji: "👷" },
  Alat: { bg: "#F3E5F5", color: "#7B1FA2", label: "Alat/Bahan", emoji: "🔧" },
};

const allKat = ["Semua", "Bibit", "Pupuk", "Obat", "Tenaga", "Alat"];

export function BiayaProduksiScreen({ onNavigate }: Props) {
  const [filterKat, setFilterKat] = useState("Semua");
  const [showForm, setShowForm] = useState(false);

  const totalBiaya = biayaList.reduce((s, b) => s + b.harga, 0);
  const filtered = filterKat === "Semua" ? biayaList : biayaList.filter((b) => b.kategori === filterKat);

  // Per-kategori total
  const perKat = Object.entries(
    biayaList.reduce((acc, b) => {
      acc[b.kategori] = (acc[b.kategori] || 0) + b.harga;
      return acc;
    }, {} as Record<string, number>)
  );

  return (
    <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", backgroundColor: C.bg, fontFamily: "'Inter', system-ui, sans-serif" }}>
      <GreenHeader title="Biaya Produksi" subtitle="Padi IR-64 – Sawah Barat" onBack={() => onNavigate("detail-tanam")} />

      <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px 24px" }}>

        {/* Total card */}
        <div style={{ background: `linear-gradient(135deg, ${C.green} 0%, #3E9A4D 100%)`, borderRadius: 16, padding: "18px 20px", marginBottom: 16 }}>
          <p style={{ color: "rgba(255,255,255,0.8)", fontSize: 13 }}>Total Biaya Produksi</p>
          <p style={{ color: "white", fontSize: 28, fontWeight: 800, marginTop: 4 }}>{formatRupiah(totalBiaya)}</p>
          <div style={{ display: "flex", gap: 8, marginTop: 12, flexWrap: "wrap" }}>
            {perKat.map(([kat, total]) => {
              const ks = katColors[kat];
              return (
                <div key={kat} style={{ backgroundColor: "rgba(255,255,255,0.2)", borderRadius: 8, padding: "4px 10px" }}>
                  <p style={{ fontSize: 11, color: "rgba(255,255,255,0.9)", fontWeight: 500 }}>{ks?.emoji} {kat}: {formatRupiah(total)}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Filter pills */}
        <div style={{ display: "flex", gap: 8, overflowX: "auto", marginBottom: 14, paddingBottom: 4 }}>
          {allKat.map((kat) => (
            <button
              key={kat}
              onClick={() => setFilterKat(kat)}
              style={{
                height: 34,
                paddingLeft: 14,
                paddingRight: 14,
                borderRadius: 20,
                backgroundColor: filterKat === kat ? C.green : C.white,
                color: filterKat === kat ? "white" : C.textMid,
                fontSize: 13,
                fontWeight: filterKat === kat ? 600 : 400,
                border: `1px solid ${filterKat === kat ? C.green : C.border}`,
                cursor: "pointer",
                flexShrink: 0,
              }}
            >
              {kat}
            </button>
          ))}
        </div>

        {/* List */}
        {filtered.map((b) => {
          const ks = katColors[b.kategori] || { bg: "#F5F5F5", color: "#666", emoji: "📦" };
          return (
            <div key={b.id} style={{ backgroundColor: C.white, borderRadius: 12, padding: "14px 16px", marginBottom: 8, display: "flex", alignItems: "center", gap: 12, boxShadow: "0 1px 3px rgba(0,0,0,0.06)" }}>
              <div style={{ width: 44, height: 44, borderRadius: 12, backgroundColor: ks.bg, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontSize: 22 }}>
                {ks.emoji}
              </div>
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: 14, fontWeight: 600, color: C.textDark }}>{b.nama}</p>
                <p style={{ fontSize: 12, color: C.textLight, marginTop: 2 }}>📦 {b.jumlah} • 🗓 {b.tanggal}</p>
                <Badge label={b.kategori} type={b.kategori === "Bibit" ? "success" : b.kategori === "Pupuk" ? "info" : b.kategori === "Obat" ? "warning" : "default"} />
              </div>
              <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark }}>{formatRupiah(b.harga)}</p>
            </div>
          );
        })}

        {/* Add button */}
        {!showForm && (
          <button
            onClick={() => setShowForm(true)}
            style={{ width: "100%", height: 52, borderRadius: 12, backgroundColor: C.greenSoft, color: C.green, fontSize: 15, fontWeight: 700, border: `1.5px dashed ${C.greenLight}`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 4 }}
          >
            <PlusIcon size={20} color={C.green} />
            Tambah Biaya
          </button>
        )}

        {/* Simple Form */}
        {showForm && (
          <div style={{ backgroundColor: C.white, borderRadius: 14, padding: 16, boxShadow: "0 2px 8px rgba(0,0,0,0.1)", marginTop: 4 }}>
            <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark, marginBottom: 14 }}>Tambah Biaya</p>
            {["Nama Barang/Kegiatan", "Kategori", "Jumlah/Volume", "Harga (Rp)"].map((label, i) => (
              <div key={i} style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 13, fontWeight: 600, color: C.textMid, display: "block", marginBottom: 6 }}>{label}</label>
                <input
                  placeholder={label}
                  style={{ width: "100%", height: 46, borderRadius: 8, border: `1.5px solid ${C.border}`, backgroundColor: "#FAFCFB", paddingLeft: 14, paddingRight: 14, fontSize: 14, color: C.textDark, outline: "none", boxSizing: "border-box" }}
                />
              </div>
            ))}
            <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
              <button onClick={() => setShowForm(false)} style={{ flex: 1, height: 46, borderRadius: 10, backgroundColor: C.bg, color: C.textMid, fontSize: 14, fontWeight: 600, border: `1px solid ${C.border}`, cursor: "pointer" }}>Batal</button>
              <button onClick={() => setShowForm(false)} style={{ flex: 2, height: 46, borderRadius: 10, backgroundColor: C.green, color: "white", fontSize: 14, fontWeight: 700, border: "none", cursor: "pointer" }}>Simpan</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
