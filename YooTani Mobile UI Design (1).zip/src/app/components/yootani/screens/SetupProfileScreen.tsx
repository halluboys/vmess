import React, { useState } from "react";
import { C, StatusBar, UserIcon, PlusIcon } from "../shared";

interface Props {
  onSaved: () => void;
}

export function SetupProfileScreen({ onSaved }: Props) {
  const [nama, setNama] = useState("");
  const [hp, setHp] = useState("");
  const [desa, setDesa] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const errors = {
    nama: submitted && !nama.trim() ? "Nama wajib diisi" : "",
    hp: submitted && !hp.trim() ? "Nomor HP wajib diisi" : "",
    desa: submitted && !desa.trim() ? "Desa / alamat wajib diisi" : "",
  };

  function handleSave() {
    setSubmitted(true);
    if (!nama.trim() || !hp.trim() || !desa.trim()) return;
    onSaved();
  }

  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        backgroundColor: C.bg,
        fontFamily: "'Inter', system-ui, sans-serif",
        overflowY: "auto",
      }}
    >
      {/* Header */}
      <div style={{ backgroundColor: C.green }}>
        <div style={{ padding: "10px 20px 8px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ color: "white", fontSize: 13, fontWeight: 600 }}>09:41</span>
          <div style={{ display: "flex", gap: 6 }}>
            <svg width="22" height="12" viewBox="0 0 22 12" fill="white">
              <rect x="0" y="1.5" width="18" height="9" rx="2" stroke="white" strokeWidth="1.2" fill="none" />
              <rect x="1.2" y="2.7" width="13" height="6.6" rx="1" fill="white" />
              <path d="M19 4v4a2 2 0 000-4z" fill="white" />
            </svg>
          </div>
        </div>
        <div style={{ padding: "8px 20px 24px" }}>
          <h1 style={{ color: "white", fontSize: 20, fontWeight: 700 }}>Data Petani</h1>
          <p style={{ color: "rgba(255,255,255,0.8)", fontSize: 14, marginTop: 2 }}>
            Lengkapi profil sebelum mulai
          </p>
        </div>
      </div>

      {/* Wave */}
      <div style={{ marginTop: -1, lineHeight: 0 }}>
        <svg width="100%" height="28" viewBox="0 0 390 28" preserveAspectRatio="none" fill={C.green}>
          <path d="M0 0 Q97.5 28 195 14 Q292.5 0 390 28 L390 0 Z" />
        </svg>
      </div>

      <div style={{ flex: 1, padding: "8px 20px 24px" }}>
        {/* Avatar upload area */}
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", marginBottom: 28 }}>
          <div
            style={{
              width: 88,
              height: 88,
              borderRadius: 44,
              backgroundColor: C.greenSoft,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              border: `2.5px dashed ${C.greenLight}`,
              marginBottom: 8,
              position: "relative",
            }}
          >
            <UserIcon size={40} color={C.greenMid} />
            <div
              style={{
                position: "absolute",
                bottom: 0,
                right: 0,
                width: 28,
                height: 28,
                borderRadius: 14,
                backgroundColor: C.green,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                border: "2px solid white",
              }}
            >
              <PlusIcon size={14} color="white" />
            </div>
          </div>
          <p style={{ fontSize: 13, color: C.textLight }}>Foto Profil (opsional)</p>
        </div>

        {/* Form */}
        <div
          style={{
            backgroundColor: C.white,
            borderRadius: 16,
            padding: 20,
            boxShadow: "0 2px 8px rgba(0,0,0,0.06)",
            display: "flex",
            flexDirection: "column",
            gap: 20,
            marginBottom: 24,
          }}
        >
          {/* Nama */}
          <div>
            <label style={{ fontSize: 14, fontWeight: 600, color: C.textMid, display: "block", marginBottom: 8 }}>
              Nama Petani <span style={{ color: C.red }}>*</span>
            </label>
            <div style={{ position: "relative" }}>
              <div style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)" }}>
                <UserIcon size={18} color={C.textLight} />
              </div>
              <input
                value={nama}
                onChange={(e) => setNama(e.target.value)}
                placeholder="Masukkan nama lengkap"
                style={{
                  width: "100%",
                  height: 52,
                  borderRadius: 10,
                  border: `1.5px solid ${errors.nama ? C.red : C.border}`,
                  backgroundColor: errors.nama ? C.redSoft : "#FAFCFB",
                  paddingLeft: 44,
                  paddingRight: 16,
                  fontSize: 15,
                  color: C.textDark,
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>
            {errors.nama && <p style={{ fontSize: 12, color: C.red, marginTop: 4 }}>{errors.nama}</p>}
          </div>

          {/* No HP */}
          <div>
            <label style={{ fontSize: 14, fontWeight: 600, color: C.textMid, display: "block", marginBottom: 8 }}>
              No. HP / WhatsApp <span style={{ color: C.red }}>*</span>
            </label>
            <div style={{ position: "relative" }}>
              <div style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)" }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={C.textLight} strokeWidth="2" strokeLinecap="round">
                  <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81 19.79 19.79 0 01.01 1.18 2 2 0 012 0h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z" />
                </svg>
              </div>
              <input
                value={hp}
                onChange={(e) => setHp(e.target.value)}
                placeholder="08xxxxxxxxxx"
                type="tel"
                style={{
                  width: "100%",
                  height: 52,
                  borderRadius: 10,
                  border: `1.5px solid ${errors.hp ? C.red : C.border}`,
                  backgroundColor: errors.hp ? C.redSoft : "#FAFCFB",
                  paddingLeft: 44,
                  paddingRight: 16,
                  fontSize: 15,
                  color: C.textDark,
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>
            {errors.hp && <p style={{ fontSize: 12, color: C.red, marginTop: 4 }}>{errors.hp}</p>}
          </div>

          {/* Desa */}
          <div>
            <label style={{ fontSize: 14, fontWeight: 600, color: C.textMid, display: "block", marginBottom: 8 }}>
              Desa / Alamat <span style={{ color: C.red }}>*</span>
            </label>
            <div style={{ position: "relative" }}>
              <div style={{ position: "absolute", left: 14, top: 16 }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={C.textLight} strokeWidth="2" strokeLinecap="round">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" />
                  <circle cx="12" cy="10" r="3" />
                </svg>
              </div>
              <textarea
                value={desa}
                onChange={(e) => setDesa(e.target.value)}
                placeholder="Desa Sukamaju, Kec. Ciwidey..."
                rows={3}
                style={{
                  width: "100%",
                  borderRadius: 10,
                  border: `1.5px solid ${errors.desa ? C.red : C.border}`,
                  backgroundColor: errors.desa ? C.redSoft : "#FAFCFB",
                  paddingLeft: 44,
                  paddingRight: 16,
                  paddingTop: 14,
                  paddingBottom: 14,
                  fontSize: 15,
                  color: C.textDark,
                  outline: "none",
                  resize: "none",
                  fontFamily: "'Inter', system-ui, sans-serif",
                  boxSizing: "border-box",
                }}
              />
            </div>
            {errors.desa && <p style={{ fontSize: 12, color: C.red, marginTop: 4 }}>{errors.desa}</p>}
          </div>
        </div>

        {/* Save Button */}
        <button
          onClick={handleSave}
          style={{
            width: "100%",
            height: 56,
            borderRadius: 14,
            backgroundColor: C.green,
            color: "white",
            fontSize: 17,
            fontWeight: 700,
            border: "none",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            boxShadow: "0 4px 16px rgba(45,122,58,0.3)",
          }}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M22 11.08V12a10 10 0 11-5.93-9.14" />
            <polyline points="22 4 12 14.01 9 11.01" />
          </svg>
          Simpan & Mulai
        </button>

        <p style={{ fontSize: 12, color: C.textLight, textAlign: "center", marginTop: 12, lineHeight: 1.6 }}>
          Data Anda tersimpan aman di perangkat ini
        </p>
      </div>
    </div>
  );
}
