import React, { useState } from "react";
import { C, GreenHeader, formatRupiah, PlusIcon } from "../shared";

interface Props {
  onNavigate: (screen: string) => void;
}

const panenData = [
  { id: 1, tanggal: "15 Apr 2024", hasil: 180, satuan: "kg", harga: 5500, catatan: "Kualitas bagus, musim kering" },
  { id: 2, tanggal: "8 Apr 2024", hasil: 200, satuan: "kg", harga: 5500, catatan: "" },
];

export function HasilPanenScreen({ onNavigate }: Props) {
  const [showForm, setShowForm] = useState(false);

  const totalHasil = panenData.reduce((s, p) => s + p.hasil, 0);
  const totalPendapatan = panenData.reduce((s, p) => s + p.hasil * p.harga, 0);

  return (
    <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", backgroundColor: C.bg, fontFamily: "'Inter', system-ui, sans-serif" }}>
      <GreenHeader title="Hasil Panen" subtitle="Padi IR-64 – Sawah Barat" onBack={() => onNavigate("detail-tanam")} />

      <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px 24px" }}>

        {/* Summary card */}
        <div style={{ background: "linear-gradient(135deg, #F9A825 0%, #E65100 100%)", borderRadius: 16, padding: "18px 20px", marginBottom: 16 }}>
          <p style={{ color: "rgba(255,255,255,0.85)", fontSize: 13 }}>Total Hasil Panen</p>
          <p style={{ color: "white", fontSize: 32, fontWeight: 800, marginTop: 4 }}>{totalHasil} kg</p>
          <div style={{ height: 1, backgroundColor: "rgba(255,255,255,0.25)", margin: "12px 0" }} />
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <div>
              <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 12 }}>Total Pendapatan</p>
              <p style={{ color: "white", fontSize: 18, fontWeight: 700, marginTop: 2 }}>{formatRupiah(totalPendapatan)}</p>
            </div>
            <div>
              <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 12, textAlign: "right" }}>Harga Rata-rata</p>
              <p style={{ color: "white", fontSize: 18, fontWeight: 700, marginTop: 2, textAlign: "right" }}>Rp 5.500/kg</p>
            </div>
          </div>
        </div>

        {/* Records */}
        {panenData.map((p, idx) => (
          <div key={p.id} style={{ backgroundColor: C.white, borderRadius: 14, padding: "16px", marginBottom: 10, boxShadow: "0 1px 4px rgba(0,0,0,0.07)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
              <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                <div style={{ width: 44, height: 44, borderRadius: 12, backgroundColor: "#FFF9E6", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>
                  🌾
                </div>
                <div>
                  <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark }}>Panen ke-{panenData.length - idx}</p>
                  <p style={{ fontSize: 13, color: C.textLight }}>🗓 {p.tanggal}</p>
                </div>
              </div>
              <div style={{ textAlign: "right" }}>
                <p style={{ fontSize: 20, fontWeight: 800, color: "#E65100" }}>{p.hasil} kg</p>
                <p style={{ fontSize: 12, color: C.textLight }}>= {formatRupiah(p.hasil * p.harga)}</p>
              </div>
            </div>
            <div style={{ backgroundColor: C.bg, borderRadius: 10, padding: "10px 14px" }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <p style={{ fontSize: 13, color: C.textMid }}>Harga Jual</p>
                <p style={{ fontSize: 13, fontWeight: 600, color: C.textDark }}>{formatRupiah(p.harga)}/kg</p>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4 }}>
                <p style={{ fontSize: 13, color: C.textMid }}>Total Nilai</p>
                <p style={{ fontSize: 14, fontWeight: 700, color: C.green }}>{formatRupiah(p.hasil * p.harga)}</p>
              </div>
              {p.catatan && (
                <div style={{ marginTop: 8, paddingTop: 8, borderTop: `1px solid ${C.border}` }}>
                  <p style={{ fontSize: 12, color: C.textLight }}>📝 {p.catatan}</p>
                </div>
              )}
            </div>
          </div>
        ))}

        {/* Add Form */}
        {showForm && (
          <div style={{ backgroundColor: C.white, borderRadius: 14, padding: 16, boxShadow: "0 2px 8px rgba(0,0,0,0.1)", marginTop: 4 }}>
            <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark, marginBottom: 14 }}>Catat Hasil Panen</p>
            {["Tanggal Panen", "Jumlah Hasil (kg)", "Harga Jual per kg (Rp)", "Catatan (opsional)"].map((label, i) => (
              <div key={i} style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 13, fontWeight: 600, color: C.textMid, display: "block", marginBottom: 6 }}>{label}</label>
                <input placeholder={label} style={{ width: "100%", height: 46, borderRadius: 8, border: `1.5px solid ${C.border}`, backgroundColor: "#FAFCFB", paddingLeft: 14, paddingRight: 14, fontSize: 14, color: C.textDark, outline: "none", boxSizing: "border-box" }} />
              </div>
            ))}
            <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
              <button onClick={() => setShowForm(false)} style={{ flex: 1, height: 46, borderRadius: 10, backgroundColor: C.bg, color: C.textMid, fontSize: 14, fontWeight: 600, border: `1px solid ${C.border}`, cursor: "pointer" }}>Batal</button>
              <button onClick={() => setShowForm(false)} style={{ flex: 2, height: 46, borderRadius: 10, backgroundColor: "#F9A825", color: "white", fontSize: 14, fontWeight: 700, border: "none", cursor: "pointer" }}>🌾 Simpan Panen</button>
            </div>
          </div>
        )}

        {/* Add button */}
        {!showForm && (
          <button
            onClick={() => setShowForm(true)}
            style={{ width: "100%", height: 52, borderRadius: 12, backgroundColor: "#FFF9E6", color: "#E65100", fontSize: 15, fontWeight: 700, border: "1.5px dashed #FFB74D", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 4 }}
          >
            <PlusIcon size={20} color="#E65100" />
            Catat Hasil Panen
          </button>
        )}
      </div>
    </div>
  );
}
