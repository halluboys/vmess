import React from "react";
import { C, GreenHeader, BottomNav, formatRupiah } from "../shared";

interface Props {
  onNavigate: (screen: string) => void;
}

const biayaDetail = [
  { label: "Bibit", emoji: "🌱", total: 75000, pct: 9 },
  { label: "Pupuk", emoji: "🧪", total: 370000, pct: 44 },
  { label: "Obat/Pestisida", emoji: "💊", total: 85000, pct: 10 },
  { label: "Tenaga Kerja", emoji: "👷", total: 360000, pct: 43 },
  { label: "Alat/Bahan", emoji: "🔧", total: 18000, pct: 2 },
];

const totalBiaya = biayaDetail.reduce((s, b) => s + b.total, 0);
const totalPanen = 2090000;
const labaRugi = totalPanen - totalBiaya;

const barColors = [C.green, C.blue, C.orange, "#D4A017", "#7B1FA2"];

export function LaporanScreen({ onNavigate }: Props) {
  return (
    <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", backgroundColor: C.bg, fontFamily: "'Inter', system-ui, sans-serif" }}>
      <GreenHeader
        title="Laporan Musim"
        subtitle="Padi IR-64 • Mar – Apr 2024"
        onBack={() => onNavigate("dashboard")}
        rightElement={
          <button style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.2)", border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round">
              <circle cx="12" cy="12" r="1" /><circle cx="19" cy="12" r="1" /><circle cx="5" cy="12" r="1" />
            </svg>
          </button>
        }
      />

      <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px 24px" }}>

        {/* Main summary */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
          <div style={{ backgroundColor: C.white, borderRadius: 14, padding: "14px 16px", boxShadow: "0 1px 4px rgba(0,0,0,0.07)", gridColumn: "1 / -1" }}>
            <p style={{ fontSize: 13, color: C.textLight }}>Laba / Rugi Musim Ini</p>
            <p style={{ fontSize: 30, fontWeight: 800, color: labaRugi >= 0 ? C.green : C.red, marginTop: 4 }}>
              {labaRugi >= 0 ? "+" : ""}{formatRupiah(labaRugi)}
            </p>
            <p style={{ fontSize: 13, color: C.textLight, marginTop: 4 }}>
              {labaRugi >= 0 ? "✅ Musim ini UNTUNG" : "❌ Musim ini RUGI"}
            </p>
          </div>
          <div style={{ backgroundColor: C.redSoft, borderRadius: 14, padding: "14px 16px", boxShadow: "0 1px 4px rgba(0,0,0,0.05)" }}>
            <p style={{ fontSize: 11, color: C.red }}>Total Biaya</p>
            <p style={{ fontSize: 18, fontWeight: 800, color: C.red, marginTop: 4 }}>{formatRupiah(totalBiaya)}</p>
          </div>
          <div style={{ backgroundColor: C.greenSoft, borderRadius: 14, padding: "14px 16px", boxShadow: "0 1px 4px rgba(0,0,0,0.05)" }}>
            <p style={{ fontSize: 11, color: C.green }}>Total Pendapatan</p>
            <p style={{ fontSize: 18, fontWeight: 800, color: C.green, marginTop: 4 }}>{formatRupiah(totalPanen)}</p>
          </div>
        </div>

        {/* Info lahan & tanaman */}
        <div style={{ backgroundColor: C.white, borderRadius: 14, padding: "14px 16px", boxShadow: "0 1px 4px rgba(0,0,0,0.07)", marginBottom: 14 }}>
          <p style={{ fontSize: 14, fontWeight: 700, color: C.textDark, marginBottom: 10 }}>Info Musim Tanam</p>
          {[
            { label: "Lahan", value: "Sawah Barat" },
            { label: "Tanaman", value: "Padi IR-64" },
            { label: "Tanggal Tanam", value: "10 Maret 2024" },
            { label: "Lama Musim", value: "42 hari (berjalan)" },
            { label: "Jumlah Tanaman", value: "5.000 batang" },
            { label: "Total Panen", value: "380 kg (2 kali panen)" },
          ].map((r, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "7px 0", borderBottom: i < 5 ? `1px solid ${C.border}` : "none" }}>
              <p style={{ fontSize: 13, color: C.textLight }}>{r.label}</p>
              <p style={{ fontSize: 13, fontWeight: 600, color: C.textDark, textAlign: "right", maxWidth: "55%" }}>{r.value}</p>
            </div>
          ))}
        </div>

        {/* Biaya breakdown */}
        <div style={{ backgroundColor: C.white, borderRadius: 14, padding: "14px 16px", boxShadow: "0 1px 4px rgba(0,0,0,0.07)", marginBottom: 14 }}>
          <p style={{ fontSize: 14, fontWeight: 700, color: C.textDark, marginBottom: 12 }}>Rincian Biaya Produksi</p>
          {biayaDetail.map((b, i) => (
            <div key={i} style={{ marginBottom: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                <span style={{ fontSize: 13, color: C.textMid }}>{b.emoji} {b.label}</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: C.textDark }}>{formatRupiah(b.total)}</span>
              </div>
              {/* Progress bar */}
              <div style={{ height: 6, backgroundColor: C.bg, borderRadius: 3, overflow: "hidden" }}>
                <div style={{ height: "100%", width: `${b.pct}%`, backgroundColor: barColors[i], borderRadius: 3, transition: "width 0.5s" }} />
              </div>
            </div>
          ))}
          <div style={{ display: "flex", justifyContent: "space-between", paddingTop: 10, borderTop: `1px solid ${C.border}` }}>
            <span style={{ fontSize: 14, fontWeight: 700, color: C.textDark }}>Total</span>
            <span style={{ fontSize: 16, fontWeight: 800, color: C.red }}>{formatRupiah(totalBiaya)}</span>
          </div>
        </div>

        {/* Panen breakdown */}
        <div style={{ backgroundColor: C.white, borderRadius: 14, padding: "14px 16px", boxShadow: "0 1px 4px rgba(0,0,0,0.07)", marginBottom: 16 }}>
          <p style={{ fontSize: 14, fontWeight: 700, color: C.textDark, marginBottom: 10 }}>Rekap Panen</p>
          {[
            { tanggal: "15 Apr 2024", hasil: "180 kg", nilai: formatRupiah(990000) },
            { tanggal: "8 Apr 2024", hasil: "200 kg", nilai: formatRupiah(1100000) },
          ].map((p, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: i < 1 ? `1px solid ${C.border}` : "none" }}>
              <div>
                <p style={{ fontSize: 14, fontWeight: 600, color: C.textDark }}>🌾 {p.hasil}</p>
                <p style={{ fontSize: 12, color: C.textLight }}>🗓 {p.tanggal}</p>
              </div>
              <p style={{ fontSize: 15, fontWeight: 700, color: C.green }}>{p.nilai}</p>
            </div>
          ))}
        </div>

        {/* Export PDF */}
        <button
          style={{
            width: "100%",
            height: 56,
            borderRadius: 14,
            backgroundColor: C.red,
            color: "white",
            fontSize: 17,
            fontWeight: 700,
            border: "none",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 10,
            boxShadow: "0 4px 16px rgba(211,47,47,0.3)",
          }}
        >
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round">
            <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" />
            <polyline points="14,2 14,8 20,8" />
            <line x1="16" y1="13" x2="8" y2="13" />
            <line x1="16" y1="17" x2="8" y2="17" />
          </svg>
          Export Laporan PDF
        </button>
      </div>

      <BottomNav active="laporan" onNavigate={onNavigate} />
    </div>
  );
}
