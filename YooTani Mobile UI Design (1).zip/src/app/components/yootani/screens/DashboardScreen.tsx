import React from "react";
import {
  C, Card, Badge, SectionTitle, BottomNav,
  MoneyIcon, HarvestIcon, CalendarIcon, SeedIcon, PlusIcon,
  formatRupiah, LeafIcon,
} from "../shared";

interface Props {
  onNavigate: (screen: string) => void;
}

const quickActions = [
  {
    key: "data-tanam",
    label: "Tambah\nData Tanam",
    icon: SeedIcon,
    bg: C.greenSoft,
    color: C.green,
  },
  {
    key: "biaya",
    label: "Catat\nBiaya",
    icon: MoneyIcon,
    bg: C.orangeSoft,
    color: C.orange,
  },
  {
    key: "panen",
    label: "Catat\nPanen",
    icon: HarvestIcon,
    bg: C.yellowSoft,
    color: "#D4A017",
  },
  {
    key: "jadwal",
    label: "Tambah\nJadwal",
    icon: CalendarIcon,
    bg: C.blueSoft,
    color: C.blue,
  },
];

const jadwalHariIni = [
  { id: 1, kegiatan: "Semprot pestisida – Lahan Barat", jam: "07:00", done: false },
  { id: 2, kegiatan: "Pemupukan susulan – Lahan Timur", jam: "10:00", done: true },
];

const tanamAktif = [
  {
    id: 1,
    lahan: "Lahan Sawah Barat",
    tanaman: "Padi IR-64",
    tanggal: "10 Mar 2024",
    status: "Vegetatif",
    umur: "42 hst",
  },
  {
    id: 2,
    lahan: "Kebun Atas",
    tanaman: "Cabai Merah",
    tanggal: "20 Feb 2024",
    status: "Berbuah",
    umur: "60 hst",
  },
];

export function DashboardScreen({ onNavigate }: Props) {
  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        backgroundColor: C.bg,
        fontFamily: "'Inter', system-ui, sans-serif",
      }}
    >
      {/* Scrollable content */}
      <div style={{ flex: 1, overflowY: "auto" }}>
        {/* Green Header */}
        <div
          style={{
            background: `linear-gradient(135deg, ${C.green} 0%, #3E9A4D 100%)`,
            paddingBottom: 28,
          }}
        >
          {/* Status bar */}
          <div style={{ padding: "10px 20px 0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ color: "white", fontSize: 13, fontWeight: 600 }}>09:41</span>
            <div style={{ display: "flex", gap: 6 }}>
              <svg width="22" height="12" viewBox="0 0 22 12" fill="white">
                <rect x="0" y="1.5" width="18" height="9" rx="2" stroke="white" strokeWidth="1.2" fill="none" />
                <rect x="1.2" y="2.7" width="13" height="6.6" rx="1" fill="white" />
                <path d="M19 4v4a2 2 0 000-4z" fill="white" />
              </svg>
            </div>
          </div>

          {/* Greeting */}
          <div style={{ padding: "16px 20px 0" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div>
                <p style={{ color: "rgba(255,255,255,0.8)", fontSize: 14 }}>Selamat pagi 👋</p>
                <h2 style={{ color: "white", fontSize: 22, fontWeight: 700, marginTop: 2 }}>Pak Budi</h2>
                <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 13, marginTop: 2 }}>Ds. Sukamaju, Ciwidey</p>
              </div>
              {/* Avatar */}
              <div
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: 24,
                  backgroundColor: "rgba(255,255,255,0.2)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  border: "2px solid rgba(255,255,255,0.4)",
                }}
              >
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round">
                  <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
                  <circle cx="12" cy="7" r="4" />
                </svg>
              </div>
            </div>
          </div>

          {/* Stats Row */}
          <div style={{ display: "flex", gap: 10, padding: "20px 20px 0", marginTop: 4 }}>
            {[
              { label: "Musim Aktif", value: "2" },
              { label: "Total Biaya", value: "Rp 2,4jt" },
              { label: "Panen Bulan Ini", value: "380 kg" },
            ].map((s, i) => (
              <div
                key={i}
                style={{
                  flex: 1,
                  backgroundColor: "rgba(255,255,255,0.15)",
                  borderRadius: 12,
                  padding: "12px 10px",
                  backdropFilter: "blur(4px)",
                  border: "1px solid rgba(255,255,255,0.2)",
                }}
              >
                <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 11, textAlign: "center" }}>{s.label}</p>
                <p style={{ color: "white", fontSize: 16, fontWeight: 700, textAlign: "center", marginTop: 4 }}>
                  {s.value}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Wave */}
        <div style={{ marginTop: -1, lineHeight: 0, background: C.bg }}>
          <svg width="100%" height="28" viewBox="0 0 390 28" preserveAspectRatio="none">
            <path d="M0 0 Q97.5 28 195 14 Q292.5 0 390 28 L390 0 Z" fill={`linear-gradient(135deg, ${C.green} 0%, #3E9A4D 100%)`} />
            <path d="M0 0 Q97.5 28 195 14 Q292.5 0 390 28 L390 0 Z" fill={C.green} />
          </svg>
        </div>

        <div style={{ padding: "0 16px 100px" }}>

          {/* Quick Actions */}
          <div style={{ marginBottom: 20 }}>
            <SectionTitle title="Aksi Cepat" />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 10 }}>
              {quickActions.map((action) => {
                const Icon = action.icon;
                return (
                  <button
                    key={action.key}
                    onClick={() => onNavigate(action.key)}
                    style={{
                      backgroundColor: C.white,
                      borderRadius: 12,
                      padding: "14px 6px",
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      gap: 8,
                      boxShadow: "0 1px 4px rgba(0,0,0,0.07)",
                      border: "none",
                      cursor: "pointer",
                    }}
                  >
                    <div
                      style={{
                        width: 44,
                        height: 44,
                        borderRadius: 12,
                        backgroundColor: action.bg,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <Icon size={22} color={action.color} />
                    </div>
                    <p
                      style={{
                        fontSize: 11,
                        fontWeight: 600,
                        color: C.textMid,
                        textAlign: "center",
                        lineHeight: 1.4,
                        whiteSpace: "pre-line",
                      }}
                    >
                      {action.label}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Jadwal Hari Ini */}
          <div style={{ marginBottom: 20 }}>
            <SectionTitle title="Jadwal Hari Ini" action="Lihat Semua" onAction={() => onNavigate("jadwal")} />
            <div
              style={{
                backgroundColor: C.white,
                borderRadius: 14,
                boxShadow: "0 1px 4px rgba(0,0,0,0.07)",
                overflow: "hidden",
              }}
            >
              {jadwalHariIni.map((j, idx) => (
                <div
                  key={j.id}
                  style={{
                    padding: "14px 16px",
                    display: "flex",
                    alignItems: "center",
                    gap: 12,
                    borderBottom: idx < jadwalHariIni.length - 1 ? `1px solid ${C.border}` : "none",
                  }}
                >
                  {/* Check circle */}
                  <div
                    style={{
                      width: 32,
                      height: 32,
                      borderRadius: 16,
                      backgroundColor: j.done ? C.greenSoft : C.bg,
                      border: `2px solid ${j.done ? C.green : C.border}`,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flexShrink: 0,
                    }}
                  >
                    {j.done && (
                      <svg width="14" height="14" viewBox="0 0 20 20" fill="none" stroke={C.green} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M4 10l5 5 7-9" />
                      </svg>
                    )}
                  </div>
                  <div style={{ flex: 1 }}>
                    <p
                      style={{
                        fontSize: 14,
                        fontWeight: 500,
                        color: j.done ? C.textLight : C.textDark,
                        textDecoration: j.done ? "line-through" : "none",
                      }}
                    >
                      {j.kegiatan}
                    </p>
                    <p style={{ fontSize: 12, color: C.textLight, marginTop: 2 }}>🕐 {j.jam}</p>
                  </div>
                  <Badge label={j.done ? "Selesai" : "Belum"} type={j.done ? "success" : "default"} />
                </div>
              ))}
            </div>
          </div>

          {/* Data Tanam Aktif */}
          <div>
            <SectionTitle title="Musim Tanam Aktif" action="Lihat Semua" onAction={() => onNavigate("data-tanam")} />
            {tanamAktif.map((t) => (
              <button
                key={t.id}
                onClick={() => onNavigate("detail-tanam")}
                style={{
                  width: "100%",
                  backgroundColor: C.white,
                  borderRadius: 14,
                  padding: "14px 16px",
                  boxShadow: "0 1px 4px rgba(0,0,0,0.07)",
                  marginBottom: 10,
                  display: "flex",
                  alignItems: "center",
                  gap: 14,
                  border: "none",
                  cursor: "pointer",
                  textAlign: "left",
                }}
              >
                {/* Plant icon */}
                <div
                  style={{
                    width: 48,
                    height: 48,
                    borderRadius: 14,
                    backgroundColor: C.greenSoft,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexShrink: 0,
                  }}
                >
                  <LeafIcon size={24} color={C.green} />
                </div>
                <div style={{ flex: 1 }}>
                  <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark }}>{t.tanaman}</p>
                  <p style={{ fontSize: 13, color: C.textLight, marginTop: 2 }}>📍 {t.lahan}</p>
                  <div style={{ display: "flex", gap: 6, marginTop: 6 }}>
                    <Badge label={t.status} type="success" />
                    <Badge label={t.umur} type="info" />
                  </div>
                </div>
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke={C.textLight} strokeWidth="2" strokeLinecap="round">
                  <path d="M7.5 5l5 5-5 5" />
                </svg>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Nav */}
      <BottomNav active="dashboard" onNavigate={onNavigate} />
    </div>
  );
}
