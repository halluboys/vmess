import React, { useState } from "react";
import { C, GreenHeader, BottomNav, Badge, LeafIcon, PlusIcon, TrashIcon, EditIcon } from "../shared";

interface Props {
  onNavigate: (screen: string) => void;
}

// ─── Master data ──────────────────────────────────────────────────────────────
const lahanList = [
  { id: 1, nama: "Lahan Sawah Barat", ukuran: "0.5 ha" },
  { id: 2, nama: "Kebun Atas", ukuran: "0.25 ha" },
  { id: 3, nama: "Lahan Sawah Timur", ukuran: "0.4 ha" },
  { id: 4, nama: "Kebun Bawah", ukuran: "0.3 ha" },
];

const tanamanList = [
  { id: 1, nama: "Padi", varietas: ["IR-64", "Ciherang", "Situbagendit", "Inpari 32"], emoji: "🌾" },
  { id: 2, nama: "Cabai Merah", varietas: ["Keriting", "TM-999", "Hot Beauty"], emoji: "🌶️" },
  { id: 3, nama: "Tomat", varietas: ["Cherry", "Beef Tomato", "Servo"], emoji: "🍅" },
  { id: 4, nama: "Jagung", varietas: ["P-35", "Bisi-18", "NK-212"], emoji: "🌽" },
  { id: 5, nama: "Bayam", varietas: ["Lokal", "Hijau Bangkok"], emoji: "🥬" },
  { id: 6, nama: "Kacang Panjang", varietas: ["Lokal", "Lebat-1"], emoji: "🫘" },
];

const satuanList = ["batang", "biji", "kg bibit", "gram bibit", "polybag", "stek"];

// ─── Types ────────────────────────────────────────────────────────────────────
interface MusimItem {
  id: number;
  lahan: string;
  tanaman: string;
  varietas: string;
  tanggal: string;
  jumlah: string;
  satuan: string;
  catatan: string;
  status: "aktif" | "selesai";
}

const initialMusim: MusimItem[] = [
  {
    id: 1, lahan: "Lahan Sawah Barat", tanaman: "Padi IR-64", varietas: "IR-64",
    tanggal: "2024-03-10", jumlah: "5.000", satuan: "batang", catatan: "", status: "aktif",
  },
  {
    id: 2, lahan: "Kebun Atas", tanaman: "Cabai Merah", varietas: "Keriting",
    tanggal: "2024-02-20", jumlah: "800", satuan: "batang", catatan: "Pupuk NPK minggu ke-3", status: "aktif",
  },
  {
    id: 3, lahan: "Lahan Sawah Timur", tanaman: "Padi Ciherang", varietas: "Ciherang",
    tanggal: "2023-11-05", jumlah: "4.200", satuan: "batang", catatan: "", status: "selesai",
  },
  {
    id: 4, lahan: "Kebun Bawah", tanaman: "Tomat Cherry", varietas: "Cherry",
    tanggal: "2023-09-15", jumlah: "500", satuan: "batang", catatan: "", status: "selesai",
  },
];

const tabs = ["Aktif", "Selesai", "Semua"];

// ─── Format date ─────────────────────────────────────────────────────────────
function formatTanggal(iso: string) {
  if (!iso) return "-";
  const [y, m, d] = iso.split("-");
  const months = ["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Ags","Sep","Okt","Nov","Des"];
  return `${parseInt(d)} ${months[parseInt(m) - 1]} ${y}`;
}

// ─── Bottom Sheet Form ────────────────────────────────────────────────────────
interface BottomSheetProps {
  onClose: () => void;
  onSave: (item: Omit<MusimItem, "id" | "status">) => void;
}

function TambahMusimSheet({ onClose, onSave }: BottomSheetProps) {
  const [step, setStep] = useState(1); // 1 = pilih lahan+tanaman, 2 = detail
  const [lahanId, setLahanId] = useState<number | null>(null);
  const [tanamanId, setTanamanId] = useState<number | null>(null);
  const [varietas, setVarietas] = useState("");
  const [varietasCustom, setVarietasCustom] = useState("");
  const [tanggal, setTanggal] = useState(new Date().toISOString().slice(0, 10));
  const [jumlah, setJumlah] = useState("");
  const [satuan, setSatuan] = useState("batang");
  const [catatan, setCatatan] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const selectedLahan = lahanList.find((l) => l.id === lahanId);
  const selectedTanaman = tanamanList.find((t) => t.id === tanamanId);

  function validateStep1() {
    const e: Record<string, string> = {};
    if (!lahanId) e.lahan = "Pilih lahan tanam";
    if (!tanamanId) e.tanaman = "Pilih jenis tanaman";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function validateStep2() {
    const e: Record<string, string> = {};
    if (!tanggal) e.tanggal = "Tanggal tanam wajib diisi";
    if (!jumlah.trim()) e.jumlah = "Jumlah bibit wajib diisi";
    else if (isNaN(Number(jumlah.replace(/\./g, "").replace(",", ".")))) e.jumlah = "Masukkan angka yang valid";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function handleNext() {
    if (validateStep1()) setStep(2);
  }

  function handleSave() {
    if (!validateStep2()) return;
    const finalVarietas = varietas === "__custom__" ? varietasCustom : varietas;
    onSave({
      lahan: selectedLahan!.nama,
      tanaman: `${selectedTanaman!.nama}${finalVarietas ? " " + finalVarietas : ""}`,
      varietas: finalVarietas,
      tanggal,
      jumlah,
      satuan,
      catatan,
    });
  }

  const inputStyle: React.CSSProperties = {
    width: "100%", height: 50, borderRadius: 10,
    border: `1.5px solid ${C.border}`, backgroundColor: "#FAFCFB",
    paddingLeft: 14, paddingRight: 14, fontSize: 15,
    color: C.textDark, outline: "none", boxSizing: "border-box",
    fontFamily: "'Inter', system-ui, sans-serif",
  };

  const errInputStyle: React.CSSProperties = { ...inputStyle, border: `1.5px solid ${C.red}`, backgroundColor: C.redSoft };
  const selectStyle: React.CSSProperties = { ...inputStyle, cursor: "pointer", appearance: "none" as any };

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        style={{
          position: "absolute", inset: 0, backgroundColor: "rgba(0,0,0,0.45)",
          zIndex: 40, borderRadius: 40,
        }}
      />

      {/* Sheet */}
      <div
        style={{
          position: "absolute", bottom: 0, left: 0, right: 0,
          backgroundColor: C.white, borderRadius: "24px 24px 0 0",
          zIndex: 50, maxHeight: "88%", display: "flex", flexDirection: "column",
          boxShadow: "0 -8px 32px rgba(0,0,0,0.18)",
        }}
      >
        {/* Handle bar */}
        <div style={{ display: "flex", justifyContent: "center", paddingTop: 12, paddingBottom: 4 }}>
          <div style={{ width: 40, height: 4, borderRadius: 2, backgroundColor: "#DDD" }} />
        </div>

        {/* Header */}
        <div style={{ padding: "10px 20px 14px", borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <p style={{ fontSize: 17, fontWeight: 700, color: C.textDark }}>Tambah Musim Tanam</p>
            <p style={{ fontSize: 12, color: C.textLight, marginTop: 2 }}>
              Langkah {step} dari 2 — {step === 1 ? "Pilih Lahan & Tanaman" : "Detail Musim"}
            </p>
          </div>
          <button onClick={onClose} style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: C.bg, border: `1px solid ${C.border}`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={C.textMid} strokeWidth="2.5" strokeLinecap="round">
              <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        {/* Progress bar */}
        <div style={{ height: 3, backgroundColor: C.border }}>
          <div style={{ height: "100%", backgroundColor: C.green, width: step === 1 ? "50%" : "100%", transition: "width 0.3s ease" }} />
        </div>

        {/* Scrollable content */}
        <div style={{ flex: 1, overflowY: "auto", padding: "20px 20px 8px" }}>

          {step === 1 ? (
            <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>

              {/* Pilih Lahan */}
              <div>
                <label style={{ fontSize: 13, fontWeight: 700, color: C.textMid, display: "block", marginBottom: 8 }}>
                  🗺️ Pilih Lahan <span style={{ color: C.red }}>*</span>
                </label>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {lahanList.map((l) => {
                    const selected = lahanId === l.id;
                    return (
                      <button
                        key={l.id}
                        onClick={() => { setLahanId(l.id); setErrors((e) => ({ ...e, lahan: "" })); }}
                        style={{
                          width: "100%", padding: "12px 14px", borderRadius: 12, textAlign: "left",
                          border: selected ? `2px solid ${C.green}` : `1.5px solid ${C.border}`,
                          backgroundColor: selected ? C.greenSoft : "#FAFCFB",
                          cursor: "pointer", display: "flex", alignItems: "center", gap: 12,
                        }}
                      >
                        <div style={{ width: 38, height: 38, borderRadius: 10, backgroundColor: selected ? C.green : "#EEE", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={selected ? "white" : C.textLight} strokeWidth="2" strokeLinecap="round"><rect x="3" y="3" width="18" height="18" rx="2" /><path d="M3 9h18M3 15h18M9 3v18" /></svg>
                        </div>
                        <div style={{ flex: 1 }}>
                          <p style={{ fontSize: 14, fontWeight: 600, color: selected ? C.green : C.textDark }}>{l.nama}</p>
                          <p style={{ fontSize: 12, color: C.textLight }}>📐 {l.ukuran}</p>
                        </div>
                        {selected && (
                          <div style={{ width: 22, height: 22, borderRadius: 11, backgroundColor: C.green, display: "flex", alignItems: "center", justifyContent: "center" }}>
                            <svg width="12" height="12" viewBox="0 0 20 20" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round"><path d="M4 10l5 5 7-9" /></svg>
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
                {errors.lahan && <p style={{ fontSize: 12, color: C.red, marginTop: 6 }}>⚠️ {errors.lahan}</p>}
              </div>

              {/* Pilih Tanaman */}
              <div>
                <label style={{ fontSize: 13, fontWeight: 700, color: C.textMid, display: "block", marginBottom: 8 }}>
                  🌱 Pilih Jenis Tanaman <span style={{ color: C.red }}>*</span>
                </label>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                  {tanamanList.map((t) => {
                    const selected = tanamanId === t.id;
                    return (
                      <button
                        key={t.id}
                        onClick={() => { setTanamanId(t.id); setVarietas(""); setErrors((e) => ({ ...e, tanaman: "" })); }}
                        style={{
                          padding: "12px 10px", borderRadius: 12, textAlign: "center",
                          border: selected ? `2px solid ${C.green}` : `1.5px solid ${C.border}`,
                          backgroundColor: selected ? C.greenSoft : "#FAFCFB",
                          cursor: "pointer",
                        }}
                      >
                        <div style={{ fontSize: 28, marginBottom: 6 }}>{t.emoji}</div>
                        <p style={{ fontSize: 13, fontWeight: 600, color: selected ? C.green : C.textDark }}>{t.nama}</p>
                      </button>
                    );
                  })}
                </div>
                {errors.tanaman && <p style={{ fontSize: 12, color: C.red, marginTop: 6 }}>⚠️ {errors.tanaman}</p>}
              </div>

              {/* Pilih Varietas (conditional) */}
              {selectedTanaman && (
                <div>
                  <label style={{ fontSize: 13, fontWeight: 700, color: C.textMid, display: "block", marginBottom: 8 }}>
                    🌿 Varietas <span style={{ color: C.textLight, fontWeight: 400 }}>(opsional)</span>
                  </label>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: varietas === "__custom__" ? 10 : 0 }}>
                    {[...selectedTanaman.varietas, "Lainnya..."].map((v) => {
                      const val = v === "Lainnya..." ? "__custom__" : v;
                      const sel = varietas === val;
                      return (
                        <button
                          key={v}
                          onClick={() => setVarietas(sel ? "" : val)}
                          style={{
                            height: 36, paddingLeft: 14, paddingRight: 14, borderRadius: 20,
                            border: sel ? `2px solid ${C.green}` : `1.5px solid ${C.border}`,
                            backgroundColor: sel ? C.greenSoft : "#FAFCFB",
                            color: sel ? C.green : C.textMid,
                            fontSize: 13, fontWeight: sel ? 700 : 400, cursor: "pointer",
                          }}
                        >
                          {v}
                        </button>
                      );
                    })}
                  </div>
                  {varietas === "__custom__" && (
                    <input
                      autoFocus
                      value={varietasCustom}
                      onChange={(e) => setVarietasCustom(e.target.value)}
                      placeholder="Ketik nama varietas..."
                      style={{ ...inputStyle, marginTop: 8 }}
                    />
                  )}
                </div>
              )}
            </div>
          ) : (
            /* Step 2 */
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>

              {/* Summary step 1 */}
              <div style={{ backgroundColor: C.greenSoft, borderRadius: 12, padding: "12px 14px", display: "flex", gap: 12, alignItems: "center" }}>
                <div style={{ fontSize: 28 }}>{selectedTanaman?.emoji}</div>
                <div>
                  <p style={{ fontSize: 14, fontWeight: 700, color: C.green }}>
                    {selectedTanaman?.nama}{varietas && varietas !== "__custom__" ? ` — ${varietas}` : varietas === "__custom__" && varietasCustom ? ` — ${varietasCustom}` : ""}
                  </p>
                  <p style={{ fontSize: 12, color: C.textMid }}>📍 {selectedLahan?.nama} ({selectedLahan?.ukuran})</p>
                </div>
                <button onClick={() => setStep(1)} style={{ marginLeft: "auto", fontSize: 12, color: C.green, fontWeight: 600, background: "none", border: "none", cursor: "pointer" }}>Ubah</button>
              </div>

              {/* Tanggal Tanam */}
              <div>
                <label style={{ fontSize: 13, fontWeight: 700, color: C.textMid, display: "block", marginBottom: 8 }}>
                  📅 Tanggal Mulai Tanam <span style={{ color: C.red }}>*</span>
                </label>
                <input
                  type="date"
                  value={tanggal}
                  onChange={(e) => { setTanggal(e.target.value); setErrors((err) => ({ ...err, tanggal: "" })); }}
                  style={errors.tanggal ? errInputStyle : inputStyle}
                />
                {errors.tanggal && <p style={{ fontSize: 12, color: C.red, marginTop: 4 }}>⚠️ {errors.tanggal}</p>}
              </div>

              {/* Jumlah + Satuan */}
              <div>
                <label style={{ fontSize: 13, fontWeight: 700, color: C.textMid, display: "block", marginBottom: 8 }}>
                  🌱 Jumlah Bibit <span style={{ color: C.red }}>*</span>
                </label>
                <div style={{ display: "flex", gap: 8 }}>
                  <input
                    type="number"
                    inputMode="numeric"
                    value={jumlah}
                    onChange={(e) => { setJumlah(e.target.value); setErrors((err) => ({ ...err, jumlah: "" })); }}
                    placeholder="Contoh: 5000"
                    style={{ ...(errors.jumlah ? errInputStyle : inputStyle), flex: 2 }}
                  />
                  <select
                    value={satuan}
                    onChange={(e) => setSatuan(e.target.value)}
                    style={{ ...selectStyle, flex: 1.2, paddingRight: 8 }}
                  >
                    {satuanList.map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
                {errors.jumlah && <p style={{ fontSize: 12, color: C.red, marginTop: 4 }}>⚠️ {errors.jumlah}</p>}
              </div>

              {/* Estimasi Panen */}
              <div>
                <label style={{ fontSize: 13, fontWeight: 700, color: C.textMid, display: "block", marginBottom: 8 }}>
                  🗓️ Estimasi Panen <span style={{ color: C.textLight, fontWeight: 400 }}>(opsional)</span>
                </label>
                <input
                  type="date"
                  style={inputStyle}
                  min={tanggal}
                />
              </div>

              {/* Catatan */}
              <div>
                <label style={{ fontSize: 13, fontWeight: 700, color: C.textMid, display: "block", marginBottom: 8 }}>
                  📝 Catatan <span style={{ color: C.textLight, fontWeight: 400 }}>(opsional)</span>
                </label>
                <textarea
                  value={catatan}
                  onChange={(e) => setCatatan(e.target.value)}
                  placeholder="Catatan tambahan musim ini..."
                  rows={3}
                  style={{
                    width: "100%", borderRadius: 10, border: `1.5px solid ${C.border}`,
                    backgroundColor: "#FAFCFB", padding: "12px 14px", fontSize: 14,
                    color: C.textDark, outline: "none", resize: "none",
                    boxSizing: "border-box", fontFamily: "'Inter', system-ui, sans-serif",
                  }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer CTA */}
        <div style={{ padding: "14px 20px 24px", borderTop: `1px solid ${C.border}`, backgroundColor: C.white }}>
          {step === 1 ? (
            <button
              onClick={handleNext}
              style={{
                width: "100%", height: 54, borderRadius: 14, backgroundColor: C.green,
                color: "white", fontSize: 16, fontWeight: 700, border: "none", cursor: "pointer",
                display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
              }}
            >
              Lanjut ke Detail
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round"><path d="M5 12h14M12 5l7 7-7 7" /></svg>
            </button>
          ) : (
            <div style={{ display: "flex", gap: 10 }}>
              <button
                onClick={() => setStep(1)}
                style={{
                  height: 54, paddingLeft: 20, paddingRight: 20, borderRadius: 14,
                  backgroundColor: C.bg, color: C.textMid, fontSize: 15, fontWeight: 600,
                  border: `1.5px solid ${C.border}`, cursor: "pointer",
                  display: "flex", alignItems: "center", gap: 6,
                }}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={C.textMid} strokeWidth="2.5" strokeLinecap="round"><path d="M19 12H5M12 5l-7 7 7 7" /></svg>
                Kembali
              </button>
              <button
                onClick={handleSave}
                style={{
                  flex: 1, height: 54, borderRadius: 14, backgroundColor: C.green,
                  color: "white", fontSize: 16, fontWeight: 700, border: "none", cursor: "pointer",
                  display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
                }}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>
                Simpan Musim
              </button>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

// ─── Success Toast ────────────────────────────────────────────────────────────
function SuccessToast({ tanaman, lahan, onClose }: { tanaman: string; lahan: string; onClose: () => void }) {
  React.useEffect(() => {
    const t = setTimeout(onClose, 3000);
    return () => clearTimeout(t);
  }, [onClose]);
  return (
    <div style={{
      position: "absolute", bottom: 80, left: 16, right: 16, zIndex: 60,
      backgroundColor: C.green, borderRadius: 14, padding: "14px 16px",
      display: "flex", alignItems: "center", gap: 12,
      boxShadow: "0 4px 20px rgba(45,122,58,0.4)",
    }}>
      <div style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: "rgba(255,255,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>
      </div>
      <div style={{ flex: 1 }}>
        <p style={{ fontSize: 14, fontWeight: 700, color: "white" }}>Musim berhasil ditambahkan!</p>
        <p style={{ fontSize: 12, color: "rgba(255,255,255,0.8)", marginTop: 1 }}>{tanaman} · {lahan}</p>
      </div>
      <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", padding: 4 }}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.7)" strokeWidth="2.5" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></svg>
      </button>
    </div>
  );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────
export function DataTanamScreen({ onNavigate }: Props) {
  const [activeTab, setActiveTab] = useState(0);
  const [musimData, setMusimData] = useState<MusimItem[]>(initialMusim);
  const [showSheet, setShowSheet] = useState(false);
  const [toast, setToast] = useState<{ tanaman: string; lahan: string } | null>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const filtered = musimData.filter((m) => {
    if (tabs[activeTab] === "Aktif") return m.status === "aktif";
    if (tabs[activeTab] === "Selesai") return m.status === "selesai";
    return true;
  });

  function handleSaveMusim(data: Omit<MusimItem, "id" | "status">) {
    const newItem: MusimItem = {
      ...data,
      id: Date.now(),
      status: "aktif",
    };
    setMusimData((prev) => [newItem, ...prev]);
    setShowSheet(false);
    setToast({ tanaman: newItem.tanaman, lahan: newItem.lahan });
    setActiveTab(0); // Switch to "Aktif" tab
  }

  function handleDelete(id: number) {
    setMusimData((prev) => prev.filter((m) => m.id !== id));
    setDeleteId(null);
  }

  const aktifCount = musimData.filter((m) => m.status === "aktif").length;
  const selesaiCount = musimData.filter((m) => m.status === "selesai").length;

  return (
    <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", backgroundColor: C.bg, fontFamily: "'Inter', system-ui, sans-serif", position: "relative" }}>
      <GreenHeader
        title="Data Tanam"
        subtitle={`${aktifCount} aktif · ${selesaiCount} selesai`}
        onBack={() => onNavigate("dashboard")}
        rightElement={
          <button
            onClick={() => setShowSheet(true)}
            style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.2)", border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}
          >
            <PlusIcon size={20} color="white" />
          </button>
        }
      />

      {/* Tabs */}
      <div style={{ backgroundColor: C.green, paddingBottom: 0 }}>
        <div style={{ display: "flex", padding: "0 16px 0" }}>
          {tabs.map((tab, i) => (
            <button
              key={tab}
              onClick={() => setActiveTab(i)}
              style={{
                flex: 1, height: 44, border: "none", backgroundColor: "transparent",
                color: activeTab === i ? "white" : "rgba(255,255,255,0.6)",
                fontSize: 14, fontWeight: activeTab === i ? 700 : 400,
                borderBottom: activeTab === i ? "3px solid white" : "3px solid transparent",
                cursor: "pointer",
              }}
            >
              {tab}
              {tab === "Aktif" && aktifCount > 0 && (
                <span style={{ marginLeft: 6, backgroundColor: "rgba(255,255,255,0.25)", borderRadius: 10, paddingLeft: 7, paddingRight: 7, paddingTop: 2, paddingBottom: 2, fontSize: 11, fontWeight: 700 }}>
                  {aktifCount}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* List */}
      <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px 100px" }}>

        {filtered.length === 0 ? (
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "50px 24px", gap: 12 }}>
            <div style={{ width: 72, height: 72, borderRadius: 36, backgroundColor: C.greenSoft, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <LeafIcon size={36} color={C.greenLight} />
            </div>
            <p style={{ fontSize: 16, fontWeight: 600, color: C.textMid, textAlign: "center" }}>
              {tabs[activeTab] === "Aktif" ? "Belum ada musim aktif" : "Belum ada musim selesai"}
            </p>
            <p style={{ fontSize: 13, color: C.textLight, textAlign: "center" }}>
              Tap tombol + untuk mulai mencatat musim tanam baru
            </p>
            <button
              onClick={() => setShowSheet(true)}
              style={{ marginTop: 6, backgroundColor: C.green, color: "white", borderRadius: 12, height: 46, paddingLeft: 24, paddingRight: 24, fontSize: 14, fontWeight: 700, border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 8 }}
            >
              <PlusIcon size={18} color="white" /> Tambah Musim
            </button>
          </div>
        ) : (
          filtered.map((m) => (
            <div
              key={m.id}
              style={{
                backgroundColor: C.white, borderRadius: 14, padding: "14px 16px",
                boxShadow: "0 1px 4px rgba(0,0,0,0.07)", marginBottom: 10,
                border: deleteId === m.id ? `1.5px solid ${C.red}` : "1.5px solid transparent",
              }}
            >
              {/* Main row */}
              <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                {/* Icon */}
                <div style={{ width: 48, height: 48, borderRadius: 14, backgroundColor: m.status === "aktif" ? C.greenSoft : "#F5F5F5", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  <LeafIcon size={24} color={m.status === "aktif" ? C.green : C.textLight} />
                </div>

                {/* Info */}
                <div style={{ flex: 1 }} onClick={() => onNavigate("detail-tanam")} role="button" style={{ flex: 1, cursor: "pointer" }}>
                  <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark }}>{m.tanaman}</p>
                  <p style={{ fontSize: 13, color: C.textLight, marginTop: 1 }}>📍 {m.lahan}</p>
                  <p style={{ fontSize: 12, color: C.textLight, marginTop: 2 }}>🗓 Tanam: {formatTanggal(m.tanggal)}</p>
                  <div style={{ display: "flex", gap: 6, marginTop: 6, flexWrap: "wrap" }}>
                    <Badge label={m.status === "aktif" ? "Aktif" : "Selesai"} type={m.status === "aktif" ? "success" : "default"} />
                    {m.jumlah && <Badge label={`${m.jumlah} ${m.satuan}`} type="info" />}
                    {m.catatan && <Badge label="Ada catatan" type="warning" />}
                  </div>
                </div>

                {/* Actions */}
                <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                  <button
                    onClick={() => onNavigate("detail-tanam")}
                    style={{ width: 34, height: 34, borderRadius: 8, backgroundColor: C.bg, border: `1px solid ${C.border}`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}
                  >
                    <svg width="16" height="16" viewBox="0 0 20 20" fill="none" stroke={C.textMid} strokeWidth="2" strokeLinecap="round"><path d="M7.5 5l5 5-5 5" /></svg>
                  </button>
                  <button
                    onClick={() => setDeleteId(deleteId === m.id ? null : m.id)}
                    style={{ width: 34, height: 34, borderRadius: 8, backgroundColor: deleteId === m.id ? C.redSoft : C.bg, border: `1px solid ${deleteId === m.id ? "#FFCDD2" : C.border}`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}
                  >
                    <TrashIcon size={15} color={C.red} />
                  </button>
                </div>
              </div>

              {/* Delete confirm row */}
              {deleteId === m.id && (
                <div style={{ marginTop: 12, paddingTop: 12, borderTop: `1px solid ${C.border}`, display: "flex", gap: 8, alignItems: "center" }}>
                  <p style={{ flex: 1, fontSize: 13, color: C.red, fontWeight: 500 }}>Hapus musim ini?</p>
                  <button onClick={() => setDeleteId(null)} style={{ height: 34, paddingLeft: 14, paddingRight: 14, borderRadius: 8, backgroundColor: C.bg, border: `1px solid ${C.border}`, fontSize: 13, fontWeight: 600, color: C.textMid, cursor: "pointer" }}>Batal</button>
                  <button onClick={() => handleDelete(m.id)} style={{ height: 34, paddingLeft: 14, paddingRight: 14, borderRadius: 8, backgroundColor: C.red, border: "none", fontSize: 13, fontWeight: 700, color: "white", cursor: "pointer" }}>Hapus</button>
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* FAB */}
      <button
        onClick={() => setShowSheet(true)}
        style={{
          position: "absolute", bottom: 76, right: 16,
          backgroundColor: C.green, color: "white",
          borderRadius: 16, height: 52, paddingLeft: 20, paddingRight: 20,
          boxShadow: "0 4px 14px rgba(45,122,58,0.4)",
          display: "flex", alignItems: "center", gap: 8,
          fontSize: 15, fontWeight: 700, border: "none", cursor: "pointer",
        }}
      >
        <span style={{ fontSize: 22, lineHeight: 1 }}>+</span>
        Tambah Musim
      </button>

      {/* Bottom Sheet */}
      {showSheet && (
        <TambahMusimSheet
          onClose={() => setShowSheet(false)}
          onSave={handleSaveMusim}
        />
      )}

      {/* Success Toast */}
      {toast && (
        <SuccessToast
          tanaman={toast.tanaman}
          lahan={toast.lahan}
          onClose={() => setToast(null)}
        />
      )}

      <BottomNav active="data-tanam" onNavigate={onNavigate} />
    </div>
  );
}
