import React, { useState } from "react";
import { C, GreenHeader, DownloadIcon, UploadIcon, ShieldIcon } from "../shared";

interface Props {
  onNavigate: (screen: string) => void;
}

export function BackupRestoreScreen({ onNavigate }: Props) {
  const [backupState, setBackupState] = useState<"idle" | "loading" | "done">("idle");
  const [restoreState, setRestoreState] = useState<"idle" | "confirm" | "loading" | "done" | "error">("idle");

  function handleBackup() {
    setBackupState("loading");
    setTimeout(() => setBackupState("done"), 1800);
  }

  function handleRestoreClick() {
    setRestoreState("confirm");
  }

  function handleRestoreConfirm() {
    setRestoreState("loading");
    setTimeout(() => setRestoreState("done"), 2000);
  }

  return (
    <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", backgroundColor: C.bg, fontFamily: "'Inter', system-ui, sans-serif" }}>
      <GreenHeader title="Backup & Restore" subtitle="Amankan data Anda" onBack={() => onNavigate("settings")} />

      <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px 24px" }}>

        {/* Info card */}
        <div style={{ backgroundColor: C.blueSoft, borderRadius: 12, padding: "12px 14px", display: "flex", gap: 10, alignItems: "flex-start", marginBottom: 20 }}>
          <ShieldIcon size={20} color={C.blue} />
          <p style={{ fontSize: 13, color: C.blue, lineHeight: 1.5 }}>
            Backup data disimpan sebagai file <strong>.zip</strong>. Simpan file ini di tempat aman. Untuk pindah perangkat, gunakan fitur Restore dengan file backup tersebut.
          </p>
        </div>

        {/* Last backup info */}
        <div style={{ backgroundColor: C.white, borderRadius: 14, padding: "16px", boxShadow: "0 1px 4px rgba(0,0,0,0.07)", marginBottom: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
            <div style={{ width: 48, height: 48, borderRadius: 14, backgroundColor: C.greenSoft, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke={C.green} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z" />
              </svg>
            </div>
            <div>
              <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark }}>Backup Terakhir</p>
              <p style={{ fontSize: 13, color: C.textLight }}>{backupState === "done" ? "Baru saja" : "20 Apr 2024, 15:32"}</p>
            </div>
            <div style={{ marginLeft: "auto" }}>
              <span style={{ backgroundColor: C.greenSoft, color: C.green, fontSize: 12, fontWeight: 600, borderRadius: 8, padding: "4px 10px" }}>
                {backupState === "done" ? "✅ Baru" : "✅ OK"}
              </span>
            </div>
          </div>

          {/* File info */}
          <div style={{ backgroundColor: C.bg, borderRadius: 10, padding: "10px 14px" }}>
            {[
              { label: "Nama File", value: "yootani_backup_20Apr2024.zip" },
              { label: "Ukuran File", value: "284 KB" },
              { label: "Total Musim", value: "4 musim" },
              { label: "Total Biaya", value: "Rp 4.562.000" },
            ].map((r, i) => (
              <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", borderBottom: i < 3 ? `1px solid ${C.border}` : "none" }}>
                <p style={{ fontSize: 12, color: C.textLight }}>{r.label}</p>
                <p style={{ fontSize: 12, fontWeight: 600, color: C.textDark }}>{r.value}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Buat Backup */}
        <div style={{ backgroundColor: C.white, borderRadius: 14, padding: "16px", boxShadow: "0 1px 4px rgba(0,0,0,0.07)", marginBottom: 14 }}>
          <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark, marginBottom: 6 }}>Buat Backup Baru</p>
          <p style={{ fontSize: 13, color: C.textLight, marginBottom: 14, lineHeight: 1.5 }}>
            Ekspor semua data ke file .zip dan simpan ke penyimpanan lokal.
          </p>
          <button
            onClick={handleBackup}
            disabled={backupState === "loading"}
            style={{
              width: "100%",
              height: 52,
              borderRadius: 12,
              backgroundColor: backupState === "loading" ? "#B2DFBA" : C.green,
              color: "white",
              fontSize: 15,
              fontWeight: 700,
              border: "none",
              cursor: backupState === "loading" ? "not-allowed" : "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 10,
            }}
          >
            {backupState === "loading" ? (
              <>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" style={{ animation: "spin 1s linear infinite" }}>
                  <path d="M21 12a9 9 0 11-6.2-8.55" />
                </svg>
                Membuat Backup...
              </>
            ) : backupState === "done" ? (
              <>✅ Backup Berhasil Disimpan</>
            ) : (
              <><DownloadIcon size={20} color="white" /> Buat Backup Sekarang</>
            )}
          </button>
        </div>

        {/* Restore */}
        <div style={{ backgroundColor: C.white, borderRadius: 14, padding: "16px", boxShadow: "0 1px 4px rgba(0,0,0,0.07)", marginBottom: 14 }}>
          <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark, marginBottom: 6 }}>Restore dari File</p>
          <p style={{ fontSize: 13, color: C.textLight, marginBottom: 8, lineHeight: 1.5 }}>
            Pulihkan data dari file backup .zip yang tersimpan.
          </p>

          {/* Warning */}
          <div style={{ backgroundColor: C.orangeSoft, borderRadius: 8, padding: "10px 12px", marginBottom: 14, display: "flex", gap: 8, alignItems: "flex-start" }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={C.orange} strokeWidth="2.5" strokeLinecap="round" style={{ marginTop: 1, flexShrink: 0 }}>
              <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
              <line x1="12" y1="9" x2="12" y2="13" /><line x1="12" y1="17" x2="12.01" y2="17" />
            </svg>
            <p style={{ fontSize: 12, color: C.orange, lineHeight: 1.5 }}>
              Data yang ada akan diganti dengan data backup. Pastikan file backup valid.
            </p>
          </div>

          {/* Confirm dialog */}
          {restoreState === "confirm" && (
            <div style={{ backgroundColor: C.redSoft, borderRadius: 10, padding: "12px 14px", marginBottom: 12, border: `1px solid #FFCDD2` }}>
              <p style={{ fontSize: 14, fontWeight: 600, color: C.red, marginBottom: 8 }}>Konfirmasi Restore</p>
              <p style={{ fontSize: 13, color: "#B71C1C", lineHeight: 1.5, marginBottom: 12 }}>
                Semua data saat ini akan diganti. Tindakan ini tidak bisa dibatalkan. Lanjutkan?
              </p>
              <div style={{ display: "flex", gap: 8 }}>
                <button onClick={() => setRestoreState("idle")} style={{ flex: 1, height: 40, borderRadius: 8, backgroundColor: C.bg, color: C.textMid, fontSize: 13, fontWeight: 600, border: `1px solid ${C.border}`, cursor: "pointer" }}>Batal</button>
                <button onClick={handleRestoreConfirm} style={{ flex: 2, height: 40, borderRadius: 8, backgroundColor: C.red, color: "white", fontSize: 13, fontWeight: 700, border: "none", cursor: "pointer" }}>Ya, Restore</button>
              </div>
            </div>
          )}

          {restoreState === "done" && (
            <div style={{ backgroundColor: C.greenSoft, borderRadius: 8, padding: "10px 12px", marginBottom: 12, display: "flex", gap: 8, alignItems: "center" }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={C.green} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22 11.08V12a10 10 0 11-5.93-9.14" /><polyline points="22 4 12 14.01 9 11.01" />
              </svg>
              <p style={{ fontSize: 13, color: C.green, fontWeight: 600 }}>Data berhasil dipulihkan!</p>
            </div>
          )}

          <button
            onClick={handleRestoreClick}
            disabled={restoreState === "loading" || restoreState === "done"}
            style={{
              width: "100%",
              height: 52,
              borderRadius: 12,
              backgroundColor: restoreState === "loading" ? "#FFE0B2" : restoreState === "done" ? "#E8F5E9" : C.orangeSoft,
              color: restoreState === "done" ? C.green : C.orange,
              fontSize: 15,
              fontWeight: 700,
              border: `1.5px solid ${restoreState === "done" ? C.green : C.orange}`,
              cursor: restoreState === "loading" || restoreState === "done" ? "not-allowed" : "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 10,
            }}
          >
            {restoreState === "loading" ? (
              <>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={C.orange} strokeWidth="2.5" strokeLinecap="round" style={{ animation: "spin 1s linear infinite" }}>
                  <path d="M21 12a9 9 0 11-6.2-8.55" />
                </svg>
                Memulihkan Data...
              </>
            ) : restoreState === "done" ? (
              "✅ Restore Selesai"
            ) : (
              <><UploadIcon size={20} color={C.orange} /> Pilih File Backup (.zip)</>
            )}
          </button>
        </div>

        {/* Validation info */}
        <div style={{ backgroundColor: C.white, borderRadius: 14, padding: "14px 16px", boxShadow: "0 1px 4px rgba(0,0,0,0.07)" }}>
          <p style={{ fontSize: 14, fontWeight: 700, color: C.textDark, marginBottom: 8 }}>Validasi File Backup</p>
          {[
            { icon: "✅", label: "Format file .zip", ok: true },
            { icon: "✅", label: "Versi YooTani kompatibel", ok: true },
            { icon: "✅", label: "Integritas data", ok: true },
            { icon: "⏳", label: "Tanggal backup dalam 30 hari", ok: null },
          ].map((v, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "6px 0", borderBottom: i < 3 ? `1px solid ${C.border}` : "none" }}>
              <span style={{ fontSize: 16 }}>{v.icon}</span>
              <p style={{ fontSize: 13, color: v.ok === null ? C.textLight : C.textDark }}>{v.label}</p>
            </div>
          ))}
        </div>
      </div>

      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
