import React, { useState } from "react";
import { C, GreenHeader, PlantIcon, PlusIcon, EditIcon, TrashIcon } from "../shared";

interface Props {
  onNavigate: (screen: string) => void;
}

const tanamanData = [
  { id: 1, nama: "Padi", varietas: "IR-64, Ciherang, Situbagendit", emoji: "🌾" },
  { id: 2, nama: "Cabai Merah", varietas: "Keriting, TM-999", emoji: "🌶️" },
  { id: 3, nama: "Tomat", varietas: "Cherry, Beef Tomato", emoji: "🍅" },
  { id: 4, nama: "Jagung", varietas: "P-35, Bisi-18", emoji: "🌽" },
  { id: 5, nama: "Bayam", varietas: "-", emoji: "🥬" },
];

export function DataTanamanScreen({ onNavigate }: Props) {
  const [showForm, setShowForm] = useState(false);
  const [nama, setNama] = useState("");
  const [varietas, setVarietas] = useState("");

  return (
    <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", backgroundColor: C.bg, fontFamily: "'Inter', system-ui, sans-serif" }}>
      <GreenHeader
        title="Data Tanaman"
        subtitle={`${tanamanData.length} jenis tanaman`}
        onBack={() => onNavigate("settings")}
        rightElement={
          <button onClick={() => setShowForm(true)} style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.2)", border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <PlusIcon size={20} color="white" />
          </button>
        }
      />

      <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px 24px" }}>

        {/* Add Form */}
        {showForm && (
          <div style={{ backgroundColor: C.white, borderRadius: 14, padding: 16, boxShadow: "0 2px 8px rgba(0,0,0,0.1)", marginBottom: 14 }}>
            <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark, marginBottom: 14 }}>Tambah Tanaman Baru</p>
            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: C.textMid, display: "block", marginBottom: 6 }}>Nama Tanaman <span style={{ color: C.red }}>*</span></label>
              <input value={nama} onChange={e => setNama(e.target.value)} placeholder="Contoh: Kacang Panjang" style={{ width: "100%", height: 46, borderRadius: 8, border: `1.5px solid ${C.border}`, backgroundColor: "#FAFCFB", paddingLeft: 14, paddingRight: 14, fontSize: 14, color: C.textDark, outline: "none", boxSizing: "border-box" }} />
            </div>
            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: C.textMid, display: "block", marginBottom: 6 }}>Varietas <span style={{ color: C.textLight, fontWeight: 400 }}>(opsional)</span></label>
              <input value={varietas} onChange={e => setVarietas(e.target.value)} placeholder="Contoh: Lokal, Hibrida" style={{ width: "100%", height: 46, borderRadius: 8, border: `1.5px solid ${C.border}`, backgroundColor: "#FAFCFB", paddingLeft: 14, paddingRight: 14, fontSize: 14, color: C.textDark, outline: "none", boxSizing: "border-box" }} />
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => setShowForm(false)} style={{ flex: 1, height: 46, borderRadius: 10, backgroundColor: C.bg, color: C.textMid, fontSize: 14, fontWeight: 600, border: `1px solid ${C.border}`, cursor: "pointer" }}>Batal</button>
              <button onClick={() => { setShowForm(false); setNama(""); setVarietas(""); }} style={{ flex: 2, height: 46, borderRadius: 10, backgroundColor: C.green, color: "white", fontSize: 14, fontWeight: 700, border: "none", cursor: "pointer" }}>Simpan Tanaman</button>
            </div>
          </div>
        )}

        {/* Tanaman List */}
        {tanamanData.map((t) => (
          <div key={t.id} style={{ backgroundColor: C.white, borderRadius: 14, padding: "14px 16px", marginBottom: 10, boxShadow: "0 1px 4px rgba(0,0,0,0.07)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ width: 48, height: 48, borderRadius: 14, backgroundColor: C.greenSoft, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontSize: 26 }}>
                {t.emoji}
              </div>
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: 15, fontWeight: 700, color: C.textDark }}>{t.nama}</p>
                <p style={{ fontSize: 12, color: C.textLight, marginTop: 2 }}>
                  {t.varietas !== "-" ? `🌿 ${t.varietas}` : "Varietas tidak dicatat"}
                </p>
              </div>
              <div style={{ display: "flex", gap: 4 }}>
                <button style={{ width: 34, height: 34, borderRadius: 8, backgroundColor: C.bg, border: `1px solid ${C.border}`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <EditIcon size={16} color={C.textMid} />
                </button>
                <button style={{ width: 34, height: 34, borderRadius: 8, backgroundColor: C.redSoft, border: `1px solid #FFCDD2`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <TrashIcon size={16} color={C.red} />
                </button>
              </div>
            </div>
          </div>
        ))}

        {!showForm && (
          <button
            onClick={() => setShowForm(true)}
            style={{ width: "100%", height: 52, borderRadius: 12, backgroundColor: C.greenSoft, color: C.green, fontSize: 15, fontWeight: 700, border: `1.5px dashed ${C.greenLight}`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 4 }}
          >
            <PlusIcon size={20} color={C.green} />
            Tambah Tanaman
          </button>
        )}
      </div>
    </div>
  );
}
