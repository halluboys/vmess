# PRD — YooTani

## 1. Product Overview

**Nama produk:** YooTani  
**Platform:** Android  
**Tipe aplikasi:** offline-first mobile app untuk petani  
**Tujuan utama:** membantu petani mencatat dan memonitor usaha tani per musim tanam, dari awal tanam sampai panen selesai, lalu membuat rekap dan laporan per musim.

YooTani dirancang untuk dipakai oleh petani secara sederhana, cepat, dan praktis. Aktivasi awal membutuhkan internet untuk validasi lisensi, tetapi setelah itu fitur utama aplikasi dapat digunakan secara offline.

---

## 2. Problem Statement

Petani sering mencatat kegiatan usaha tani secara manual, tercecer, atau tidak konsisten. Akibatnya:
- biaya produksi sulit dipantau
- jadwal kegiatan seperti semprot mudah terlewat
- hasil panen bertahap tidak tercatat rapi
- keuntungan/rugi per musim sulit dihitung
- riwayat musim tanam yang selesai sulit dilihat kembali
- perpindahan perangkat berisiko menyebabkan data hilang jika tidak ada backup

---

## 3. Product Goals

### Goal utama
- memudahkan petani mencatat usaha tani per musim
- memudahkan petani memantau biaya, jadwal, dan hasil panen
- menyediakan laporan per musim tanam
- menyediakan histori musim yang telah selesai
- menyediakan backup dan restore data

### Goal penggunaan
- mudah dipakai user awam
- tetap bisa dipakai offline setelah aktivasi
- cepat dipahami pada penggunaan pertama
- nyaman dibaca di HP Android biasa

---

## 4. Target User

### Primary User
Petani perorangan atau pengelola usaha tani kecil/menengah yang:
- memakai Android
- butuh pencatatan sederhana
- tidak ingin aplikasi yang rumit
- lebih sering bekerja di lapangan
- membutuhkan fitur offline

### Karakter user
- tidak selalu terbiasa dengan aplikasi kompleks
- butuh tombol jelas dan besar
- butuh tulisan yang mudah dibaca
- lebih fokus ke pencatatan praktis daripada analitik rumit

---

## 5. Product Principles

- **Offline-first:** fitur utama berjalan offline setelah aktivasi awal
- **Simple-first:** form dan alur dibuat sesederhana mungkin
- **Season-based:** unit utama pencatatan adalah musim tanam
- **Actionable:** dashboard harus membantu tindakan cepat
- **Readable:** angka, status, dan CTA harus mudah dibaca
- **Safe data:** backup/restore harus mudah dan aman

---

## 6. Scope

### 6.1 MVP Scope
Fitur yang masuk versi awal:
- aktivasi lisensi dengan key code
- setup profil petani
- dashboard utama
- data lahan
- data tanaman
- pembuatan musim tanam
- biaya produksi
- jadwal kegiatan / semprot + notifikasi lokal
- pencatatan hasil panen bertahap
- rekap akhir musim
- laporan per musim
- export PDF per musim
- backup data
- restore data
- history musim selesai
- info lisensi

### 6.2 Out of Scope
Tidak masuk versi awal:
- multi-user dalam 1 perangkat
- cloud sync penuh
- web dashboard
- pembayaran online
- marketplace
- analitik AI
- laporan global lintas seluruh musim sebagai laporan utama
- transfer lisensi antar perangkat

---

## 7. Core Product Rules

### 7.1 Lisensi
- aplikasi pertama kali dibuka menampilkan halaman input lisensi
- user harus memasukkan key code
- validasi lisensi dilakukan secara online
- jika lisensi valid, user lanjut ke setup data petani
- setelah aktivasi sukses, aplikasi tidak meminta key code lagi
- setelah aktivasi, aplikasi bisa dipakai offline
- 1 lisensi hanya untuk 1 user/perangkat
- lisensi dibuat oleh admin
- lisensi memiliki durasi aktif
- lisensi tidak dapat dipindahkan ke perangkat lain
- jika pindah perangkat, admin harus membuat lisensi baru

### 7.2 Perangkat Baru
Jika user pindah perangkat:
1. user backup data di perangkat lama
2. user install aplikasi di perangkat baru
3. user aktivasi dengan lisensi baru
4. user restore data dari file backup
5. histori tetap tersedia setelah restore

### 7.3 Logout
- tidak ada fitur logout
- karena aplikasi bersifat single-user per perangkat
- jika aplikasi terhapus, user cukup install ulang, aktivasi ulang, lalu restore backup

### 7.4 Unit Utama Data
Unit utama pencatatan adalah **musim tanam**.

Setiap musim tanam akan memiliki:
- lahan
- jenis tanaman
- tanggal tanam
- biaya produksi
- jadwal kegiatan
- hasil panen bertahap
- status musim
- rekap akhir
- laporan PDF
- history jika selesai

### 7.5 Modal Awal
- modal awal tidak dibuat sebagai modul terpisah
- modal awal dianggap bagian dari biaya produksi
- contoh: bibit, pupuk awal, obat awal, tenaga kerja awal

### 7.6 Laporan
- laporan utama berbasis **per musim tanam**
- bukan laporan global seluruh data
- contoh laporan: “Cabe Lahan Belakang — tanam 10-10-2026”
- petani bisa punya banyak musim berbeda untuk tanaman berbeda

### 7.7 Backup & Restore
- backup dilakukan manual oleh user
- format backup berupa file `.zip`
- isi backup direkomendasikan berupa data terstruktur dan metadata
- restore hanya dilakukan dari file valid
- restore dapat dipakai saat pindah perangkat agar histori tetap aman

---

## 8. User Flow

### 8.1 First-Time Flow
1. user buka aplikasi
2. masuk ke halaman aktivasi lisensi
3. input key code
4. sistem validasi online
5. jika valid, lanjut ke setup data petani
6. user isi data petani
7. user masuk ke dashboard utama

### 8.2 Daily Flow
1. user buka aplikasi
2. masuk langsung ke dashboard
3. user dapat memilih:
   - tambah musim tanam
   - catat biaya
   - tambah jadwal
   - catat panen
   - lihat laporan
4. data tersimpan lokal
5. dashboard dan laporan ikut berubah sesuai data terbaru

### 8.3 End-of-Season Flow
1. user menyelesaikan musim tanam
2. sistem membuat rekap akhir musim
3. musim dipindahkan ke history
4. user tetap bisa membuka detail dan export PDF

### 8.4 Device Migration Flow
1. user backup data
2. pindah ke perangkat baru
3. aktivasi lisensi baru
4. restore backup
5. data kembali tersedia

---

## 9. Information Architecture

Halaman utama yang dibutuhkan:
1. Aktivasi Lisensi  
2. Setup Profil Petani  
3. Dashboard  
4. Data Tanam  
5. Detail Tanam  
6. Biaya Produksi  
7. Jadwal Kegiatan / Semprot  
8. Panen  
9. Laporan  
10. Backup & Restore  
11. Pengaturan / Lainnya  
12. Info Lisensi  
13. Data Lahan  
14. Data Tanaman  
15. History Musim

---

## 10. Feature Requirements

### 10.1 Aktivasi Lisensi

**Tujuan:** memastikan hanya user dengan lisensi valid yang bisa memakai aplikasi.

**Input:**
- key code lisensi

**Output:**
- status lisensi valid / invalid / expired
- aktivasi sukses
- penyimpanan status aktivasi lokal

**States:**
- initial
- loading
- invalid
- expired
- success
- no internet

**Acceptance Criteria:**
- user bisa input key code
- sistem memvalidasi lisensi ke server
- lisensi invalid ditolak
- lisensi expired ditolak
- lisensi valid mengarahkan user ke setup profil
- hasil aktivasi tersimpan lokal

---

### 10.2 Setup Profil Petani

**Field minimum:**
- nama petani
- nomor HP/WhatsApp
- desa/alamat

**Validation:**
- nama petani wajib
- field lain boleh opsional jika belum ingin dipaksa

**Acceptance Criteria:**
- user bisa mengisi profil
- data tersimpan lokal
- setelah simpan, user masuk dashboard

---

### 10.3 Dashboard

**Tujuan:** menjadi pusat kontrol usaha tani.

**Komponen utama:**
- sapaan user
- statistik ringkas
- jadwal hari ini
- aksi cepat
- data tanam aktif
- bottom navigation

**Quick Actions:**
- tambah data tanam
- catat biaya
- catat hasil panen
- tambah jadwal

**Acceptance Criteria:**
- statistik tampil dari data aktual
- aksi cepat membuka screen yang tepat
- data tanam aktif tampil rapi
- jika belum ada musim aktif, tampil empty state yang jelas

---

### 10.4 Data Lahan

**Tujuan:** menyimpan master data lahan.

**Field:**
- nama lahan (wajib)
- ukuran/luas lahan (opsional)
- lokasi/keterangan (opsional)

**Acceptance Criteria:**
- user bisa tambah/edit/hapus data lahan
- nama lahan wajib diisi

---

### 10.5 Data Tanaman

**Tujuan:** menyimpan master data tanaman.

**Field:**
- nama tanaman (wajib)
- varietas (opsional)
- catatan (opsional)

**Acceptance Criteria:**
- user bisa tambah/edit/hapus tanaman
- nama tanaman wajib diisi

---

### 10.6 Musim Tanam

**Tujuan:** menjadi unit utama pencatatan usaha tani.

**Field wajib:**
- nama lahan
- jenis tanaman
- tanggal tanam

**Field opsional:**
- jumlah tanaman
- estimasi panen
- catatan awal
- label musim tanam jika diperlukan

**Status musim:**
- aktif
- siap panen
- selesai

**Acceptance Criteria:**
- user bisa membuat musim tanam baru
- lahan, tanaman, dan tanggal tanam wajib dipilih/diisi
- musim aktif tampil di dashboard
- musim selesai pindah ke history
- user bisa membuka detail musim

---

### 10.7 Biaya Produksi

**Tujuan:** mencatat semua pengeluaran per musim tanam.

**Kategori biaya awal:**
- bibit
- pupuk
- obat
- tenaga kerja
- alat/bahan lain
- kategori custom jika nanti ditambahkan

**Field:**
- musim tanam
- kategori
- nama item
- qty/jumlah
- harga satuan
- total
- tanggal
- catatan

**Business Rule:**
- modal awal dianggap bagian dari biaya produksi

**Acceptance Criteria:**
- user bisa tambah/edit/hapus biaya
- total biaya musim dihitung otomatis
- biaya dapat dilihat per kategori dan total

---

### 10.8 Jadwal Kegiatan / Semprot

**Tujuan:** membantu user mengingat aktivitas budidaya.

**Jenis jadwal:**
- semprot
- penyiraman
- pemupukan
- kegiatan lain

**Field:**
- judul kegiatan
- musim tanam
- tanggal
- jam
- catatan
- status selesai/belum

**Acceptance Criteria:**
- user bisa tambah/edit/hapus jadwal
- notifikasi lokal muncul sesuai jadwal
- jadwal hari ini tampil di dashboard
- jadwal bisa ditandai selesai

---

### 10.9 Hasil Panen

**Tujuan:** mencatat hasil panen dari panen pertama sampai selesai.

**Field:**
- musim tanam
- tanggal panen
- jumlah hasil
- satuan
- harga jual
- total pendapatan
- catatan

**Acceptance Criteria:**
- satu musim bisa punya banyak entry panen
- total hasil panen dan pendapatan dihitung otomatis
- daftar panen tersusun berdasarkan tanggal

---

### 10.10 Rekap Akhir Musim

**Tujuan:** melihat hasil akhir musim tanam.

**Isi rekap:**
- total biaya produksi
- total hasil panen / pendapatan
- laba/rugi bersih
- catatan akhir musim

**Acceptance Criteria:**
- sistem menghitung rekap otomatis
- user bisa melihat untung/rugi per musim
- user bisa menandai musim selesai

---

### 10.11 Laporan Per Musim

**Tujuan:** menyediakan laporan formal per musim tanam.

**Isi laporan:**
- nama musim / identitas musim
- lahan
- tanaman
- tanggal tanam
- status
- total biaya
- total hasil panen / pendapatan
- laba/rugi
- daftar biaya
- daftar panen
- ringkasan akhir

**Acceptance Criteria:**
- user bisa membuka laporan per musim
- user bisa export PDF
- isi PDF sesuai data musim tersebut

---

### 10.12 Backup & Restore

**Tujuan:** melindungi data user dan mendukung pindah perangkat.

**Format backup:**
- file `.zip`

**Rekomendasi isi backup:**
- `metadata.json`
- `data.json`

**Metadata minimum:**
- versi aplikasi
- tanggal backup
- nama petani
- versi schema/data

**Restore:**
- hanya dari file valid
- menimpa data lama setelah konfirmasi

**Acceptance Criteria:**
- user bisa membuat backup
- file backup tersimpan ke storage
- restore hanya menerima file valid
- restore sukses memulihkan data lokal

---

### 10.13 History Musim Selesai

**Tujuan:** menyimpan arsip musim yang telah selesai.

**Acceptance Criteria:**
- musim selesai tetap dapat dibuka
- laporan PDF tetap bisa dibuat dari history
- user bisa melihat detail biaya, panen, dan rekap musim lama

---

### 10.14 Pengaturan / Lainnya

**Menu utama:**
- data lahan
- data tanaman
- profil petani
- notifikasi
- backup & restore
- info lisensi
- tentang aplikasi

**Acceptance Criteria:**
- semua menu utama bisa diakses dari area ini
- tidak ada logout

---

## 11. Data Entities

Entity utama:
- License
- FarmerProfile
- Land
- Crop
- PlantingSeason
- ProductionCost
- ActivitySchedule
- HarvestEntry
- SeasonSummary
- BackupMetadata

---

## 12. Non-Functional Requirements

- aplikasi harus berjalan offline setelah aktivasi awal
- data lokal harus stabil dan aman
- backup dan restore harus mudah dipahami user
- notifikasi lokal harus berjalan
- UI harus sederhana dan mudah dibaca
- ukuran tombol harus nyaman disentuh
- export PDF harus bisa dilakukan dari data lokal
- performa list harus tetap nyaman untuk data menengah
- screen harus punya empty state, loading state, dan error state

---

## 13. Assumptions

- satu perangkat digunakan oleh satu user utama
- aktivasi lisensi dikelola backend/admin terpisah
- data utama setelah aktivasi tersimpan lokal
- backup manual menjadi mekanisme utama pemindahan data
- laporan utama fokus per musim, bukan lintas seluruh data

---

## 14. Open Questions yang Masih Bisa Diputuskan Nanti

- apakah jumlah tanaman ditampilkan di dashboard kalau diisi
- apakah estimasi panen ingin dijadikan field wajib di masa depan
- apakah kategori biaya custom dibuka sejak MVP atau phase berikutnya
- apakah notifikasi cukup lokal atau perlu template jadwal otomatis

---

## 15. Definition of Done untuk MVP

Produk dianggap siap MVP jika:
- user bisa aktivasi lisensi online
- user bisa mengisi profil petani
- user bisa membuat musim tanam
- user bisa mencatat biaya produksi
- user bisa membuat jadwal dan menerima notifikasi lokal
- user bisa mencatat panen bertahap
- user bisa melihat rekap akhir musim
- user bisa membuat PDF laporan per musim
- user bisa backup dan restore data
- user bisa membuka history musim selesai
- aplikasi tetap berjalan offline setelah aktivasi awal
