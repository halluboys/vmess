#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"

MAIL_DOMAIN="${1:-haluboy.org}"
ALLOWED_DOMAINS_DEFAULT="${MAIL_DOMAIN},mail.${MAIL_DOMAIN},inbox.${MAIL_DOMAIN}"
ALLOWED_DOMAINS="${2:-$ALLOWED_DOMAINS_DEFAULT}"

echo "[0/8] Konfigurasi domain"
echo "MAIL_DOMAIN       = $MAIL_DOMAIN"
echo "ALLOWED_DOMAINS   = $ALLOWED_DOMAINS"

echo "[1/8] Cek Node.js dan npm..."
command -v node >/dev/null 2>&1 || { echo "Node.js belum terinstall"; exit 1; }
command -v npm >/dev/null 2>&1 || { echo "npm belum terinstall"; exit 1; }

echo "[2/8] Install dependency..."
npm install

echo "[3/8] Cek login Cloudflare..."
if ! npx wrangler whoami >/dev/null 2>&1; then
  echo "Belum login, menjalankan wrangler login..."
  npx wrangler login
fi

echo "[4/8] Menulis domain ke wrangler.jsonc..."
if command -v python3 >/dev/null 2>&1; then
python3 - <<PY
from pathlib import Path
p = Path("wrangler.jsonc")
txt = p.read_text()
txt = txt.replace("__MAIL_DOMAIN__", "${MAIL_DOMAIN}")
txt = txt.replace("__ALLOWED_DOMAINS__", "${ALLOWED_DOMAINS}")
p.write_text(txt)
PY
else
  sed -i "s|__MAIL_DOMAIN__|${MAIL_DOMAIN}|g" wrangler.jsonc
  sed -i "s|__ALLOWED_DOMAINS__|${ALLOWED_DOMAINS}|g" wrangler.jsonc
fi

if grep -q "__DB_ID__" wrangler.jsonc; then
  echo "[5/8] Membuat D1 database tempmail-db..."
  CREATE_OUT="$(npx wrangler d1 create tempmail-db 2>&1 || true)"
  echo "$CREATE_OUT"
  DB_ID="$(printf "%s" "$CREATE_OUT" | grep -Eo '[0-9a-fA-F-]{36}' | head -n1 || true)"
  if [ -z "$DB_ID" ]; then
    echo "Gagal mengambil database_id otomatis."
    echo "Silakan ganti __DB_ID__ di wrangler.jsonc secara manual lalu jalankan lagi."
    exit 1
  fi

  if command -v python3 >/dev/null 2>&1; then
python3 - <<PY
from pathlib import Path
p = Path("wrangler.jsonc")
p.write_text(p.read_text().replace("__DB_ID__", "${DB_ID}"))
PY
  else
    sed -i "s/__DB_ID__/${DB_ID}/g" wrangler.jsonc
  fi
else
  echo "[5/8] Database ID sudah ada, lewati."
fi

echo "[6/8] Menjalankan schema D1..."
npx wrangler d1 execute tempmail-db --file=./schema.sql

echo "[7/8] Deploy Worker..."
npx wrangler deploy

echo
echo "[8/8] Selesai."
echo "Worker sudah dideploy."
echo "Masih perlu 2 langkah manual di Cloudflare Dashboard:"
echo "1. Tambahkan custom domain ke Worker, misalnya mail.${MAIL_DOMAIN}"
echo "2. Aktifkan Email Routing lalu arahkan catch-all / address ke Worker"
echo
echo "Contoh pakai:"
echo "  bash deploy_all.sh haluboy.org"
echo "  bash deploy_all.sh contoh.com 'contoh.com,mail.contoh.com,inbox.contoh.com,temp.contoh.com'"
