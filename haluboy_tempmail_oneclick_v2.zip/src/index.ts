export interface Env {
  DB: D1Database;
  MAIL_DOMAIN: string;
  ALLOWED_DOMAINS: string;
  INBOX_TTL_HOURS: string;
}

type InboxRow = {
  id: string;
  address: string;
  localpart: string;
  domain: string;
  created_at: string;
  expires_at: string;
  created_ip: string | null;
  is_active: number;
};

type MessageRow = {
  id: string;
  inbox_id: string;
  from_email: string | null;
  subject: string | null;
  snippet: string | null;
  body_text: string | null;
  body_html: string | null;
  received_at: string;
  is_read: number;
};

const JSON_HEADERS = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store"
};

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method.toUpperCase();

    if (method === "GET" && path === "/") return html(PUBLIC_INDEX_HTML);
    if (method === "GET" && path === "/style.css") return new Response(PUBLIC_STYLE_CSS, { headers: { "content-type": "text/css; charset=utf-8" } });
    if (method === "GET" && path === "/app.js") return new Response(PUBLIC_APP_JS, { headers: { "content-type": "application/javascript; charset=utf-8" } });
    if (method === "GET" && path === "/config.js") {
      const domains = getAllowedDomains(env);
      const script = `window.__CONFIG__ = ${JSON.stringify({ domains, autoRefreshMs: 5000 })};`;
      return new Response(script, { headers: { "content-type": "application/javascript; charset=utf-8" } });
    }
    if (method === "GET" && path === "/health") return json({ ok: true, service: "haluboy-tempmail", domain: env.MAIL_DOMAIN, domains: getAllowedDomains(env) });

    if (method === "POST" && path === "/api/inboxes") return createInbox(request, env);

    if (method === "GET" && path.startsWith("/api/inboxes/") && path.endsWith("/messages")) {
      const email = decodeURIComponent(path.replace("/api/inboxes/", "").replace("/messages", ""));
      return listMessages(email, env);
    }

    if (method === "GET" && path.startsWith("/api/messages/")) {
      const id = decodeURIComponent(path.replace("/api/messages/", ""));
      return getMessage(id, env);
    }

    if (method === "DELETE" && path.startsWith("/api/inboxes/")) {
      const email = decodeURIComponent(path.replace("/api/inboxes/", ""));
      return deleteInbox(email, env);
    }

    return json({ ok: false, error: "Not found" }, 404);
  },

  async email(message: ForwardableEmailMessage, env: Env): Promise<void> {
    const toEmail = String(message.to || "").trim().toLowerCase();
    const inbox = await env.DB.prepare("SELECT * FROM inboxes WHERE address = ? AND is_active = 1 LIMIT 1").bind(toEmail).first<InboxRow>();
    if (!inbox) {
      message.setReject("Inbox not found");
      return;
    }
    const rawText = await new Response(message.raw).text();
    const subject = message.headers.get("subject") || "(No subject)";
    const fromEmail = String(message.from || "");
    const bodyText = rawText.slice(0, 12000);
    const bodyHtml = rawText.includes("<html") ? rawText.slice(0, 12000) : "";
    const snippet = bodyText.replace(/\s+/g, " ").trim().slice(0, 180);

    await env.DB.prepare(
      "INSERT INTO messages (id, inbox_id, from_email, subject, snippet, body_text, body_html, received_at, is_read) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)"
    ).bind(crypto.randomUUID(), inbox.id, fromEmail, subject, snippet, bodyText, bodyHtml, new Date().toISOString()).run();
  }
};

async function createInbox(request: Request, env: Env): Promise<Response> {
  const body = await safeJson(request);
  const usernameInput = cleanLocalpart(String(body?.username || ""));
  const localpart = usernameInput || randomLocalpart();
  const allowedDomains = getAllowedDomains(env);
  const domain = String(body?.domain || env.MAIL_DOMAIN || "").toLowerCase();

  if (!allowedDomains.includes(domain)) return json({ ok: false, error: "Domain tidak diizinkan" }, 400);

  const address = `${localpart}@${domain}`;
  const exists = await env.DB.prepare("SELECT id FROM inboxes WHERE address = ? LIMIT 1").bind(address).first();
  if (exists) return json({ ok: false, error: "Email sudah dipakai, coba username lain" }, 409);

  const now = new Date();
  const expiresAt = new Date(now.getTime() + Number(env.INBOX_TTL_HOURS || 24) * 60 * 60 * 1000).toISOString();
  const id = crypto.randomUUID();
  const ip = request.headers.get("CF-Connecting-IP") || "0.0.0.0";

  await env.DB.prepare("INSERT INTO inboxes (id, address, localpart, domain, created_at, expires_at, created_ip, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, 1)")
    .bind(id, address, localpart, domain, now.toISOString(), expiresAt, ip).run();

  return json({ ok: true, inbox: { id, address, created_at: now.toISOString(), expires_at: expiresAt } }, 201);
}

async function listMessages(address: string, env: Env): Promise<Response> {
  const inbox = await env.DB.prepare("SELECT * FROM inboxes WHERE address = ? AND is_active = 1 LIMIT 1").bind(String(address).toLowerCase()).first<InboxRow>();
  if (!inbox) return json({ ok: false, error: "Inbox tidak ditemukan" }, 404);

  const rows = await env.DB.prepare("SELECT id, from_email, subject, snippet, received_at, is_read FROM messages WHERE inbox_id = ? ORDER BY received_at DESC LIMIT 100")
    .bind(inbox.id).all<MessageRow>();

  return json({ ok: true, inbox: { address: inbox.address, expires_at: inbox.expires_at }, messages: rows.results || [] });
}

async function getMessage(id: string, env: Env): Promise<Response> {
  const row = await env.DB.prepare("SELECT id, from_email, subject, snippet, body_text, body_html, received_at, is_read FROM messages WHERE id = ? LIMIT 1")
    .bind(id).first<MessageRow>();
  if (!row) return json({ ok: false, error: "Message tidak ditemukan" }, 404);
  await env.DB.prepare("UPDATE messages SET is_read = 1 WHERE id = ?").bind(id).run();
  return json({ ok: true, message: row });
}

async function deleteInbox(address: string, env: Env): Promise<Response> {
  const inbox = await env.DB.prepare("SELECT * FROM inboxes WHERE address = ? LIMIT 1").bind(String(address).toLowerCase()).first<InboxRow>();
  if (!inbox) return json({ ok: false, error: "Inbox tidak ditemukan" }, 404);
  await env.DB.prepare("DELETE FROM messages WHERE inbox_id = ?").bind(inbox.id).run();
  await env.DB.prepare("DELETE FROM inboxes WHERE id = ?").bind(inbox.id).run();
  return json({ ok: true, deleted: inbox.address });
}

function getAllowedDomains(env: Env): string[] {
  return String(env.ALLOWED_DOMAINS || env.MAIL_DOMAIN || "").split(",").map(v => v.trim().toLowerCase()).filter(Boolean);
}
function cleanLocalpart(value: string): string {
  return String(value || "").trim().toLowerCase().replace(/[^a-z0-9._-]/g, "").replace(/^[._-]+|[._-]+$/g, "").slice(0, 24);
}
function randomLocalpart(): string {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let out = "hb";
  for (let i = 0; i < 8; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}
async function safeJson(request: Request): Promise<any> { try { return await request.json(); } catch { return {}; } }
function json(data: unknown, status = 200): Response { return new Response(JSON.stringify(data, null, 2), { status, headers: JSON_HEADERS }); }
function html(content: string): Response { return new Response(content, { headers: { "content-type": "text/html; charset=utf-8" } }); }

const PUBLIC_INDEX_HTML = "<!DOCTYPE html>\n<html lang=\"id\">\n<head>\n  <meta charset=\"UTF-8\" />\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n  <title>Haluboy TempMail Premium</title>\n  <link rel=\"stylesheet\" href=\"/style.css\" />\n</head>\n<body>\n  <div class=\"app-bg\"></div>\n  <div class=\"container\">\n    <header class=\"topbar glass\">\n      <div class=\"brand-wrap\">\n        <div class=\"brand-icon\">\u2709</div>\n        <div>\n          <div class=\"brand-title\">TempMail</div>\n          <div class=\"brand-subtitle\">Premium disposable inbox</div>\n        </div>\n      </div>\n      <div class=\"topbar-actions\">\n        <button class=\"icon-btn\" id=\"themeBtn\" title=\"Theme\">\u263e</button>\n        <button class=\"icon-btn\" id=\"helpBtn\" title=\"Help\">?</button>\n      </div>\n    </header>\n\n    <section class=\"hero glass\">\n      <div class=\"hero-head\">\n        <div>\n          <div class=\"eyebrow\">Temporary Inbox</div>\n          <h1>TempMail Premium</h1>\n          <p class=\"hero-text\">Generate inbox cepat, ganti domain, copy email, refresh otomatis, dan buka detail email langsung dari dashboard.</p>\n        </div>\n        <div class=\"hero-badge\">\n          <span class=\"dot\"></span>\n          <span id=\"refreshLabel\">Auto refresh 5s</span>\n        </div>\n      </div>\n\n      <div class=\"generator-panel\">\n        <div class=\"generator-grid\">\n          <div class=\"field\">\n            <label>Username</label>\n            <input id=\"usernameInput\" type=\"text\" placeholder=\"contoh: rayyan\" />\n          </div>\n\n          <div class=\"field\">\n            <label>Domain</label>\n            <select id=\"domainSelect\"></select>\n          </div>\n\n          <div class=\"field field-small\">\n            <label>Sort</label>\n            <select id=\"sortSelect\">\n              <option value=\"newest\">Newest</option>\n              <option value=\"oldest\">Oldest</option>\n            </select>\n          </div>\n        </div>\n\n        <div class=\"action-row\">\n          <button class=\"secondary-btn\" id=\"randomBtn\">Random</button>\n          <button class=\"primary-btn\" id=\"createBtn\">Create Email</button>\n        </div>\n      </div>\n\n      <div class=\"inbox-hero\">\n        <div class=\"mailbox-icon\">\u2709</div>\n        <div class=\"mailbox-content\">\n          <div class=\"label\">Active inbox</div>\n          <div class=\"email-line\">\n            <div class=\"email-value\" id=\"emailValue\">Belum ada email</div>\n            <button class=\"tiny-btn\" id=\"copyBtn\" title=\"Copy email\">\u29c9</button>\n          </div>\n          <div class=\"meta-line\" id=\"expiryInfo\">Inbox akan muncul di sini setelah dibuat.</div>\n        </div>\n      </div>\n\n      <div class=\"hero-actions\">\n        <button class=\"action-btn\" id=\"refreshBtn\">Refresh</button>\n        <button class=\"action-btn\" id=\"newBtn\">New Inbox</button>\n        <button class=\"action-btn danger\" id=\"deleteBtn\">Delete Inbox</button>\n      </div>\n    </section>\n\n    <section class=\"stats-row\">\n      <div class=\"stat-card glass\">\n        <div class=\"stat-label\">Messages</div>\n        <div class=\"stat-value\" id=\"messageCount\">0</div>\n      </div>\n      <div class=\"stat-card glass\">\n        <div class=\"stat-label\">Domain</div>\n        <div class=\"stat-value stat-small\" id=\"activeDomain\">-</div>\n      </div>\n      <div class=\"stat-card glass\">\n        <div class=\"stat-label\">Status</div>\n        <div class=\"stat-value stat-small\">Live</div>\n      </div>\n    </section>\n\n    <section class=\"list-wrap\">\n      <div class=\"empty-state glass\" id=\"emptyState\">\n        <div class=\"empty-icon\">\u2302</div>\n        <h3>Your inbox is empty</h3>\n        <p>Waiting for incoming emails. They will appear here automatically.</p>\n      </div>\n\n      <div class=\"message-list glass hidden\" id=\"messageList\"></div>\n    </section>\n  </div>\n\n  <div class=\"modal hidden\" id=\"messageModal\">\n    <div class=\"modal-card glass\">\n      <div class=\"modal-header\">\n        <div>\n          <h3 id=\"modalSubject\">Detail email</h3>\n          <div class=\"modal-meta\" id=\"modalMeta\"></div>\n        </div>\n        <button class=\"icon-btn\" id=\"closeModal\">\u2715</button>\n      </div>\n\n      <div class=\"tab-row\">\n        <button class=\"tab-btn active\" data-tab=\"text\">Text</button>\n        <button class=\"tab-btn\" data-tab=\"html\">HTML</button>\n      </div>\n\n      <pre class=\"modal-body\" id=\"modalTextBody\">Loading...</pre>\n      <div class=\"modal-html hidden\" id=\"modalHtmlBody\"></div>\n    </div>\n  </div>\n\n  <div class=\"toast\" id=\"toast\"></div>\n  <script src=\"/config.js\"></script>\n  <script src=\"/app.js\"></script>\n</body>\n</html>\n";
const PUBLIC_STYLE_CSS = ":root{\n  --bg:#050f24;\n  --bg-2:#0a1737;\n  --glass:rgba(14,27,60,.78);\n  --glass-2:rgba(17,33,71,.82);\n  --line:rgba(152,174,255,.12);\n  --text:#f7f9ff;\n  --muted:#9dadd6;\n  --primary:#6c5cff;\n  --primary-2:#8276ff;\n  --success:#28d17a;\n  --danger:#ff507e;\n  --shadow:0 18px 70px rgba(0,0,0,.34);\n}\n*{box-sizing:border-box}\nhtml,body{margin:0;padding:0}\nbody{\n  min-height:100vh;\n  font-family:Inter,ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;\n  color:var(--text);\n  background:\n    radial-gradient(circle at 15% 8%, rgba(109,91,255,.22), transparent 18%),\n    radial-gradient(circle at 88% 12%, rgba(69,120,255,.16), transparent 18%),\n    radial-gradient(circle at 18% 86%, rgba(109,91,255,.12), transparent 20%),\n    linear-gradient(180deg,var(--bg) 0%,var(--bg-2) 100%);\n}\n.app-bg{position:fixed; inset:0; pointer-events:none; background-image:linear-gradient(rgba(255,255,255,.02) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.02) 1px, transparent 1px); background-size:32px 32px; mask-image:linear-gradient(180deg, rgba(0,0,0,.8), transparent 100%)}\n.container{width:min(100%,1120px);margin:0 auto;padding:20px 16px 44px}\n.glass{background:linear-gradient(180deg,var(--glass-2),var(--glass));border:1px solid var(--line);box-shadow:var(--shadow);backdrop-filter:blur(12px)}\n.topbar{border-radius:22px;padding:16px 18px;display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:18px}\n.brand-wrap{display:flex;align-items:center;gap:14px}\n.brand-icon,.mailbox-icon,.empty-icon{display:grid;place-items:center;background:linear-gradient(180deg, rgba(116,103,255,.28), rgba(116,103,255,.12));border:1px solid rgba(145,136,255,.2)}\n.brand-icon{width:54px;height:54px;border-radius:18px;font-size:24px}\n.brand-title{font-size:22px;font-weight:800;letter-spacing:-.03em}\n.brand-subtitle{font-size:13px;color:var(--muted)}\n.topbar-actions{display:flex;gap:10px}\n.icon-btn{width:44px;height:44px;border-radius:14px;border:1px solid var(--line);background:rgba(9,20,47,.8);color:var(--text);cursor:pointer;font-weight:700}\n.hero{border-radius:28px;padding:24px;margin-bottom:18px;position:relative;overflow:hidden}\n.hero:before{content:\"\";position:absolute;right:-120px;top:-120px;width:280px;height:280px;border-radius:999px;background:radial-gradient(circle, rgba(108,92,255,.18), transparent 65%)}\n.hero-head{display:flex;align-items:flex-start;justify-content:space-between;gap:20px;margin-bottom:20px;position:relative;z-index:1}\n.eyebrow{font-size:13px;color:var(--muted);text-transform:uppercase;letter-spacing:.08em}\nh1{margin:4px 0 10px;font-size:42px;line-height:1;font-weight:900;letter-spacing:-.04em}\n.hero-text{margin:0;color:var(--muted);line-height:1.7;max-width:720px}\n.hero-badge{min-height:50px;padding:0 16px;border-radius:16px;display:inline-flex;align-items:center;gap:10px;background:rgba(9,20,47,.72);border:1px solid var(--line);white-space:nowrap}\n.dot{width:12px;height:12px;border-radius:999px;background:var(--success);box-shadow:0 0 0 4px rgba(40,209,122,.16)}\n.generator-panel{position:relative;z-index:1;background:rgba(8,18,43,.5);border:1px solid var(--line);border-radius:22px;padding:16px;margin-bottom:18px}\n.generator-grid{display:grid;grid-template-columns:1.3fr 1fr .7fr;gap:14px}\n.field label{display:block;font-size:13px;color:var(--muted);margin-bottom:8px}\ninput,select{width:100%;height:54px;border-radius:16px;border:1px solid var(--line);background:rgba(10,22,50,.8);color:var(--text);padding:0 16px;font-size:15px;outline:none}\n.action-row{display:flex;gap:12px;justify-content:flex-end;margin-top:14px}\n.primary-btn,.secondary-btn,.action-btn,.tab-btn{cursor:pointer;font-weight:800;color:#fff;transition:.18s ease}\n.primary-btn{border:none;height:54px;padding:0 22px;border-radius:16px;background:linear-gradient(180deg,var(--primary-2),var(--primary));box-shadow:0 14px 34px rgba(108,92,255,.34)}\n.secondary-btn,.action-btn{height:54px;padding:0 18px;border-radius:16px;background:rgba(10,22,50,.8);border:1px solid var(--line)}\n.action-btn.danger{background:rgba(77,16,38,.72);border-color:rgba(255,80,126,.16);color:#ffc4d3}\n.inbox-hero{display:flex;align-items:center;gap:16px;margin-bottom:18px;position:relative;z-index:1}\n.mailbox-icon{width:78px;height:78px;border-radius:24px;font-size:34px;flex:0 0 auto}\n.label{font-size:13px;color:var(--muted);margin-bottom:4px}\n.email-line{display:flex;align-items:center;gap:10px;flex-wrap:wrap}\n.email-value{font-size:26px;font-weight:800;letter-spacing:-.03em;word-break:break-all}\n.tiny-btn{width:38px;height:38px;border-radius:12px;border:1px solid var(--line);background:rgba(10,22,50,.7);color:var(--text);cursor:pointer}\n.meta-line{margin-top:8px;color:var(--muted);font-size:14px}\n.hero-actions{display:flex;gap:12px;flex-wrap:wrap;position:relative;z-index:1}\n.stats-row{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:18px}\n.stat-card{border-radius:22px;padding:18px}\n.stat-label{font-size:13px;color:var(--muted);margin-bottom:10px}\n.stat-value{font-size:30px;font-weight:900;letter-spacing:-.04em}\n.stat-small{font-size:20px}\n.list-wrap{min-height:420px}\n.empty-state,.message-list{border-radius:26px}\n.empty-state{min-height:420px;padding:36px 24px;display:grid;place-items:center;text-align:center}\n.empty-icon{width:90px;height:90px;border-radius:999px;font-size:34px;margin:0 auto 18px}\n.empty-state h3{margin:0 0 10px;font-size:26px}\n.empty-state p{margin:0;color:var(--muted);font-size:18px;line-height:1.7}\n.message-list{overflow:hidden}\n.message-item{display:grid;grid-template-columns:1fr auto;gap:14px;padding:18px 20px;border-bottom:1px solid rgba(155,178,255,.08);cursor:pointer;transition:background .18s ease, transform .18s ease}\n.message-item:hover{background:rgba(255,255,255,.02);transform:translateY(-1px)}\n.message-item:last-child{border-bottom:0}\n.from{font-size:16px;font-weight:800;margin-bottom:6px}\n.subject{font-size:16px;margin-bottom:4px}\n.snippet{font-size:14px;line-height:1.6;color:var(--muted)}\n.time{font-size:13px;color:var(--muted);white-space:nowrap;margin-left:18px}\n.modal{position:fixed;inset:0;background:rgba(3,10,24,.76);display:flex;align-items:center;justify-content:center;padding:16px;z-index:20}\n.modal.hidden{display:none}\n.modal-card{width:min(100%,920px);max-height:88vh;overflow:auto;border-radius:26px;padding:20px}\n.modal-header{display:flex;justify-content:space-between;gap:14px;margin-bottom:14px}\n.modal-header h3{margin:0 0 8px;font-size:24px}\n.modal-meta{color:var(--muted);font-size:14px;line-height:1.7}\n.tab-row{display:flex;gap:10px;margin-bottom:12px}\n.tab-btn{height:42px;padding:0 14px;border-radius:12px;background:rgba(10,22,50,.7);border:1px solid var(--line)}\n.tab-btn.active{background:linear-gradient(180deg,var(--primary-2),var(--primary));border-color:transparent}\n.modal-body,.modal-html{margin:0;border-radius:18px;border:1px solid rgba(155,178,255,.08);background:rgba(8,18,43,.82);padding:16px;color:#eef2ff}\n.modal-body{white-space:pre-wrap;word-break:break-word;line-height:1.7;min-height:280px}\n.modal-html{min-height:280px;overflow:auto}\n.hidden{display:none !important}\n.toast{position:fixed;left:50%;bottom:22px;transform:translateX(-50%);background:rgba(12,24,54,.96);border:1px solid var(--line);color:#fff;padding:12px 16px;border-radius:16px;font-size:14px;box-shadow:var(--shadow);opacity:0;pointer-events:none;transition:opacity .2s ease, transform .2s ease;z-index:30}\n.toast.show{opacity:1;transform:translateX(-50%) translateY(-6px)}\n@media (max-width:900px){.generator-grid{grid-template-columns:1fr}.action-row{justify-content:stretch}.action-row button{flex:1}.hero-head{flex-direction:column}.stats-row{grid-template-columns:1fr}}\n@media (max-width:720px){.container{padding:16px 12px 30px}h1{font-size:30px}.email-value{font-size:18px}.hero-actions,.topbar{flex-wrap:wrap}.message-item{grid-template-columns:1fr}.time{margin-left:0}}\n";
const PUBLIC_APP_JS = "const CONFIG = window.__CONFIG__ || { domains: ['haluboy.org'], autoRefreshMs: 5000 };\n\nconst state = {\n  currentEmail: localStorage.getItem('tempmail_current_email') || '',\n  currentDomain: localStorage.getItem('tempmail_domain') || CONFIG.domains[0],\n  messages: [],\n  expiresAt: '',\n  countdown: Math.floor((CONFIG.autoRefreshMs || 5000) / 1000),\n  sort: 'newest',\n  toastTimer: null,\n  countdownTimer: null,\n  pollTimer: null\n};\n\nconst $ = (id) => document.getElementById(id);\nconst usernameInput = $('usernameInput');\nconst domainSelect = $('domainSelect');\nconst sortSelect = $('sortSelect');\nconst emailValue = $('emailValue');\nconst expiryInfo = $('expiryInfo');\nconst activeDomain = $('activeDomain');\nconst messageCount = $('messageCount');\nconst refreshLabel = $('refreshLabel');\nconst emptyState = $('emptyState');\nconst messageList = $('messageList');\nconst toast = $('toast');\nconst modal = $('messageModal');\nconst modalSubject = $('modalSubject');\nconst modalMeta = $('modalMeta');\nconst modalTextBody = $('modalTextBody');\nconst modalHtmlBody = $('modalHtmlBody');\n\nfunction initDomains(){\n  domainSelect.innerHTML = (CONFIG.domains || []).map(d => `<option value=\"${d}\">${d}</option>`).join('');\n  domainSelect.value = state.currentDomain;\n  activeDomain.textContent = state.currentDomain;\n}\nfunction randomUsername(){ const chars='abcdefghijklmnopqrstuvwxyz0123456789'; let out='hb'; for(let i=0;i<9;i++) out += chars[Math.floor(Math.random()*chars.length)]; return out; }\nfunction escapeHtml(str){ return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\"/g,'&quot;').replace(/'/g,'&#039;'); }\nfunction showToast(msg){ toast.textContent=msg; toast.classList.add('show'); clearTimeout(state.toastTimer); state.toastTimer=setTimeout(()=>toast.classList.remove('show'),1800); }\nfunction setEmail(email, expiresAt=''){ state.currentEmail=email||''; state.expiresAt=expiresAt||''; if(state.currentEmail) localStorage.setItem('tempmail_current_email', state.currentEmail); else localStorage.removeItem('tempmail_current_email'); emailValue.textContent=state.currentEmail||'Belum ada email'; expiryInfo.textContent=state.expiresAt?('Expired: '+formatDate(state.expiresAt)):'Inbox akan muncul di sini setelah dibuat.'; }\nfunction formatDate(value){ if(!value) return '-'; try{ return new Date(value).toLocaleString('id-ID',{year:'numeric',month:'short',day:'2-digit',hour:'2-digit',minute:'2-digit'});}catch{return value;} }\n\nasync function createInbox(){\n  try{\n    $('createBtn').disabled = true;\n    const username = usernameInput.value.trim();\n    const domain = domainSelect.value;\n    state.currentDomain = domain;\n    localStorage.setItem('tempmail_domain', domain);\n    activeDomain.textContent = domain;\n    const res = await fetch('/api/inboxes',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({ username, domain })});\n    const data = await res.json();\n    if(!res.ok || !data.ok) throw new Error(data.error || 'Gagal membuat inbox');\n    setEmail(data.inbox.address, data.inbox.expires_at);\n    state.messages = [];\n    renderMessages();\n    showToast('Inbox berhasil dibuat');\n    await loadMessages(true);\n  }catch(err){ showToast(err.message || 'Gagal membuat inbox'); }\n  finally{ $('createBtn').disabled = false; }\n}\n\nasync function loadMessages(force=false){\n  if(!state.currentEmail){ renderMessages(); return; }\n  try{\n    const res = await fetch('/api/inboxes/' + encodeURIComponent(state.currentEmail) + '/messages');\n    const data = await res.json();\n    if(!res.ok || !data.ok) throw new Error(data.error || 'Gagal memuat pesan');\n    state.messages = Array.isArray(data.messages) ? data.messages.slice() : [];\n    if(data.inbox && data.inbox.expires_at) setEmail(state.currentEmail, data.inbox.expires_at);\n    renderMessages();\n    if(force) showToast('Inbox diperbarui');\n  }catch(err){ showToast(err.message || 'Gagal memuat pesan'); }\n}\n\nfunction renderMessages(){\n  const list = [...state.messages];\n  list.sort((a,b)=>{ const ta = new Date(a.received_at || 0).getTime(); const tb = new Date(b.received_at || 0).getTime(); return state.sort === 'oldest' ? ta - tb : tb - ta; });\n  messageCount.textContent = String(list.length);\n  if(!list.length){ emptyState.classList.remove('hidden'); messageList.classList.add('hidden'); messageList.innerHTML=''; return; }\n  emptyState.classList.add('hidden'); messageList.classList.remove('hidden');\n  messageList.innerHTML = list.map(m => `\n    <div class=\"message-item\" data-id=\"${escapeHtml(m.id)}\">\n      <div>\n        <div class=\"from\">${escapeHtml(m.from_email || 'unknown sender')}</div>\n        <div class=\"subject\">${escapeHtml(m.subject || '(No subject)')}</div>\n        <div class=\"snippet\">${escapeHtml(m.snippet || '')}</div>\n      </div>\n      <div class=\"time\">${escapeHtml(formatDate(m.received_at))}</div>\n    </div>`).join('');\n  [...messageList.querySelectorAll('.message-item')].forEach(el => el.addEventListener('click', ()=>openMessage(el.dataset.id)));\n}\n\nasync function openMessage(id){\n  if(!id) return;\n  modal.classList.remove('hidden');\n  modalSubject.textContent='Loading...'; modalMeta.textContent=''; modalTextBody.textContent='Loading...'; modalHtmlBody.innerHTML='';\n  try{\n    const res = await fetch('/api/messages/' + encodeURIComponent(id));\n    const data = await res.json();\n    if(!res.ok || !data.ok) throw new Error(data.error || 'Gagal membuka email');\n    const m = data.message;\n    modalSubject.textContent = m.subject || '(No subject)';\n    modalMeta.innerHTML = `From: ${escapeHtml(m.from_email || 'unknown')}<br>Received: ${escapeHtml(formatDate(m.received_at))}`;\n    modalTextBody.textContent = m.body_text || stripHtml(m.body_html || '') || 'Tidak ada isi email';\n    modalHtmlBody.innerHTML = m.body_html || '<div style=\"color:#9dadd6\">Tidak ada HTML body.</div>';\n    switchTab('text');\n  }catch(err){ modalSubject.textContent='Gagal'; modalTextBody.textContent = err.message || 'Terjadi kesalahan'; modalHtmlBody.innerHTML=''; }\n}\nfunction switchTab(tab){ document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.toggle('active', btn.dataset.tab === tab)); modalTextBody.classList.toggle('hidden', tab !== 'text'); modalHtmlBody.classList.toggle('hidden', tab !== 'html'); }\nfunction stripHtml(html){ const div=document.createElement('div'); div.innerHTML=html; return (div.textContent||div.innerText||'').trim(); }\n\nasync function deleteInbox(){\n  if(!state.currentEmail) return showToast('Belum ada inbox');\n  if(!confirm('Hapus inbox ini?')) return;\n  try{\n    const res = await fetch('/api/inboxes/' + encodeURIComponent(state.currentEmail), { method:'DELETE' });\n    const data = await res.json();\n    if(!res.ok || !data.ok) throw new Error(data.error || 'Gagal menghapus inbox');\n    setEmail('', ''); state.messages=[]; renderMessages(); showToast('Inbox dihapus');\n  }catch(err){ showToast(err.message || 'Gagal menghapus inbox'); }\n}\nfunction startTimers(){\n  stopTimers(); state.countdown = Math.floor((CONFIG.autoRefreshMs || 5000) / 1000); refreshLabel.textContent='Auto refresh '+state.countdown+'s';\n  state.countdownTimer=setInterval(()=>{ state.countdown-=1; if(state.countdown<=0) state.countdown=Math.floor((CONFIG.autoRefreshMs||5000)/1000); refreshLabel.textContent='Auto refresh '+state.countdown+'s'; },1000);\n  state.pollTimer=setInterval(()=>loadMessages(), CONFIG.autoRefreshMs || 5000);\n}\nfunction stopTimers(){ if(state.countdownTimer) clearInterval(state.countdownTimer); if(state.pollTimer) clearInterval(state.pollTimer); }\n\n$('randomBtn').addEventListener('click', ()=>{ usernameInput.value=randomUsername(); });\n$('createBtn').addEventListener('click', createInbox);\n$('refreshBtn').addEventListener('click', ()=>loadMessages(true));\n$('newBtn').addEventListener('click', ()=>{ usernameInput.value=randomUsername(); createInbox(); });\n$('deleteBtn').addEventListener('click', deleteInbox);\n$('copyBtn').addEventListener('click', async ()=>{ if(!state.currentEmail) return showToast('Belum ada email'); await navigator.clipboard.writeText(state.currentEmail); showToast('Email disalin'); });\n$('closeModal').addEventListener('click', ()=>modal.classList.add('hidden'));\nmodal.addEventListener('click', (e)=>{ if(e.target===modal) modal.classList.add('hidden'); });\nsortSelect.addEventListener('change', ()=>{ state.sort=sortSelect.value; renderMessages(); });\ndomainSelect.addEventListener('change', ()=>{ state.currentDomain=domainSelect.value; localStorage.setItem('tempmail_domain', state.currentDomain); activeDomain.textContent=state.currentDomain; });\ndocument.querySelectorAll('.tab-btn').forEach(btn => btn.addEventListener('click', ()=>switchTab(btn.dataset.tab)));\n\nwindow.addEventListener('DOMContentLoaded', async ()=>{\n  initDomains(); usernameInput.value=randomUsername();\n  if(state.currentEmail){ setEmail(state.currentEmail, ''); await loadMessages(); }\n  startTimers();\n});\n";
