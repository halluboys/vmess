HALUBOY TEMPMAIL ONE-CLICK V2

Versi ini mendukung argumen domain saat deploy.

Contoh:
  bash deploy_all.sh haluboy.org

Atau kalau mau domain tambahan kustom:
  bash deploy_all.sh haluboy.org "haluboy.org,mail.haluboy.org,inbox.haluboy.org,temp.haluboy.org"

Yang dilakukan script:
- install dependency
- cek/login wrangler
- isi MAIL_DOMAIN dan ALLOWED_DOMAINS otomatis ke wrangler.jsonc
- buat D1 database
- ambil database_id dan masukkan ke config
- jalankan schema.sql
- deploy worker

Yang tetap manual:
- custom domain Worker di dashboard Cloudflare
- Email Routing ke Worker

Isi project:
- deploy_all.sh
- package.json
- wrangler.jsonc
- schema.sql
- src/index.ts
- public/index.html
- public/style.css
- public/app.js
