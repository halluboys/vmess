const CONFIG = window.__CONFIG__ || { domains: ['haluboy.org'], autoRefreshMs: 5000 };

const state = {
  currentEmail: localStorage.getItem('tempmail_current_email') || '',
  currentDomain: localStorage.getItem('tempmail_domain') || CONFIG.domains[0],
  messages: [],
  expiresAt: '',
  countdown: Math.floor((CONFIG.autoRefreshMs || 5000) / 1000),
  sort: 'newest',
  toastTimer: null,
  countdownTimer: null,
  pollTimer: null
};

const $ = (id) => document.getElementById(id);
const usernameInput = $('usernameInput');
const domainSelect = $('domainSelect');
const sortSelect = $('sortSelect');
const emailValue = $('emailValue');
const expiryInfo = $('expiryInfo');
const activeDomain = $('activeDomain');
const messageCount = $('messageCount');
const refreshLabel = $('refreshLabel');
const emptyState = $('emptyState');
const messageList = $('messageList');
const toast = $('toast');
const modal = $('messageModal');
const modalSubject = $('modalSubject');
const modalMeta = $('modalMeta');
const modalTextBody = $('modalTextBody');
const modalHtmlBody = $('modalHtmlBody');

function initDomains(){
  domainSelect.innerHTML = (CONFIG.domains || []).map(d => `<option value="${d}">${d}</option>`).join('');
  domainSelect.value = state.currentDomain;
  activeDomain.textContent = state.currentDomain;
}
function randomUsername(){ const chars='abcdefghijklmnopqrstuvwxyz0123456789'; let out='hb'; for(let i=0;i<9;i++) out += chars[Math.floor(Math.random()*chars.length)]; return out; }
function escapeHtml(str){ return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
function showToast(msg){ toast.textContent=msg; toast.classList.add('show'); clearTimeout(state.toastTimer); state.toastTimer=setTimeout(()=>toast.classList.remove('show'),1800); }
function setEmail(email, expiresAt=''){ state.currentEmail=email||''; state.expiresAt=expiresAt||''; if(state.currentEmail) localStorage.setItem('tempmail_current_email', state.currentEmail); else localStorage.removeItem('tempmail_current_email'); emailValue.textContent=state.currentEmail||'Belum ada email'; expiryInfo.textContent=state.expiresAt?('Expired: '+formatDate(state.expiresAt)):'Inbox akan muncul di sini setelah dibuat.'; }
function formatDate(value){ if(!value) return '-'; try{ return new Date(value).toLocaleString('id-ID',{year:'numeric',month:'short',day:'2-digit',hour:'2-digit',minute:'2-digit'});}catch{return value;} }

async function createInbox(){
  try{
    $('createBtn').disabled = true;
    const username = usernameInput.value.trim();
    const domain = domainSelect.value;
    state.currentDomain = domain;
    localStorage.setItem('tempmail_domain', domain);
    activeDomain.textContent = domain;
    const res = await fetch('/api/inboxes',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({ username, domain })});
    const data = await res.json();
    if(!res.ok || !data.ok) throw new Error(data.error || 'Gagal membuat inbox');
    setEmail(data.inbox.address, data.inbox.expires_at);
    state.messages = [];
    renderMessages();
    showToast('Inbox berhasil dibuat');
    await loadMessages(true);
  }catch(err){ showToast(err.message || 'Gagal membuat inbox'); }
  finally{ $('createBtn').disabled = false; }
}

async function loadMessages(force=false){
  if(!state.currentEmail){ renderMessages(); return; }
  try{
    const res = await fetch('/api/inboxes/' + encodeURIComponent(state.currentEmail) + '/messages');
    const data = await res.json();
    if(!res.ok || !data.ok) throw new Error(data.error || 'Gagal memuat pesan');
    state.messages = Array.isArray(data.messages) ? data.messages.slice() : [];
    if(data.inbox && data.inbox.expires_at) setEmail(state.currentEmail, data.inbox.expires_at);
    renderMessages();
    if(force) showToast('Inbox diperbarui');
  }catch(err){ showToast(err.message || 'Gagal memuat pesan'); }
}

function renderMessages(){
  const list = [...state.messages];
  list.sort((a,b)=>{ const ta = new Date(a.received_at || 0).getTime(); const tb = new Date(b.received_at || 0).getTime(); return state.sort === 'oldest' ? ta - tb : tb - ta; });
  messageCount.textContent = String(list.length);
  if(!list.length){ emptyState.classList.remove('hidden'); messageList.classList.add('hidden'); messageList.innerHTML=''; return; }
  emptyState.classList.add('hidden'); messageList.classList.remove('hidden');
  messageList.innerHTML = list.map(m => `
    <div class="message-item" data-id="${escapeHtml(m.id)}">
      <div>
        <div class="from">${escapeHtml(m.from_email || 'unknown sender')}</div>
        <div class="subject">${escapeHtml(m.subject || '(No subject)')}</div>
        <div class="snippet">${escapeHtml(m.snippet || '')}</div>
      </div>
      <div class="time">${escapeHtml(formatDate(m.received_at))}</div>
    </div>`).join('');
  [...messageList.querySelectorAll('.message-item')].forEach(el => el.addEventListener('click', ()=>openMessage(el.dataset.id)));
}

async function openMessage(id){
  if(!id) return;
  modal.classList.remove('hidden');
  modalSubject.textContent='Loading...'; modalMeta.textContent=''; modalTextBody.textContent='Loading...'; modalHtmlBody.innerHTML='';
  try{
    const res = await fetch('/api/messages/' + encodeURIComponent(id));
    const data = await res.json();
    if(!res.ok || !data.ok) throw new Error(data.error || 'Gagal membuka email');
    const m = data.message;
    modalSubject.textContent = m.subject || '(No subject)';
    modalMeta.innerHTML = `From: ${escapeHtml(m.from_email || 'unknown')}<br>Received: ${escapeHtml(formatDate(m.received_at))}`;
    modalTextBody.textContent = m.body_text || stripHtml(m.body_html || '') || 'Tidak ada isi email';
    modalHtmlBody.innerHTML = m.body_html || '<div style="color:#9dadd6">Tidak ada HTML body.</div>';
    switchTab('text');
  }catch(err){ modalSubject.textContent='Gagal'; modalTextBody.textContent = err.message || 'Terjadi kesalahan'; modalHtmlBody.innerHTML=''; }
}
function switchTab(tab){ document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.toggle('active', btn.dataset.tab === tab)); modalTextBody.classList.toggle('hidden', tab !== 'text'); modalHtmlBody.classList.toggle('hidden', tab !== 'html'); }
function stripHtml(html){ const div=document.createElement('div'); div.innerHTML=html; return (div.textContent||div.innerText||'').trim(); }

async function deleteInbox(){
  if(!state.currentEmail) return showToast('Belum ada inbox');
  if(!confirm('Hapus inbox ini?')) return;
  try{
    const res = await fetch('/api/inboxes/' + encodeURIComponent(state.currentEmail), { method:'DELETE' });
    const data = await res.json();
    if(!res.ok || !data.ok) throw new Error(data.error || 'Gagal menghapus inbox');
    setEmail('', ''); state.messages=[]; renderMessages(); showToast('Inbox dihapus');
  }catch(err){ showToast(err.message || 'Gagal menghapus inbox'); }
}
function startTimers(){
  stopTimers(); state.countdown = Math.floor((CONFIG.autoRefreshMs || 5000) / 1000); refreshLabel.textContent='Auto refresh '+state.countdown+'s';
  state.countdownTimer=setInterval(()=>{ state.countdown-=1; if(state.countdown<=0) state.countdown=Math.floor((CONFIG.autoRefreshMs||5000)/1000); refreshLabel.textContent='Auto refresh '+state.countdown+'s'; },1000);
  state.pollTimer=setInterval(()=>loadMessages(), CONFIG.autoRefreshMs || 5000);
}
function stopTimers(){ if(state.countdownTimer) clearInterval(state.countdownTimer); if(state.pollTimer) clearInterval(state.pollTimer); }

$('randomBtn').addEventListener('click', ()=>{ usernameInput.value=randomUsername(); });
$('createBtn').addEventListener('click', createInbox);
$('refreshBtn').addEventListener('click', ()=>loadMessages(true));
$('newBtn').addEventListener('click', ()=>{ usernameInput.value=randomUsername(); createInbox(); });
$('deleteBtn').addEventListener('click', deleteInbox);
$('copyBtn').addEventListener('click', async ()=>{ if(!state.currentEmail) return showToast('Belum ada email'); await navigator.clipboard.writeText(state.currentEmail); showToast('Email disalin'); });
$('closeModal').addEventListener('click', ()=>modal.classList.add('hidden'));
modal.addEventListener('click', (e)=>{ if(e.target===modal) modal.classList.add('hidden'); });
sortSelect.addEventListener('change', ()=>{ state.sort=sortSelect.value; renderMessages(); });
domainSelect.addEventListener('change', ()=>{ state.currentDomain=domainSelect.value; localStorage.setItem('tempmail_domain', state.currentDomain); activeDomain.textContent=state.currentDomain; });
document.querySelectorAll('.tab-btn').forEach(btn => btn.addEventListener('click', ()=>switchTab(btn.dataset.tab)));

window.addEventListener('DOMContentLoaded', async ()=>{
  initDomains(); usernameInput.value=randomUsername();
  if(state.currentEmail){ setEmail(state.currentEmail, ''); await loadMessages(); }
  startTimers();
});
