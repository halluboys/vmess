export interface Env {
  DB: D1Database;
  PUBLIC_EMAIL_DOMAIN: string;
  APP_DOMAIN: string;
  INBOX_TTL_HOURS: string;
  AUTO_REFRESH_MS: string;
}

type InboxRow = {
  id: string;
  address: string;
  localpart: string;
  domain: string;
  created_at: string;
  expires_at: string;
  created_ip: string | null;
  is_active: number;
};

type MessageRow = {
  id: string;
  inbox_id: string;
  from_email: string | null;
  subject: string | null;
  snippet: string | null;
  body_text: string | null;
  body_html: string | null;
  received_at: string;
  is_read: number;
};

const JSON_HEADERS = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store"
};

const HTML = `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Haluboy TempMail Premium</title>
  <link rel="stylesheet" href="/style.css" />
</head>
<body>
  <div class="app-bg"></div>
  <div class="container">
    <header class="topbar glass">
      <div class="brand-wrap">
        <div class="brand-icon">✉</div>
        <div>
          <div class="brand-title">TempMail</div>
          <div class="brand-subtitle">Premium disposable inbox</div>
        </div>
      </div>
      <div class="topbar-actions">
        <button class="icon-btn" type="button">☾</button>
        <button class="icon-btn" type="button">?</button>
      </div>
    </header>

    <section class="hero glass">
      <div class="hero-head">
        <div>
          <div class="eyebrow">Temporary Inbox</div>
          <h1>TempMail Premium</h1>
          <p class="hero-text">Generate inbox cepat, copy email, refresh otomatis, dan buka detail email langsung dari dashboard.</p>
        </div>
        <div class="hero-badge">
          <span class="dot"></span>
          <span id="refreshLabel">Auto refresh 4s</span>
        </div>
      </div>

      <div class="generator-panel">
        <div class="generator-grid">
          <div class="field">
            <label>Username</label>
            <input id="usernameInput" type="text" placeholder="contoh: naso" />
          </div>

          <div class="field">
            <label>Domain</label>
            <input id="domainValue" type="text" readonly />
          </div>

          <div class="field field-small">
            <label>Sort</label>
            <select id="sortSelect">
              <option value="newest">Newest</option>
              <option value="oldest">Oldest</option>
            </select>
          </div>
        </div>

        <div class="action-row">
          <button class="secondary-btn" id="randomBtn" type="button">Random</button>
          <button class="primary-btn" id="createBtn" type="button">Create Email</button>
        </div>
      </div>

      <div class="inbox-hero">
        <div class="mailbox-icon">✉</div>
        <div class="mailbox-content">
          <div class="label">Active inbox</div>
          <div class="email-line">
            <div class="email-value" id="emailValue">Belum ada email</div>
            <button class="tiny-btn" id="copyBtn" type="button" title="Copy email">⧉</button>
          </div>
          <div class="meta-line" id="expiryInfo">Inbox akan muncul di sini setelah dibuat.</div>
        </div>
      </div>

      <div class="hero-actions">
        <button class="action-btn" id="refreshBtn" type="button">Refresh</button>
        <button class="action-btn" id="newBtn" type="button">New Inbox</button>
        <button class="action-btn danger" id="deleteBtn" type="button">Delete Inbox</button>
      </div>
    </section>

    <section class="stats-row">
      <div class="stat-card glass">
        <div class="stat-label">Messages</div>
        <div class="stat-value" id="messageCount">0</div>
      </div>
      <div class="stat-card glass">
        <div class="stat-label">App domain</div>
        <div class="stat-value stat-small" id="activeAppDomain">-</div>
      </div>
      <div class="stat-card glass">
        <div class="stat-label">Email domain</div>
        <div class="stat-value stat-small" id="activeEmailDomain">-</div>
      </div>
    </section>

    <section class="list-wrap">
      <div class="empty-state glass" id="emptyState">
        <div class="empty-icon">⌂</div>
        <h3>Your inbox is empty</h3>
        <p>Waiting for incoming emails. They will appear here automatically.</p>
      </div>

      <div class="message-list glass hidden" id="messageList"></div>
    </section>
  </div>

  <div class="modal hidden" id="messageModal">
    <div class="modal-card glass">
      <div class="modal-header">
        <div>
          <h3 id="modalSubject">Detail email</h3>
          <div class="modal-meta" id="modalMeta"></div>
        </div>
        <button class="icon-btn" id="closeModal" type="button">✕</button>
      </div>

      <div class="tab-row">
        <button class="tab-btn active" data-tab="text" type="button">Text</button>
        <button class="tab-btn" data-tab="html" type="button">HTML</button>
      </div>

      <pre class="modal-body" id="modalTextBody">Loading...</pre>
      <div class="modal-html hidden" id="modalHtmlBody"></div>
    </div>
  </div>

  <div class="toast" id="toast"></div>
  <script src="/config.js"></script>
  <script src="/app.js"></script>
</body>
</html>`;

const CSS = `:root{
  --bg:#050f24;--bg-2:#0a1737;--glass:rgba(14,27,60,.78);--glass-2:rgba(17,33,71,.82);
  --line:rgba(152,174,255,.12);--text:#f7f9ff;--muted:#9dadd6;--primary:#6c5cff;--primary-2:#8276ff;
  --success:#28d17a;--danger:#ff507e;--shadow:0 18px 70px rgba(0,0,0,.34)}
*{box-sizing:border-box}html,body{margin:0;padding:0}
body{min-height:100vh;font-family:Inter,ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:var(--text);
background:radial-gradient(circle at 15% 8%, rgba(109,91,255,.22), transparent 18%),radial-gradient(circle at 88% 12%, rgba(69,120,255,.16), transparent 18%),radial-gradient(circle at 18% 86%, rgba(109,91,255,.12), transparent 20%),linear-gradient(180deg,var(--bg) 0%,var(--bg-2) 100%)}
.app-bg{position:fixed;inset:0;pointer-events:none;background-image:linear-gradient(rgba(255,255,255,.02) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.02) 1px, transparent 1px);background-size:32px 32px;mask-image:linear-gradient(180deg, rgba(0,0,0,.8), transparent 100%)}
.container{width:min(100%,1120px);margin:0 auto;padding:20px 16px 44px}.glass{background:linear-gradient(180deg,var(--glass-2),var(--glass));border:1px solid var(--line);box-shadow:var(--shadow);backdrop-filter:blur(12px)}
.topbar{border-radius:22px;padding:16px 18px;display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:18px}.brand-wrap{display:flex;align-items:center;gap:14px}
.brand-icon,.mailbox-icon,.empty-icon{display:grid;place-items:center;background:linear-gradient(180deg, rgba(116,103,255,.28), rgba(116,103,255,.12));border:1px solid rgba(145,136,255,.2)}
.brand-icon{width:54px;height:54px;border-radius:18px;font-size:24px}.brand-title{font-size:22px;font-weight:800;letter-spacing:-.03em}.brand-subtitle{font-size:13px;color:var(--muted)}.topbar-actions{display:flex;gap:10px}
.icon-btn{width:44px;height:44px;border-radius:14px;border:1px solid var(--line);background:rgba(9,20,47,.8);color:var(--text);cursor:pointer;font-weight:700}
.hero{border-radius:28px;padding:24px;margin-bottom:18px;position:relative;overflow:hidden}.hero:before{content:"";position:absolute;right:-120px;top:-120px;width:280px;height:280px;border-radius:999px;background:radial-gradient(circle, rgba(108,92,255,.18), transparent 65%)}
.hero-head{display:flex;align-items:flex-start;justify-content:space-between;gap:20px;margin-bottom:20px;position:relative;z-index:1}.eyebrow{font-size:13px;color:var(--muted);text-transform:uppercase;letter-spacing:.08em}
h1{margin:4px 0 10px;font-size:42px;line-height:1;font-weight:900;letter-spacing:-.04em}.hero-text{margin:0;color:var(--muted);line-height:1.7;max-width:720px}
.hero-badge{min-height:50px;padding:0 16px;border-radius:16px;display:inline-flex;align-items:center;gap:10px;background:rgba(9,20,47,.72);border:1px solid var(--line);white-space:nowrap}
.dot{width:12px;height:12px;border-radius:999px;background:var(--success);box-shadow:0 0 0 4px rgba(40,209,122,.16)}
.generator-panel{position:relative;z-index:1;background:rgba(8,18,43,.5);border:1px solid var(--line);border-radius:22px;padding:16px;margin-bottom:18px}
.generator-grid{display:grid;grid-template-columns:1.3fr 1fr .7fr;gap:14px}.field label{display:block;font-size:13px;color:var(--muted);margin-bottom:8px}
input,select{width:100%;height:54px;border-radius:16px;border:1px solid var(--line);background:rgba(10,22,50,.8);color:var(--text);padding:0 16px;font-size:15px;outline:none}
.action-row{display:flex;gap:12px;justify-content:flex-end;margin-top:14px}.primary-btn,.secondary-btn,.action-btn,.tab-btn{cursor:pointer;font-weight:800;color:#fff;transition:.18s ease}
.primary-btn{border:none;height:54px;padding:0 22px;border-radius:16px;background:linear-gradient(180deg,var(--primary-2),var(--primary));box-shadow:0 14px 34px rgba(108,92,255,.34)}
.secondary-btn,.action-btn{height:54px;padding:0 18px;border-radius:16px;background:rgba(10,22,50,.8);border:1px solid var(--line)}.action-btn.danger{background:rgba(77,16,38,.72);border-color:rgba(255,80,126,.16);color:#ffc4d3}
.inbox-hero{display:flex;align-items:center;gap:16px;margin-bottom:18px;position:relative;z-index:1}.mailbox-icon{width:78px;height:78px;border-radius:24px;font-size:34px;flex:0 0 auto}
.label{font-size:13px;color:var(--muted);margin-bottom:4px}.email-line{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.email-value{font-size:26px;font-weight:800;letter-spacing:-.03em;word-break:break-all}
.tiny-btn{width:38px;height:38px;border-radius:12px;border:1px solid var(--line);background:rgba(10,22,50,.7);color:var(--text);cursor:pointer}.meta-line{margin-top:8px;color:var(--muted);font-size:14px}
.hero-actions{display:flex;gap:12px;flex-wrap:wrap;position:relative;z-index:1}.stats-row{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:18px}.stat-card{border-radius:22px;padding:18px}
.stat-label{font-size:13px;color:var(--muted);margin-bottom:10px}.stat-value{font-size:30px;font-weight:900;letter-spacing:-.04em;word-break:break-word}.stat-small{font-size:20px}
.list-wrap{min-height:420px}.empty-state,.message-list{border-radius:26px}.empty-state{min-height:420px;padding:36px 24px;display:grid;place-items:center;text-align:center}
.empty-icon{width:90px;height:90px;border-radius:999px;font-size:34px;margin:0 auto 18px}.empty-state h3{margin:0 0 10px;font-size:26px}.empty-state p{margin:0;color:var(--muted);font-size:18px;line-height:1.7}
.message-list{overflow:hidden}.message-item{display:grid;grid-template-columns:1fr auto;gap:14px;padding:18px 20px;border-bottom:1px solid rgba(155,178,255,.08);cursor:pointer;transition:background .18s ease, transform .18s ease}.message-item:hover{background:rgba(255,255,255,.02);transform:translateY(-1px)}.message-item:last-child{border-bottom:0}
.from{font-size:16px;font-weight:800;margin-bottom:6px}.subject{font-size:16px;margin-bottom:4px}.snippet{font-size:14px;line-height:1.6;color:var(--muted)}.time{font-size:13px;color:var(--muted);white-space:nowrap;margin-left:18px}
.modal{position:fixed;inset:0;background:rgba(3,10,24,.76);display:flex;align-items:center;justify-content:center;padding:16px;z-index:20}.modal.hidden{display:none}.modal-card{width:min(100%,920px);max-height:88vh;overflow:auto;border-radius:26px;padding:20px}.modal-header{display:flex;justify-content:space-between;gap:14px;margin-bottom:14px}.modal-header h3{margin:0 0 8px;font-size:24px}.modal-meta{color:var(--muted);font-size:14px;line-height:1.7}.tab-row{display:flex;gap:10px;margin-bottom:12px}.tab-btn{height:42px;padding:0 14px;border-radius:12px;background:rgba(10,22,50,.7);border:1px solid var(--line)}.tab-btn.active{background:linear-gradient(180deg,var(--primary-2),var(--primary));border-color:transparent}
.modal-body,.modal-html{margin:0;border-radius:18px;border:1px solid rgba(155,178,255,.08);background:rgba(8,18,43,.82);padding:16px;color:#eef2ff}.modal-body{white-space:pre-wrap;word-break:break-word;line-height:1.7;min-height:280px}.modal-html{min-height:280px;overflow:auto}.hidden{display:none !important}
.toast{position:fixed;left:50%;bottom:22px;transform:translateX(-50%);background:rgba(12,24,54,.96);border:1px solid var(--line);color:#fff;padding:12px 16px;border-radius:16px;font-size:14px;box-shadow:var(--shadow);opacity:0;pointer-events:none;transition:opacity .2s ease, transform .2s ease;z-index:30}.toast.show{opacity:1;transform:translateX(-50%) translateY(-6px)}
@media (max-width:900px){.generator-grid{grid-template-columns:1fr}.action-row{justify-content:stretch}.action-row button{flex:1}.hero-head{flex-direction:column}.stats-row{grid-template-columns:1fr}}
@media (max-width:720px){.container{padding:16px 12px 30px}h1{font-size:30px}.email-value{font-size:18px}.hero-actions,.topbar{flex-wrap:wrap}.message-item{grid-template-columns:1fr}.time{margin-left:0}}`;

const JS = `const CONFIG = window.__CONFIG__ || { appDomain: location.hostname, emailDomain: "haluboy.org", autoRefreshMs: 4000 };
const state = { currentEmail: localStorage.getItem("tempmail_current_email") || "", messages: [], expiresAt: "", countdown: Math.floor((CONFIG.autoRefreshMs || 4000) / 1000), sort: "newest", toastTimer: null, countdownTimer: null, pollTimer: null };
const $ = (id) => document.getElementById(id);
const usernameInput = $("usernameInput"), domainValue = $("domainValue"), sortSelect = $("sortSelect"), emailValue = $("emailValue"), expiryInfo = $("expiryInfo"), activeAppDomain = $("activeAppDomain"), activeEmailDomain = $("activeEmailDomain"), messageCount = $("messageCount"), refreshLabel = $("refreshLabel"), emptyState = $("emptyState"), messageList = $("messageList"), toast = $("toast"), modal = $("messageModal"), modalSubject = $("modalSubject"), modalMeta = $("modalMeta"), modalTextBody = $("modalTextBody"), modalHtmlBody = $("modalHtmlBody");
function randomUsername(){ const chars = "abcdefghijklmnopqrstuvwxyz0123456789"; let out = "hb"; for(let i=0;i<10;i++) out += chars[Math.floor(Math.random()*chars.length)]; return out; }
function escapeHtml(str){ return String(str || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"); }
function showToast(msg){ toast.textContent = msg; toast.classList.add("show"); clearTimeout(state.toastTimer); state.toastTimer = setTimeout(() => toast.classList.remove("show"), 1800); }
function setEmail(email, expiresAt = ""){ state.currentEmail = email || ""; state.expiresAt = expiresAt || ""; if(state.currentEmail) localStorage.setItem("tempmail_current_email", state.currentEmail); else localStorage.removeItem("tempmail_current_email"); emailValue.textContent = state.currentEmail || "Belum ada email"; expiryInfo.textContent = state.expiresAt ? "Expired: " + formatDate(state.expiresAt) : "Inbox akan muncul di sini setelah dibuat."; }
function formatDate(value){ if(!value) return "-"; try{ return new Date(value).toLocaleString("id-ID", {year:"numeric", month:"short", day:"2-digit", hour:"2-digit", minute:"2-digit"}); } catch { return value; } }
async function parseJsonResponse(res){ const text = await res.text(); try{ return JSON.parse(text); } catch { throw new Error(text.slice(0, 140) || "Response bukan JSON"); } }
async function createInbox(){ try{ $("createBtn").disabled = true; const username = usernameInput.value.trim(); const res = await fetch("/api/inboxes", { method:"POST", headers:{"content-type":"application/json"}, body:JSON.stringify({ username }) }); const data = await parseJsonResponse(res); if(!res.ok || !data.ok) throw new Error(data.error || "Gagal membuat inbox"); setEmail(data.inbox.address, data.inbox.expires_at); state.messages = []; renderMessages(); showToast("Inbox berhasil dibuat"); await loadMessages(true); } catch(err){ showToast(err.message || "Gagal membuat inbox"); } finally { $("createBtn").disabled = false; } }
async function loadMessages(force = false){ if(!state.currentEmail){ renderMessages(); return; } try{ const res = await fetch("/api/inboxes/" + encodeURIComponent(state.currentEmail) + "/messages"); const data = await parseJsonResponse(res); if(!res.ok || !data.ok) throw new Error(data.error || "Gagal memuat pesan"); state.messages = Array.isArray(data.messages) ? data.messages.slice() : []; if(data.inbox && data.inbox.expires_at) setEmail(state.currentEmail, data.inbox.expires_at); renderMessages(); if(force) showToast("Inbox diperbarui"); } catch(err){ showToast(err.message || "Gagal memuat pesan"); } }
function renderMessages(){ const list = [...state.messages]; list.sort((a,b)=>{ const ta = new Date(a.received_at || 0).getTime(); const tb = new Date(b.received_at || 0).getTime(); return state.sort === "oldest" ? ta - tb : tb - ta; }); messageCount.textContent = String(list.length); if(!list.length){ emptyState.classList.remove("hidden"); messageList.classList.add("hidden"); messageList.innerHTML = ""; return; } emptyState.classList.add("hidden"); messageList.classList.remove("hidden"); messageList.innerHTML = list.map(m => \`<div class="message-item" data-id="\${escapeHtml(m.id)}"><div><div class="from">\${escapeHtml(m.from_email || "unknown sender")}</div><div class="subject">\${escapeHtml(m.subject || "(No subject)")}</div><div class="snippet">\${escapeHtml(m.snippet || "")}</div></div><div class="time">\${escapeHtml(formatDate(m.received_at))}</div></div>\`).join(""); [...messageList.querySelectorAll(".message-item")].forEach(el => el.addEventListener("click", ()=>openMessage(el.dataset.id))); }
async function openMessage(id){ if(!id) return; modal.classList.remove("hidden"); modalSubject.textContent = "Loading..."; modalMeta.textContent = ""; modalTextBody.textContent = "Loading..."; modalHtmlBody.innerHTML = ""; try{ const res = await fetch("/api/messages/" + encodeURIComponent(id)); const data = await parseJsonResponse(res); if(!res.ok || !data.ok) throw new Error(data.error || "Gagal membuka email"); const m = data.message; modalSubject.textContent = m.subject || "(No subject)"; modalMeta.innerHTML = \`From: \${escapeHtml(m.from_email || "unknown")}<br>Received: \${escapeHtml(formatDate(m.received_at))}\`; modalTextBody.textContent = m.body_text || stripHtml(m.body_html || "") || "Tidak ada isi email"; modalHtmlBody.innerHTML = m.body_html || '<div style="color:#9dadd6">Tidak ada HTML body.</div>'; switchTab("text"); } catch(err){ modalSubject.textContent = "Gagal"; modalTextBody.textContent = err.message || "Terjadi kesalahan"; modalHtmlBody.innerHTML = ""; } }
function switchTab(tab){ document.querySelectorAll(".tab-btn").forEach(btn => btn.classList.toggle("active", btn.dataset.tab === tab)); modalTextBody.classList.toggle("hidden", tab !== "text"); modalHtmlBody.classList.toggle("hidden", tab !== "html"); }
function stripHtml(html){ const div = document.createElement("div"); div.innerHTML = html; return (div.textContent || div.innerText || "").trim(); }
async function deleteInbox(){ if(!state.currentEmail) return showToast("Belum ada inbox"); if(!confirm("Hapus inbox ini?")) return; try{ const res = await fetch("/api/inboxes/" + encodeURIComponent(state.currentEmail), { method:"DELETE" }); const data = await parseJsonResponse(res); if(!res.ok || !data.ok) throw new Error(data.error || "Gagal menghapus inbox"); setEmail("", ""); state.messages = []; renderMessages(); showToast("Inbox dihapus"); } catch(err){ showToast(err.message || "Gagal menghapus inbox"); } }
function startTimers(){ stopTimers(); state.countdown = Math.floor((CONFIG.autoRefreshMs || 4000) / 1000); refreshLabel.textContent = "Auto refresh " + state.countdown + "s"; state.countdownTimer = setInterval(() => { state.countdown -= 1; if(state.countdown <= 0) state.countdown = Math.floor((CONFIG.autoRefreshMs || 4000) / 1000); refreshLabel.textContent = "Auto refresh " + state.countdown + "s"; }, 1000); state.pollTimer = setInterval(() => loadMessages(), CONFIG.autoRefreshMs || 4000); }
function stopTimers(){ if(state.countdownTimer) clearInterval(state.countdownTimer); if(state.pollTimer) clearInterval(state.pollTimer); }
$("randomBtn").addEventListener("click", ()=>{ usernameInput.value = randomUsername(); });
$("createBtn").addEventListener("click", createInbox);
$("refreshBtn").addEventListener("click", ()=>loadMessages(true));
$("newBtn").addEventListener("click", ()=>{ usernameInput.value = randomUsername(); createInbox(); });
$("deleteBtn").addEventListener("click", deleteInbox);
$("copyBtn").addEventListener("click", async ()=>{ if(!state.currentEmail) return showToast("Belum ada email"); await navigator.clipboard.writeText(state.currentEmail); showToast("Email disalin"); });
$("closeModal").addEventListener("click", ()=>modal.classList.add("hidden"));
modal.addEventListener("click", (e)=>{ if(e.target === modal) modal.classList.add("hidden"); });
sortSelect.addEventListener("change", ()=>{ state.sort = sortSelect.value; renderMessages(); });
document.querySelectorAll(".tab-btn").forEach(btn => btn.addEventListener("click", ()=>switchTab(btn.dataset.tab)));
window.addEventListener("DOMContentLoaded", async ()=>{ domainValue.value = CONFIG.emailDomain; activeAppDomain.textContent = CONFIG.appDomain; activeEmailDomain.textContent = CONFIG.emailDomain; usernameInput.value = randomUsername(); if(state.currentEmail){ setEmail(state.currentEmail, ""); await loadMessages(); } startTimers(); });`;

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    let path = url.pathname;
    const method = request.method.toUpperCase();

    if (path.startsWith("/api/")) {
      path = path.replace(/^\/api/, "") || "/";
    }

    if (method === "GET" && (path === "/" || path === "/index.html")) return html(HTML);
    if (method === "GET" && path === "/style.css") return new Response(CSS, { headers: { "content-type": "text/css; charset=utf-8" } });
    if (method === "GET" && path === "/app.js") return new Response(JS, { headers: { "content-type": "application/javascript; charset=utf-8" } });
    if (method === "GET" && path === "/config.js") {
      const script = "window.__CONFIG__ = " + JSON.stringify({
        appDomain: env.APP_DOMAIN,
        emailDomain: env.PUBLIC_EMAIL_DOMAIN,
        autoRefreshMs: Number(env.AUTO_REFRESH_MS || 4000)
      }) + ";";
      return new Response(script, { headers: { "content-type": "application/javascript; charset=utf-8" } });
    }
    if (method === "GET" && path === "/health") return json({
      ok: true,
      service: "haluboy-tempmail",
      app_domain: env.APP_DOMAIN,
      email_domain: env.PUBLIC_EMAIL_DOMAIN
    });

    if (method === "POST" && path === "/inboxes") return createInbox(request, env);
    if (method === "GET" && path.startsWith("/inboxes/") && path.endsWith("/messages")) {
      const encoded = path.replace(/^\/inboxes\//, "").replace(/\/messages$/, "");
      return listMessages(decodeURIComponent(encoded), env);
    }
    if (method === "GET" && path.startsWith("/messages/")) return getMessage(decodeURIComponent(path.replace(/^\/messages\//, "")), env);
    if (method === "DELETE" && path.startsWith("/inboxes/")) return deleteInbox(decodeURIComponent(path.replace(/^\/inboxes\//, "")), env);

    return json({ ok: false, error: "Not found", path, method }, 404);
  },

  async email(message: ForwardableEmailMessage, env: Env): Promise<void> {
    const toEmail = String(message.to || "").trim().toLowerCase();
    const inbox = await env.DB.prepare("SELECT * FROM inboxes WHERE address = ? AND is_active = 1 LIMIT 1").bind(toEmail).first<InboxRow>();
    if (!inbox) { message.setReject("Inbox not found"); return; }

    const rawText = await new Response(message.raw).text();
    const subject = message.headers.get("subject") || "(No subject)";
    const fromEmail = String(message.from || "");
    const bodyText = rawText.slice(0, 12000);
    const bodyHtml = rawText.includes("<html") || rawText.includes("<body") ? rawText.slice(0, 12000) : "";
    const snippet = bodyText.replace(/\s+/g, " ").trim().slice(0, 180);

    await env.DB.prepare("INSERT INTO messages (id, inbox_id, from_email, subject, snippet, body_text, body_html, received_at, is_read) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)")
      .bind(crypto.randomUUID(), inbox.id, fromEmail, subject, snippet, bodyText, bodyHtml, new Date().toISOString())
      .run();
  }
};

async function createInbox(request: Request, env: Env): Promise<Response> {
  const body = await safeJson(request);
  const usernameInput = cleanLocalpart(String(body?.username || ""));
  const localpart = usernameInput || randomLocalpart();
  const domain = String(env.PUBLIC_EMAIL_DOMAIN || "").trim().toLowerCase();
  const address = \`\${localpart}@\${domain}\`;

  const exists = await env.DB.prepare("SELECT id FROM inboxes WHERE address = ? LIMIT 1").bind(address).first();
  if (exists) return json({ ok: false, error: "Email sudah dipakai, klik Random atau ganti username." }, 409);

  const now = new Date();
  const expiresAt = new Date(now.getTime() + Number(env.INBOX_TTL_HOURS || 24) * 60 * 60 * 1000).toISOString();
  const id = crypto.randomUUID();
  const ip = request.headers.get("CF-Connecting-IP") || "0.0.0.0";

  await env.DB.prepare("INSERT INTO inboxes (id, address, localpart, domain, created_at, expires_at, created_ip, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, 1)")
    .bind(id, address, localpart, domain, now.toISOString(), expiresAt, ip)
    .run();

  return json({ ok: true, inbox: { id, address, domain, created_at: now.toISOString(), expires_at: expiresAt } }, 201);
}

async function listMessages(address: string, env: Env): Promise<Response> {
  const inbox = await env.DB.prepare("SELECT * FROM inboxes WHERE address = ? AND is_active = 1 LIMIT 1").bind(String(address).toLowerCase()).first<InboxRow>();
  if (!inbox) return json({ ok: false, error: "Inbox tidak ditemukan" }, 404);

  const rows = await env.DB.prepare("SELECT id, from_email, subject, snippet, received_at, is_read FROM messages WHERE inbox_id = ? ORDER BY received_at DESC LIMIT 100")
    .bind(inbox.id).all<MessageRow>();

  return json({ ok: true, inbox: { address: inbox.address, expires_at: inbox.expires_at }, messages: rows.results || [] });
}

async function getMessage(id: string, env: Env): Promise<Response> {
  const row = await env.DB.prepare("SELECT id, from_email, subject, snippet, body_text, body_html, received_at, is_read FROM messages WHERE id = ? LIMIT 1")
    .bind(id).first<MessageRow>();
  if (!row) return json({ ok: false, error: "Message tidak ditemukan" }, 404);
  await env.DB.prepare("UPDATE messages SET is_read = 1 WHERE id = ?").bind(id).run();
  return json({ ok: true, message: row });
}

async function deleteInbox(address: string, env: Env): Promise<Response> {
  const inbox = await env.DB.prepare("SELECT * FROM inboxes WHERE address = ? LIMIT 1").bind(String(address).toLowerCase()).first<InboxRow>();
  if (!inbox) return json({ ok: false, error: "Inbox tidak ditemukan" }, 404);
  await env.DB.prepare("DELETE FROM messages WHERE inbox_id = ?").bind(inbox.id).run();
  await env.DB.prepare("DELETE FROM inboxes WHERE id = ?").bind(inbox.id).run();
  return json({ ok: true, deleted: inbox.address });
}

function cleanLocalpart(value: string): string {
  return String(value || "").trim().toLowerCase().replace(/[^a-z0-9._-]/g, "").replace(/^[._-]+|[._-]+$/g, "").slice(0, 24);
}
function randomLocalpart(): string {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789"; let out = "hb"; for (let i = 0; i < 10; i++) out += chars[Math.floor(Math.random() * chars.length)]; return out;
}
async function safeJson(request: Request): Promise<any> { try { return await request.json(); } catch { return {}; } }
function json(data: unknown, status = 200): Response { return new Response(JSON.stringify(data, null, 2), { status, headers: JSON_HEADERS }); }
function html(content: string): Response { return new Response(content, { headers: { "content-type": "text/html; charset=utf-8" } }); }