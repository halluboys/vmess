#!/usr/bin/env bash
set -euo pipefail
npm install
if grep -q "__DB_ID__" wrangler.jsonc; then
  echo "Isi database_id di wrangler.jsonc dulu."
  exit 1
fi
npx wrangler d1 execute tempmail-db --file=./schema.sql
npx wrangler deploy
