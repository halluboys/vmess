HALUBOY TEMPMAIL FIXED

Isi ZIP:
- src/index.ts
- wrangler.jsonc
- schema.sql
- package.json
- deploy.sh
- README.txt

Siap deploy untuk:
- Web UI di mail.haluboy.org
- Inbox email di username@haluboy.org

Catatan penting:
- Cloudflare Email Routing mendukung subdomain yang dikonfigurasi, tetapi catch-all rule saat ini hanya berlaku pada zone-level domain. Jadi setup paling stabil adalah:
  Web: mail.haluboy.org
  Email: username@haluboy.org

Cara deploy:
1. npm install
2. npx wrangler d1 create tempmail-db
3. Masukkan database_id ke wrangler.jsonc
4. npx wrangler d1 execute tempmail-db --file=./schema.sql
5. npx wrangler deploy

Dashboard:
1. Tambahkan custom domain/route untuk mail.haluboy.org ke Worker
2. Aktifkan Email Routing pada haluboy.org
3. Atur Catch-all -> Send to Worker -> worker ini
