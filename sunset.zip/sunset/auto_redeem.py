# Auto Redeem Script with Global auto_input Override

import builtins, time, sys, json
from dotenv import load_dotenv
from datetime import datetime

load_dotenv()

# === GLOBAL AUTO INPUT QUEUE ===
auto_inputs = []

def auto_input(prompt=""):
    global auto_inputs
    if auto_inputs:
        ans = auto_inputs.pop(0)
        print(f"{prompt}{ans}")
        return ans
    return original_input(prompt)

# Override all input() globally
original_input = builtins.input
builtins.input = auto_input

# === IMPORT YOUR ORIGINAL MODULES ===
from app.service.git import check_for_updates
from app.menus.util import clear_screen, pause
from app.client.engsel import get_balance, get_tiering_info
from app.client.famplan import validate_msisdn
from app.menus.payment import show_transaction_history
from app.service.auth import AuthInstance
from app.menus.bookmark import show_bookmark_menu
from app.menus.account import show_account_menu
from app.menus.package import fetch_my_packages
from app.menus.hot import show_hot_menu, show_hot_menu2
from app.service.sentry import enter_sentry_mode
from app.menus.purchase import purchase_by_family
from app.menus.famplan import show_family_info
from app.menus.circle import show_circle_info
from app.menus.notification import show_notification_menu
from app.menus.store.segments import show_store_segments_menu
from app.menus.store.search import show_family_list_menu, show_store_packages_menu
from app.menus.store.redemables import show_redeemables_menu
from app.client.registration import dukcapil

WIDTH = 55
auto_mode = False

def show_main_menu(profile):
    clear_screen()
    expired_at_dt = datetime.fromtimestamp(profile["balance_expired_at"]).strftime("%Y-%m-%d")
    print("=" * WIDTH)
    print((f"Nomor: {profile['number']} | Type: {profile['subscription_type']}").center(WIDTH))
    print((f"Pulsa: Rp {profile['balance']} | Aktif sampai: {expired_at_dt}").center(WIDTH))
    print((profile["point_info"]).center(WIDTH))
    print("=" * WIDTH)
    print("Menu:")
    print("1. Login/Ganti akun")
    print("2. Lihat Paket Saya")
    print("3. Redeemables")
    print("99. Tutup aplikasi")
    print("-------------------------------------------------------")

def auto_cycle():
    global auto_inputs
    print("\n[ AUTO ] Sequence berjalan...")
    auto_inputs = ["n", "A1", "3", "b", ""]
    show_redeemables_menu(False)
    print("[ AUTO ] Selesai. Menunggu 10 menit...")
    time.sleep(600)

def main():
    global auto_mode

    while True:
        active_user = AuthInstance.get_active_user()

        if active_user:
            balance = get_balance(AuthInstance.api_key, active_user["tokens"]["id_token"])
            balance_remaining = balance.get("remaining")
            balance_expired_at = balance.get("expired_at")

            point_info = "Points: N/A | Tier: N/A"

            if active_user["subscription_type"] == "PREPAID":
                tiering_data = get_tiering_info(AuthInstance.api_key, active_user["tokens"])
                tier = tiering_data.get("tier", 0)
                current_point = tiering_data.get("current_point", 0)
                point_info = f"Points: {current_point} | Tier: {tier}"

            profile = {
                "number": active_user["number"],
                "subscriber_id": active_user["subscriber_id"],
                "subscription_type": active_user["subscription_type"],
                "balance": balance_remaining,
                "balance_expired_at": balance_expired_at,
                "point_info": point_info
            }

            show_main_menu(profile)

            choice = input("Pilih menu: ")

            if choice == "3":
                # Eksekusi manual pertama
                first = input("Is enterprise? (y/n): ")
                show_redeemables_menu(first == "y")

                # Aktifkan mode otomatis
                if not auto_mode:
                    auto_mode = True
                    print("\n[ AUTO ] Mode otomatis aktif.")
                while auto_mode:
                    auto_cycle()

            elif choice == "1":
                selected_user_number = show_account_menu()
                if selected_user_number:
                    AuthInstance.set_active_user(selected_user_number)

            elif choice == "2":
                fetch_my_packages()

            elif choice == "99":
                print("Keluar aplikasi...")
                sys.exit(0)

        else:
            selected_user_number = show_account_menu()
            if selected_user_number:
                AuthInstance.set_active_user(selected_user_number)

if __name__ == "__main__":
    print("Checking for updates...")
    if check_for_updates():
        pause()
    main()
