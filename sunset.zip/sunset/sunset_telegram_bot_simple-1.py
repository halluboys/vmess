# -*- coding: utf-8 -*-
"""
SUNSET Telegram Bot (Simple)
Menu:
1) Login (input nomor; jika sudah ada di refresh-tokens.json -> set active)
   jika belum ada -> request OTP -> input OTP -> simpan refresh token -> set active
2) Cek Paket (tampilkan seluruh paket/quota)
3) eSIM 5GB (auto: family UUID + paket #1 + bayar Pulsa+Decoy V2)
4) eSIM 10GB (auto: family UUID + paket #1 + bayar Pulsa+Decoy V2)

Catatan:
- Bot ini mengikuti cara kerja project SUNSET (CLI) tapi UI Telegram.
- Untuk OTP menggunakan app.client.ciam.get_otp + submit_otp.

Run:
  cd sunset
  pip install -r requirements.txt
  pip install python-telegram-bot==20.7 python-dotenv
  export TELEGRAM_TOKEN="xxxx"
  python sunset_telegram_bot_simple.py
"""
import os
import json
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

load_dotenv()

from app.service.auth import AuthInstance
from app.client.engsel import (
    send_api_request,
    get_balance,
    get_tiering_info,
    get_family,
    get_package,
)
from app.client.ciam import get_otp, submit_otp
from app.menus.util import format_quota_byte, display_html
from app.type_dict import PaymentItem
from app.client.purchase.balance import settlement_balance
from app.service.decoy import DecoyInstance

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
if not TELEGRAM_TOKEN:
    raise RuntimeError("TELEGRAM_TOKEN env var belum di-set")

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger("sunset_telegram_simple")

# -------------------------
# Helpers UI
# -------------------------
def _back_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Kembali ke Menu", callback_data="m:home")]])

def _menu_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("1️⃣ Login", callback_data="m:login")],
        [InlineKeyboardButton("2️⃣ Cek Paket", callback_data="m:packages")],
        [InlineKeyboardButton("3️⃣ eSIM 5GB", callback_data="m:esim5")],
        [InlineKeyboardButton("4️⃣ eSIM 10GB", callback_data="m:esim10")],
    ])

async def _send_long(msg, text: str, *, parse_mode: Optional[str] = None, reply_markup=None):
    if not text:
        text = "✅ Selesai."
    while text:
        chunk = text[:3800]
        text = text[3800:]
        await msg.reply_text(chunk, parse_mode=parse_mode, reply_markup=reply_markup if not text else None)

def _money(v: Any) -> str:
    try:
        return f"{int(v):,}".replace(",", ".")
    except Exception:
        return str(v)

def _active_user() -> Optional[Dict[str, Any]]:
    return AuthInstance.get_active_user()

def _tokens() -> Optional[Dict[str, str]]:
    try:
        return AuthInstance.get_active_tokens()
    except Exception:
        u = _active_user()
        return u.get("tokens") if u else None

def _header() -> str:
    u = _active_user()
    if not u:
        return "🔐 *Belum login*\nSilakan login dulu."
    # Balance & tier are nice-to-have
    try:
        bal = get_balance(AuthInstance.api_key, u["tokens"]["id_token"])
        remaining = bal.get("remaining", "N/A")
        expired_at = bal.get("expired_at", 0)
        expired_at_dt = datetime.fromtimestamp(expired_at).strftime("%Y-%m-%d") if expired_at else "N/A"
    except Exception:
        remaining, expired_at_dt = "N/A", "N/A"
    point_info = "Points: N/A | Tier: N/A"
    try:
        if u.get("subscription_type") == "PREPAID":
            td = get_tiering_info(AuthInstance.api_key, u["tokens"])
            point_info = f"Points: {td.get('current_point',0)} | Tier: {td.get('tier',0)}"
    except Exception:
        pass

    return (
        "📱 *SUNSET XL BOT*\n"
        f"📞 *Nomor:* `{u.get('number')}` | *Type:* `{u.get('subscription_type')}`\n"
        f"💰 *Pulsa:* Rp {_money(remaining)} | *Aktif s/d:* `{expired_at_dt}`\n"
        f"⭐ *{point_info}*"
    )

def _require_login() -> Optional[str]:
    if not _active_user():
        return "❌ Kamu belum login. Pilih *1️⃣ Login* dulu."
    return None

def _is_number_registered(number: int) -> bool:
    try:
        AuthInstance.load_tokens()
    except Exception:
        pass
    for rt in getattr(AuthInstance, "refresh_tokens", []) or []:
        try:
            if int(rt.get("number")) == int(number):
                return True
        except Exception:
            continue
    # fallback read file directly
    try:
        if os.path.exists("refresh-tokens.json"):
            data = json.load(open("refresh-tokens.json","r",encoding="utf-8"))
            if isinstance(data, list):
                return any(int(x.get("number")) == int(number) for x in data if isinstance(x, dict) and x.get("number") is not None)
    except Exception:
        pass
    return False

async def _show_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, *, edit: bool = False):
    text = _header() + "\n\nPilih menu:"
    if update.callback_query and edit:
        await update.callback_query.message.edit_text(text, parse_mode="Markdown", reply_markup=_menu_kb())
    else:
        await update.effective_message.reply_text(text, parse_mode="Markdown", reply_markup=_menu_kb())

# -------------------------
# Business logic
# -------------------------
def _format_package_detail(pkg: Dict[str, Any]) -> str:
    po = pkg.get("package_option", {}) or {}
    pf = pkg.get("package_family", {}) or {}
    pv = pkg.get("package_detail_variant", {}) or {}
    name = po.get("name","")
    fam = pf.get("name","")
    var = pv.get("name","")
    price = po.get("price","N/A")
    validity = po.get("validity","N/A")
    tnc_txt = display_html(po.get("tnc","") or "")
    if isinstance(tnc_txt, str):
        tnc_txt = tnc_txt.strip()
    return (
        f"📦 *Detail Paket*\n"
        f"🏷 *Family:* {fam}\n"
        f"🧩 *Variant:* {var}\n"
        f"✨ *Nama:* {name}\n"
        f"💰 *Harga:* Rp {_money(price)}\n"
        f"📅 *Masa aktif:* {validity} hari\n\n"
        f"📝 *TnC (ringkas):*\n{(tnc_txt[:1200] + '…') if tnc_txt and len(tnc_txt)>1200 else (tnc_txt or '-')}"
    )

def _pick_option_code_from_family(fam: Dict[str, Any], target_no: int = 1) -> Optional[Dict[str, Any]]:
    n = 1
    for v in fam.get("package_variants", []):
        for opt in v.get("package_options", []):
            if n == target_no:
                return {
                    "option_code": opt.get("package_option_code"),
                    "name": opt.get("name",""),
                    "price": int(opt.get("price",0) or 0),
                }
            n += 1
    return None

def _pay_pulsa_decoy_v2(tokens: Dict[str, str], option_code: str, name: str, price: int, token_confirmation: str) -> Dict[str, Any]:
    """Return dict result; {'ok': bool, 'detail': any}"""
    items: List[PaymentItem] = [{
        "item_code": option_code,
        "product_type": "PACKAGE",
        "item_price": price,
        "item_name": name,
        "tax": 0,
        "token_confirmation": token_confirmation,
    }]

    decoy = DecoyInstance.get_decoy("balance")
    if not decoy:
        return {"ok": False, "detail": "Decoy config tidak ditemukan."}

    decoy_detail = get_package(AuthInstance.api_key, tokens, decoy["option_code"])
    if not decoy_detail:
        return {"ok": False, "detail": "Gagal load detail paket decoy."}

    decoy_price = int((decoy_detail.get("package_option") or {}).get("price", 0) or 0)
    decoy_name = (decoy_detail.get("package_option") or {}).get("name", "Decoy")
    decoy_code = (decoy_detail.get("package_option") or {}).get("package_option_code", decoy.get("option_code"))

    items2: List[PaymentItem] = list(items)
    items2.append({
        "item_code": decoy_code,
        "product_type": "",
        "item_price": decoy_price,
        "item_name": decoy_name,
        "tax": 0,
        "token_confirmation": decoy_detail.get("token_confirmation", ""),
    })

    overwrite_amount = price + decoy_price

    res = settlement_balance(
        AuthInstance.api_key,
        tokens,
        items2,
        "🤫",
        ask_overwrite=False,
        overwrite_amount=overwrite_amount,
        token_confirmation_idx=1
    )

    # settlement_balance returns dict on error, otherwise None
    if isinstance(res, dict) and res.get("status") != "SUCCESS":
        msg = res.get("message", "") or ""
        # auto-adjust like CLI
        if "Bizz-err.Amount.Total" in msg:
            try:
                valid_amount = int(msg.split("=")[1].strip())
                res2 = settlement_balance(
                    AuthInstance.api_key,
                    tokens,
                    items2,
                    "🤫",
                    ask_overwrite=False,
                    overwrite_amount=valid_amount,
                    token_confirmation_idx=-1
                )
                if not (isinstance(res2, dict) and res2.get("status") != "SUCCESS"):
                    return {"ok": True, "detail": "Adjusted OK"}
                return {"ok": False, "detail": res2}
            except Exception:
                return {"ok": False, "detail": res}
        return {"ok": False, "detail": res}

    return {"ok": True, "detail": "OK"}

# -------------------------
# Handlers
# -------------------------
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await _show_menu(update, context, edit=False)

async def on_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    data = q.data

    if data == "m:home":
        await _show_menu(update, context, edit=True)
        return

    # 1) Login
    if data == "m:login":
        # Clean UI: show only instruction + back button (no main menu)
        context.user_data["state"] = "wait_msisdn"
        await q.message.edit_text(
            "📲 *Login*\n\nKirim nomor format `628xxxx`.\n\nKetik `batal` untuk membatalkan.",
            parse_mode="Markdown",
            reply_markup=_back_kb()
        )
        return

    # 2) Cek paket
    if data == "m:packages":
        need = _require_login()
        if need:
            await q.message.edit_text(need, parse_mode="Markdown", reply_markup=_back_kb())
            return
        await q.message.edit_text("🔄 Mengambil seluruh paket/quota...", reply_markup=_back_kb())

        try:
            tokens = _tokens()
            path = "api/v8/packages/quota-details"
            payload = {"is_enterprise": False, "lang": "en", "family_member_id": ""}
            res = send_api_request(AuthInstance.api_key, path, payload, tokens["id_token"], "POST")
            if res.get("status") != "SUCCESS":
                await _send_long(q.message, f"❌ Gagal ambil paket.\n```json\n{json.dumps(res, indent=2)[:3000]}\n```", parse_mode="Markdown", reply_markup=_back_kb())
                return

            quotas = res.get("data", {}).get("quotas", []) or []
            lines = [_header(), "", "📦 *My Packages (Full)*"]
            if not quotas:
                lines.append("📭 Tidak ada data quota.")
                await _send_long(q.message, "\n".join(lines), parse_mode="Markdown", reply_markup=_back_kb())
                return

            for i, qt in enumerate(quotas, start=1):
                group = qt.get("group_name","")
                name = qt.get("name","")
                benefits = qt.get("benefits") or []
                if benefits:
                    b0 = benefits[0]
                    rem = b0.get("remaining")
                    tot = b0.get("total")
                    rems = format_quota_byte(rem) if isinstance(rem,(int,float)) else str(rem)
                    tots = format_quota_byte(tot) if isinstance(tot,(int,float)) else str(tot)
                    lines.append(f"{i}. *{group}* - {name} — {rems}/{tots}")
                else:
                    lines.append(f"{i}. *{group}* - {name}")
            await _send_long(q.message, "\n".join(lines), parse_mode="Markdown", reply_markup=_back_kb())
        except Exception as e:
            await q.message.reply_text(f"❌ Error: {type(e).__name__}: {e}", reply_markup=_back_kb())
        return

    # 3) eSIM 5GB
    if data == "m:esim5":
        need = _require_login()
        if need:
            await q.message.edit_text(need, parse_mode="Markdown", reply_markup=_back_kb()); return

        FAMILY = "0d9d072c-3dab-4f72-88cd-31c5b8dc8c6b"
        await q.message.edit_text("⚡ Dor eSIM 5GB: memproses...", reply_markup=_back_kb())

        try:
            tokens = _tokens()
            fam = get_family(AuthInstance.api_key, tokens, FAMILY, None, None)
            picked = _pick_option_code_from_family(fam, 1)
            if not picked or not picked.get("option_code"):
                await q.message.reply_text("❌ Paket #1 tidak ditemukan.", reply_markup=_back_kb()); return

            pkg = get_package(AuthInstance.api_key, tokens, picked["option_code"])
            token_confirmation = pkg.get("token_confirmation","")
            if not token_confirmation:
                await q.message.reply_text("❌ token_confirmation tidak ditemukan.", reply_markup=_back_kb()); return

            pay = _pay_pulsa_decoy_v2(tokens, picked["option_code"], picked["name"] or (pkg.get("package_option") or {}).get("name",""), picked["price"], token_confirmation)
            if pay["ok"]:
                await q.message.reply_text("✅ *SUKSES* dor eSIM 5GB (Decoy V2).", parse_mode="Markdown", reply_markup=_back_kb())
            else:
                await _send_long(q.message, f"❌ Gagal dor eSIM 5GB.\n```json\n{json.dumps(pay['detail'], indent=2)[:3000] if isinstance(pay['detail'], dict) else str(pay['detail'])}\n```", parse_mode="Markdown", reply_markup=_back_kb())
        except Exception as e:
            await q.message.reply_text(f"❌ Error: {type(e).__name__}: {e}", reply_markup=_back_kb())
        return

    # 4) eSIM 10GB
    if data == "m:esim10":
        need = _require_login()
        if need:
            await q.message.edit_text(need, parse_mode="Markdown", reply_markup=_back_kb()); return

        FAMILY = "162d261b-05c7-450c-9b7a-1873b160140c"
        await q.message.edit_text("⚡ Dor eSIM 10GB: memproses...", reply_markup=_back_kb())

        try:
            tokens = _tokens()
            fam = get_family(AuthInstance.api_key, tokens, FAMILY, None, None)
            picked = _pick_option_code_from_family(fam, 1)
            if not picked or not picked.get("option_code"):
                await q.message.reply_text("❌ Paket #1 tidak ditemukan.", reply_markup=_back_kb()); return

            pkg = get_package(AuthInstance.api_key, tokens, picked["option_code"])
            token_confirmation = pkg.get("token_confirmation","")
            if not token_confirmation:
                await q.message.reply_text("❌ token_confirmation tidak ditemukan.", reply_markup=_back_kb()); return

            pay = _pay_pulsa_decoy_v2(tokens, picked["option_code"], picked["name"] or (pkg.get("package_option") or {}).get("name",""), picked["price"], token_confirmation)
            if pay["ok"]:
                await q.message.reply_text("✅ *SUKSES* dor eSIM 10GB (Decoy V2).", parse_mode="Markdown", reply_markup=_back_kb())
            else:
                await _send_long(q.message, f"❌ Gagal dor eSIM 10GB.\n```json\n{json.dumps(pay['detail'], indent=2)[:3000] if isinstance(pay['detail'], dict) else str(pay['detail'])}\n```", parse_mode="Markdown", reply_markup=_back_kb())
        except Exception as e:
            await q.message.reply_text(f"❌ Error: {type(e).__name__}: {e}", reply_markup=_back_kb())
        return

    # fallback
    await q.message.edit_text("❌ Menu tidak dikenali.", reply_markup=_back_kb())

async def on_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (update.message.text or "").strip()
    state = context.user_data.get("state")

    if not state:
        return

    if text.lower() in ("batal", "cancel", "99"):
        context.user_data.pop("state", None)
        await update.message.reply_text("✅ Dibatalkan.", reply_markup=_back_kb())
        return

    # login flow
    if state == "wait_msisdn":
        # validate
        if not text.startswith("628") or not text.isdigit() or len(text) > 14:
            await update.message.reply_text("❌ Format nomor salah. Harus `628xxxx`.", reply_markup=_back_kb())
            return

        number = int(text)
        context.user_data["login_number"] = number

        # if registered -> set active and back menu
        if _is_number_registered(number):
            try:
                AuthInstance.set_active_user(number)
                context.user_data.pop("state", None)
                await update.message.reply_text("✅ Nomor sudah terdaftar. Akun diaktifkan.", reply_markup=_back_kb())
                return
            except Exception as e:
                context.user_data.pop("state", None)
                await update.message.reply_text(f"❌ Gagal set aktif: {e}", reply_markup=_back_kb())
                return

        # not registered -> request OTP
        await update.message.reply_text("📨 Meminta OTP...", reply_markup=_back_kb())
        try:
            subscriber_id = get_otp(str(number))
            if not subscriber_id:
                context.user_data.pop("state", None)
                await update.message.reply_text("❌ Gagal meminta OTP. Coba lagi.", reply_markup=_back_kb())
                return
            context.user_data["otp_subscriber_id"] = subscriber_id
            context.user_data["state"] = "wait_otp"
            await update.message.reply_text("✅ OTP terkirim. Sekarang kirim kode OTP 6 digit:", reply_markup=_back_kb())
        except Exception as e:
            context.user_data.pop("state", None)
            await update.message.reply_text(f"❌ Error request OTP: {type(e).__name__}: {e}", reply_markup=_back_kb())
        return

    if state == "wait_otp":
        otp = text
        if not otp.isdigit() or len(otp) != 6:
            await update.message.reply_text("❌ OTP harus 6 digit angka.", reply_markup=_back_kb())
            return

        number = context.user_data.get("login_number")
        if not number:
            context.user_data.pop("state", None)
            await update.message.reply_text("❌ State login hilang. Ulangi login.", reply_markup=_back_kb())
            return

        await update.message.reply_text("🔄 Verifikasi OTP...", reply_markup=_back_kb())
        try:
            result = submit_otp(AuthInstance.api_key, "SMS", str(number), otp)
            if not result or "refresh_token" not in result:
                await update.message.reply_text("❌ OTP salah / login gagal.", reply_markup=_back_kb())
                return

            # save & activate
            AuthInstance.add_refresh_token(int(number), result["refresh_token"])
            context.user_data.pop("state", None)
            await update.message.reply_text("✅ Login sukses. Akun tersimpan & aktif.", reply_markup=_back_kb())
        except Exception as e:
            context.user_data.pop("state", None)
            await update.message.reply_text(f"❌ Error submit OTP: {type(e).__name__}: {e}", reply_markup=_back_kb())
        return

def build_app() -> Application:
    app = Application.builder().token(TELEGRAM_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("menu", start))

    app.add_handler(CallbackQueryHandler(on_click, pattern=r"^m:"))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))

    return app

def main():
    logger.info("Starting SUNSET Telegram Bot (Simple)")
    build_app().run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
