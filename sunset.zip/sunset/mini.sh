#!/bin/bash

# Folder tujuan
DST="./minimal_app"

echo "Membuat folder minimal_app..."
mkdir -p $DST
mkdir -p $DST/app/service
mkdir -p $DST/app/menus
mkdir -p $DST/app/client/purchase
mkdir -p $DST/app/client
mkdir -p $DST/app

# Copy main.py dan .env jika ada
echo "Menyalin main.py"
cp main.py $DST/

if [ -f ".env" ]; then
    echo "Menyalin .env"
    cp .env $DST/
fi

# ================================
# SERVICE
# ================================
echo "Menyalin service files..."
cp app/service/git.py $DST/app/service/
cp app/service/auth.py $DST/app/service/

# ================================
# MENUS
# ================================
echo "Menyalin menus files..."
cp app/menus/util.py $DST/app/menus/
cp app/menus/account.py $DST/app/menus/
cp app/menus/package.py $DST/app/menus/
cp app/menus/purchase.py $DST/app/menus/

# ================================
# CLIENT
# ================================
echo "Menyalin client files..."
cp app/client/engsel.py $DST/app/client/
cp app/client/famplan.py $DST/app/client/
cp app/client/registration.py $DST/app/client/

# ================================
# CLIENT PURCHASE
# ================================
echo "Menyalin client purchase modules..."
cp app/client/purchase/balance.py $DST/app/client/purchase/
cp app/client/purchase/ewallet.py $DST/app/client/purchase/
cp app/client/purchase/qris.py $DST/app/client/purchase/

# ================================
# TYPE DICT
# ================================
echo "Menyalin type_dict..."
cp app/type_dict.py $DST/app/type_dict.py

echo ""
echo "==============================="
echo "  COPY SELESAI TANPA ERROR!"
echo "  Folder siap: minimal_app/"
echo "==============================="