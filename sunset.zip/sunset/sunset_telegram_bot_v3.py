# -*- coding: utf-8 -*-
"""
SUNSET (main.py) -> Telegram Bot
- Mengikuti alur menu 1–14 di main.py, tapi UI Telegram (InlineKeyboard).
- TIDAK memanggil menu CLI yang pakai input(); semua data ditarik lewat client/API functions lalu ditampilkan di Telegram.

Run:
  cd sunset
  pip install -r requirements.txt
  pip install python-telegram-bot==20.7
  export TELEGRAM_TOKEN="xxxx"
  python sunset_telegram_bot.py
"""
import os
import json
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

load_dotenv()

# --- Imports dari project kamu (sunset) ---
from app.service.auth import AuthInstance
from app.client.engsel import (
    send_api_request,
    get_balance,
    get_tiering_info,
    get_family,
    get_package,
)
from app.client.famplan import validate_msisdn
from app.menus.util import format_quota_byte, display_html
from app.type_dict import PaymentItem
from app.client.purchase.balance import settlement_balance
from app.client.purchase.qris import settlement_qris
from app.service.decoy import DecoyInstance  # display_html strips html in your repo

WIDTH = 55

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
if not TELEGRAM_TOKEN:
    raise RuntimeError("TELEGRAM_TOKEN env var belum di-set")

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger("sunset_telegram")

# -------------------------
# Helpers
# -------------------------
def money(v: Any) -> str:
    try:
        return f"{int(v):,}".replace(",", ".")
    except Exception:
        return str(v)

def _get_active_user() -> Optional[Dict[str, Any]]:
    return AuthInstance.get_active_user()

def _get_tokens() -> Optional[Dict[str, str]]:
    try:
        return AuthInstance.get_active_tokens()
    except Exception:
        # fallback
        u = _get_active_user()
        return u.get("tokens") if u else None

def _header() -> str:
    u = _get_active_user()
    if not u:
        return "🔐 *Belum login*"
    try:
        balance = get_balance(AuthInstance.api_key, u["tokens"]["id_token"])
        remaining = balance.get("remaining", "N/A")
        expired_at = balance.get("expired_at", 0)
        expired_at_dt = datetime.fromtimestamp(expired_at).strftime("%Y-%m-%d") if expired_at else "N/A"
    except Exception:
        remaining, expired_at_dt = "N/A", "N/A"

    point_info = "Points: N/A | Tier: N/A"
    try:
        if u.get("subscription_type") == "PREPAID":
            td = get_tiering_info(AuthInstance.api_key, u["tokens"])
            point_info = f"Points: {td.get('current_point',0)} | Tier: {td.get('tier',0)}"
    except Exception:
        pass

    return (
        "📱 *SUNSET XL BOT*\n"
        f"📞 *Nomor:* `{u.get('number')}` | *Type:* `{u.get('subscription_type')}`\n"
        f"💰 *Pulsa:* Rp {money(remaining)} | *Aktif s/d:* `{expired_at_dt}`\n"
        f"⭐ *{point_info}*"
    )



def pay_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("1️⃣ Pulsa", callback_data="pay:pulsa"),
         InlineKeyboardButton("3️⃣ QRIS", callback_data="pay:qris")],
        [InlineKeyboardButton("5️⃣ Pulsa + Decoy V2", callback_data="pay:decoyv2")],
        [InlineKeyboardButton("🔙 Kembali", callback_data="m:home")]
    ])

def main_kb() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton("1. Login/Ganti akun", callback_data="m:1"),
         InlineKeyboardButton("2. Lihat Paket Saya", callback_data="m:2")],
        [InlineKeyboardButton("3. HOT", callback_data="m:3"),
         InlineKeyboardButton("4. HOT-2", callback_data="m:4")],
        [InlineKeyboardButton("5. Option Code", callback_data="m:5"),
         InlineKeyboardButton("6. Family Code", callback_data="m:6")],
        [InlineKeyboardButton("7. Loop Family (CLI)", callback_data="m:7"),
         InlineKeyboardButton("8. Riwayat (CLI)", callback_data="m:8")],
        [InlineKeyboardButton("9. Family Plan (CLI)", callback_data="m:9"),
         InlineKeyboardButton("10. Circle (CLI)", callback_data="m:10")],
        [InlineKeyboardButton("11. Store Segments (CLI)", callback_data="m:11"),
         InlineKeyboardButton("12. Store Family List (CLI)", callback_data="m:12")],
        [InlineKeyboardButton("13. Store Packages (CLI)", callback_data="m:13"),
         InlineKeyboardButton("14. Redemables (CLI)", callback_data="m:14")],
        [InlineKeyboardButton("N. Notifikasi (CLI)", callback_data="m:n"),
         InlineKeyboardButton("V. Validate msisdn", callback_data="m:v")],
        [InlineKeyboardButton("🏠 Menu", callback_data="m:home")],
    ]
    return InlineKeyboardMarkup(rows)

async def show_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, edit: bool = False):
    text = _header() + "\n\nPilih menu:"
    if update.callback_query and edit:
        await update.callback_query.message.edit_text(text, parse_mode="Markdown", reply_markup=main_kb())
    else:
        await update.effective_message.reply_text(text, parse_mode="Markdown", reply_markup=main_kb())

def require_login() -> Optional[str]:
    if not _get_active_user():
        return "❌ Kamu belum login. Pilih *1. Login/Ganti akun* dulu."
    return None

def load_accounts() -> List[int]:
    nums: List[int] = []
    try:
        AuthInstance.load_tokens()
        for rt in getattr(AuthInstance, "refresh_tokens", []) or []:
            if "number" in rt:
                nums.append(int(rt["number"]))
    except Exception:
        pass
    # fallback refresh-tokens.json
    try:
        if os.path.exists("refresh-tokens.json"):
            data = json.load(open("refresh-tokens.json","r",encoding="utf-8"))
            if isinstance(data, list):
                for rt in data:
                    n = rt.get("number")
                    if n is not None:
                        nums.append(int(n))
    except Exception:
        pass
    # uniq keep order
    seen=set()
    out=[]
    for n in nums:
        if n not in seen:
            seen.add(n)
            out.append(n)
    return out

async def send_long(msg, text: str, *, parse_mode: Optional[str] = None, reply_markup=None):
    if not text:
        text = "✅ Selesai."
    while text:
        chunk = text[:3800]
        text = text[3800:]
        await msg.reply_text(chunk, parse_mode=parse_mode, reply_markup=reply_markup if not text else None)

# -------------------------
# Menu implementations
# -------------------------
async def menu_login(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    accounts = load_accounts()
    if not accounts:
        await q.message.edit_text(
            "ℹ️ Tidak ada akun tersimpan di `refresh-tokens.json`.\n"
            "Di project sunset, akun disimpan sebagai refresh token.\n"
            "Silakan tambahkan refresh token dulu (via tool/CLI yang kamu pakai).",
            reply_markup=main_kb()
        )
        return
    kb = [[InlineKeyboardButton(f"✅ Aktifkan {n}", callback_data=f"acc:{n}")] for n in accounts[:30]]
    kb.append([InlineKeyboardButton("🔙 Kembali", callback_data="m:home")])
    await q.message.edit_text("Pilih akun:", reply_markup=InlineKeyboardMarkup(kb))

async def menu_my_packages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    need = require_login()
    if need:
        await q.message.edit_text(need, parse_mode="Markdown", reply_markup=main_kb())
        return

    u = _get_active_user()
    tokens = _get_tokens()
    await q.message.edit_text("🔄 Mengambil paket kamu...")

    try:
        path = "api/v8/packages/quota-details"
        payload = {"is_enterprise": False, "lang": "en", "family_member_id": ""}
        res = send_api_request(AuthInstance.api_key, path, payload, tokens["id_token"], "POST")
        if res.get("status") != "SUCCESS":
            await send_long(q.message, f"❌ Gagal ambil paket.\n```json\n{json.dumps(res, indent=2)[:3000]}\n```", parse_mode="Markdown")
            return

        quotas = res.get("data", {}).get("quotas", [])
        lines = [f"{_header()}", "", "📦 *My Packages*"]
        if not quotas:
            lines.append("📭 Tidak ada data quota.")
            await send_long(q.message, "\n".join(lines), parse_mode="Markdown", reply_markup=main_kb())
            return

        # ringkas 25 item
        for i, qt in enumerate(quotas[:25], start=1):
            group = qt.get("group_name","")
            name = qt.get("name","")
            # ambil benefit pertama untuk ringkas remaining
            rem = tot = None
            benefits = qt.get("benefits") or []
            if benefits:
                b0 = benefits[0]
                rem = b0.get("remaining")
                tot = b0.get("total")
            if rem is not None and tot is not None:
                rems = format_quota_byte(rem) if isinstance(rem,(int,float)) else str(rem)
                tots = format_quota_byte(tot) if isinstance(tot,(int,float)) else str(tot)
                lines.append(f"{i}. *{group}* - {name} — {rems}/{tots}")
            else:
                lines.append(f"{i}. *{group}* - {name}")

        if len(quotas) > 25:
            lines.append(f"... dan {len(quotas)-25} item lainnya.")
        await send_long(q.message, "\n".join(lines), parse_mode="Markdown", reply_markup=main_kb())
    except Exception as e:
        await send_long(q.message, f"❌ Error: {type(e).__name__}: {e}", reply_markup=main_kb())

def _format_package_detail(pkg: Dict[str, Any]) -> str:
    po = pkg.get("package_option", {}) or {}
    pf = pkg.get("package_family", {}) or {}
    pv = pkg.get("package_detail_variant", {}) or {}
    name = po.get("name","")
    fam = pf.get("name","")
    var = pv.get("name","")
    price = po.get("price","N/A")
    validity = po.get("validity","N/A")
    tnc = po.get("tnc","")
    tnc_txt = display_html(tnc)
    if isinstance(tnc_txt, str):
        tnc_txt = tnc_txt.strip()
    # benefits may be in package_details elsewhere; keep short
    return (
        f"📦 *Detail Paket*\n"
        f"🏷 *Family:* {fam}\n"
        f"🧩 *Variant:* {var}\n"
        f"✨ *Nama:* {name}\n"
        f"💰 *Harga:* Rp {money(price)}\n"
        f"📅 *Masa aktif:* {validity} hari\n\n"
        f"📝 *TnC (ringkas):*\n{(tnc_txt[:1200] + '…') if tnc_txt and len(tnc_txt)>1200 else (tnc_txt or '-')}"
    )

async def menu_option_code(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    need = require_login()
    if need:
        await q.message.edit_text(need, parse_mode="Markdown", reply_markup=main_kb())
        return
    context.user_data["state"] = "wait_option_code"
    await q.message.edit_text("Kirim *option code* (atau `batal`).", parse_mode="Markdown")

async def menu_family_code(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    need = require_login()
    if need:
        await q.message.edit_text(need, parse_mode="Markdown", reply_markup=main_kb())
        return
    context.user_data["state"] = "wait_family_code"
    await q.message.edit_text("Kirim *family code* UUID (atau `batal`).", parse_mode="Markdown")

async def menu_hot(update: Update, context: ContextTypes.DEFAULT_TYPE, which: str):
    q = update.callback_query
    await q.answer()
    need = require_login()
    if need:
        await q.message.edit_text(need, parse_mode="Markdown", reply_markup=main_kb())
        return

    file_path = "hot_data/hot.json" if which == "hot1" else "hot_data/hot2.json"
    await q.message.edit_text("🔄 Memuat HOT list...")
    try:
        items = json.load(open(file_path, "r", encoding="utf-8"))
    except Exception as e:
        await q.message.edit_text(f"❌ Gagal baca {file_path}: {e}", reply_markup=main_kb())
        return

    context.user_data["hot_items"] = items
    context.user_data["state"] = f"wait_hot_pick:{which}"

    lines = [f"{_header()}", "", f"🔥 *{which.upper()}* (pilih nomor)"]
    for i, it in enumerate(items[:40], start=1):
        lines.append(f"{i}. {it.get('family_name','')} - {it.get('variant_name','')} - {it.get('option_name','')}")
    if len(items) > 40:
        lines.append(f"... dan {len(items)-40} item lainnya.")
    lines.append("")
    lines.append("Ketik nomor paket, contoh: `1` (atau `batal`).")
    await send_long(q.message, "\n".join(lines), parse_mode="Markdown")

# -------------------------
# Callbacks
# -------------------------
async def on_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_menu(update, context, edit=False)

async def on_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_menu(update, context, edit=False)

async def on_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    data = q.data

    if data == "m:home":
        await show_menu(update, context, edit=True); return
    if data == "m:1":
        await menu_login(update, context); return
    if data == "m:2":
        await menu_my_packages(update, context); return
    if data == "m:3":
        await menu_hot(update, context, "hot1"); return
    if data == "m:4":
        await menu_hot(update, context, "hot2"); return
    if data == "m:5":
        await menu_option_code(update, context); return
    if data == "m:6":
        await menu_family_code(update, context); return

    # Menus 7-14 & N — masih CLI di project (banyak input/loop). Kita kasih pesan jelas.
    if data in ("m:7","m:8","m:9","m:10","m:11","m:12","m:13","m:14","m:n"):
        await q.message.edit_text(
            "⚠️ Menu ini di `sunset/main.py` masih CLI interaktif (banyak `input()` dan loop).\n"
            "Agar 100% jalan di Telegram, perlu di-convert step-by-step seperti menu 5 & 6.\n\n"
            "Ketik `/menu` untuk balik.",
        )
        return

    if data == "m:v":
        need = require_login()
        if need:
            await q.message.edit_text(need, parse_mode="Markdown", reply_markup=main_kb()); return
        context.user_data["state"] = "wait_validate"
        await q.message.edit_text("Kirim msisdn `628xxxx` (atau `batal`).", parse_mode="Markdown")
        return

async def on_acc(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    num = int(q.data.split(":",1)[1])
    try:
        AuthInstance.set_active_user(num)
        await q.message.edit_text(f"✅ Aktif: `{num}`", parse_mode="Markdown")
    except Exception as e:
        await q.message.edit_text(f"❌ Gagal aktifkan akun: {e}")
    await show_menu(update, context, edit=False)

# -------------------------
# Text handler (state machine)
# -------------------------
async def on_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (update.message.text or "").strip()
    state = context.user_data.get("state")

    if not state:
        return

    if text.lower() in ("batal","cancel","99"):
        context.user_data.pop("state", None)
        context.user_data.pop("family_pkgs", None)
        context.user_data.pop("hot_items", None)
        await update.message.reply_text("✅ Dibatalkan.", reply_markup=main_kb())
        return

    need = require_login()
    if need:
        context.user_data.pop("state", None)
        await update.message.reply_text(need, parse_mode="Markdown", reply_markup=main_kb())
        return

    tokens = _get_tokens()

    # option code -> detail
    if state == "wait_option_code":
        context.user_data.pop("state", None)
        option_code = text
        await update.message.reply_text("🔄 Mengambil detail paket...")
        try:
            pkg = get_package(AuthInstance.api_key, tokens, option_code)
            if not pkg:
                await update.message.reply_text("❌ Paket tidak ditemukan.", reply_markup=main_kb()); return
            context.user_data["last_pkg"] = {
                "option_code": option_code,
                "name": (pkg.get("package_option") or {}).get("name",""),
                "price": (pkg.get("package_option") or {}).get("price",0),
                "token_confirmation": pkg.get("token_confirmation",""),
                "payment_for": (pkg.get("package_family") or {}).get("payment_for","BUY_PACKAGE"),
            }
            await send_long(update.message, _format_package_detail(pkg), parse_mode="Markdown")
            await update.message.reply_text("Pilih metode pembayaran:", reply_markup=pay_kb())
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {e}", reply_markup=main_kb())
        return

    # family code -> list packages, then wait pick
    if state == "wait_family_code":
        family_code = text
        await update.message.reply_text("🔄 Mengambil daftar paket family...")
        try:
            data = get_family(AuthInstance.api_key, tokens, family_code, None, None)
            if not data:
                context.user_data.pop("state", None)
                await update.message.reply_text("❌ Gagal load family.", reply_markup=main_kb()); return
            pkgs=[]
            n=1
            for v in data.get("package_variants", []):
                for opt in v.get("package_options", []):
                    pkgs.append({"n": n, "name": opt.get("name",""), "price": opt.get("price",""), "code": opt.get("package_option_code","")})
                    n+=1
            if not pkgs:
                context.user_data.pop("state", None)
                await update.message.reply_text("📭 Tidak ada paket di family ini.", reply_markup=main_kb()); return

            context.user_data["family_pkgs"] = pkgs
            context.user_data["state"] = "wait_family_pick"

            lines=[f"✅ Ditemukan {len(pkgs)} paket.", f"Family: `{family_code}`", ""]
            for p in pkgs[:40]:
                lines.append(f"{p['n']}. {p['name']} - Rp {money(p['price'])}")
            if len(pkgs)>40:
                lines.append(f"... dan {len(pkgs)-40} paket lainnya.")
            lines.append("")
            lines.append("Ketik nomor paket (contoh `1`) atau `batal`.")
            await send_long(update.message, "\n".join(lines), parse_mode="Markdown")
        except Exception as e:
            context.user_data.pop("state", None)
            await update.message.reply_text(f"❌ Error: {e}", reply_markup=main_kb())
        return

    if state == "wait_family_pick":
        pkgs = context.user_data.get("family_pkgs") or []
        try:
            pick = int(text)
        except ValueError:
            await update.message.reply_text("❌ Harus angka. Coba lagi atau `batal`."); return
        sel = next((p for p in pkgs if p["n"]==pick), None)
        if not sel:
            await update.message.reply_text("❌ Nomor tidak ditemukan. Coba lagi."); return
        context.user_data.pop("state", None)
        context.user_data.pop("family_pkgs", None)

        await update.message.reply_text("🔄 Mengambil detail paket...")
        try:
            pkg = get_package(AuthInstance.api_key, tokens, sel["code"])
            context.user_data["last_pkg"] = {
                "option_code": sel["code"],
                "name": (pkg.get("package_option") or {}).get("name",""),
                "price": (pkg.get("package_option") or {}).get("price",0),
                "token_confirmation": pkg.get("token_confirmation",""),
                "payment_for": (pkg.get("package_family") or {}).get("payment_for","BUY_PACKAGE"),
            }
            await send_long(update.message, _format_package_detail(pkg), parse_mode="Markdown")
            await update.message.reply_text("Pilih metode pembayaran:", reply_markup=pay_kb())
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {e}", reply_markup=main_kb())
        return

    # HOT pick
    if state.startswith("wait_hot_pick:"):
        which = state.split(":",1)[1]
        items = context.user_data.get("hot_items") or []
        try:
            idx = int(text)
        except ValueError:
            await update.message.reply_text("❌ Harus angka. Coba lagi atau `batal`."); return
        if idx < 1 or idx > len(items):
            await update.message.reply_text("❌ Nomor tidak valid. Coba lagi."); return

        item = items[idx-1]
        context.user_data.pop("state", None)
        context.user_data.pop("hot_items", None)

        family_code = item.get("family_code")
        order = item.get("order")
        is_enterprise = bool(item.get("is_enterprise", False))

        await update.message.reply_text("🔄 Mengambil detail HOT package...")
        try:
            fam = get_family(AuthInstance.api_key, tokens, family_code, is_enterprise)
            target_code = None
            for v in fam.get("package_variants", []):
                for opt in v.get("package_options", []):
                    if opt.get("order") == order:
                        target_code = opt.get("package_option_code")
                        break
                if target_code:
                    break
            if not target_code:
                await update.message.reply_text("❌ Option code HOT tidak ditemukan.", reply_markup=main_kb()); return
            pkg = get_package(AuthInstance.api_key, tokens, target_code)
            context.user_data["last_pkg"] = {
                "option_code": target_code,
                "name": (pkg.get("package_option") or {}).get("name",""),
                "price": (pkg.get("package_option") or {}).get("price",0),
                "token_confirmation": pkg.get("token_confirmation",""),
                "payment_for": (pkg.get("package_family") or {}).get("payment_for","BUY_PACKAGE"),
            }
            await send_long(update.message, _format_package_detail(pkg), parse_mode="Markdown")
            await update.message.reply_text("Pilih metode pembayaran:", reply_markup=pay_kb())
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {e}", reply_markup=main_kb())
        return

    if state == "wait_validate":
        context.user_data.pop("state", None)
        msisdn = text
        await update.message.reply_text("🔄 Validating...")
        try:
            u = _get_active_user()
            res = validate_msisdn(AuthInstance.api_key, u["tokens"], msisdn)
            out = json.dumps(res, indent=2)[:3500]
            await update.message.reply_text(f"```json\n{out}\n```", parse_mode="Markdown", reply_markup=main_kb())
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {e}", reply_markup=main_kb())



async def on_pay(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    method = q.data.split(":", 1)[1]

    need = require_login()
    if need:
        await q.message.edit_text(need, parse_mode="Markdown", reply_markup=main_kb())
        return

    last = context.user_data.get("last_pkg")
    if not last:
        await q.message.edit_text("❌ Tidak ada paket yang dipilih. Pilih paket dulu dari menu 5/6/HOT.", reply_markup=main_kb())
        return

    tokens = _get_tokens()
    option_code = last["option_code"]
    name = last.get("name","")
    price = int(last.get("price",0) or 0)
    token_confirmation = last.get("token_confirmation","")
    payment_for = last.get("payment_for","BUY_PACKAGE") or "BUY_PACKAGE"

    if not token_confirmation:
        # fallback: reload package to get token_confirmation
        try:
            pkg = get_package(AuthInstance.api_key, tokens, option_code)
            token_confirmation = pkg.get("token_confirmation","")
            payment_for = (pkg.get("package_family") or {}).get("payment_for", payment_for)
        except Exception:
            pass

    if not token_confirmation:
        await q.message.edit_text("❌ token_confirmation tidak ditemukan. Tidak bisa lanjut pembayaran.", reply_markup=main_kb())
        return

    items: List[PaymentItem] = [{
        "item_code": option_code,
        "product_type": "PACKAGE",
        "item_price": price,
        "item_name": name,
        "tax": 0,
        "token_confirmation": token_confirmation,
    }]

    await q.message.edit_text("🔄 Memproses pembayaran...")

    try:
        if method == "pulsa":
            # no input prompt: force overwrite_amount
            res = settlement_balance(
                AuthInstance.api_key,
                tokens,
                items,
                payment_for,
                ask_overwrite=False,
                overwrite_amount=price,
            )
            # settlement_balance returns dict on error, otherwise None
            if isinstance(res, dict) and res.get("status") != "SUCCESS":
                await send_long(q.message, f"❌ Gagal bayar BALANCE.\n```json\n{json.dumps(res, indent=2)[:3000]}\n```", parse_mode="Markdown", reply_markup=main_kb())
            else:
                await q.message.reply_text("✅ Request pembayaran BALANCE terkirim. Cek paket kamu di menu 2.", reply_markup=main_kb())

        
        elif method == "decoyv2":
            # Pulsa + Decoy V2 (sesuai menu CLI opsi 5)
            decoy = DecoyInstance.get_decoy("balance")
            if not decoy:
                await q.message.reply_text("❌ Decoy config tidak ditemukan.", reply_markup=main_kb())
                return
            decoy_detail = get_package(AuthInstance.api_key, tokens, decoy["option_code"])
            if not decoy_detail:
                await q.message.reply_text("❌ Gagal load detail paket decoy.", reply_markup=main_kb())
                return

            decoy_price = int((decoy_detail.get("package_option") or {}).get("price", 0) or 0)
            decoy_name = (decoy_detail.get("package_option") or {}).get("name", "Decoy")
            decoy_code = (decoy_detail.get("package_option") or {}).get("package_option_code", decoy.get("option_code"))

            items2: List[PaymentItem] = list(items)
            items2.append({
                "item_code": decoy_code,
                "product_type": "",
                "item_price": decoy_price,
                "item_name": decoy_name,
                "tax": 0,
                "token_confirmation": decoy_detail.get("token_confirmation", ""),
            })

            overwrite_amount = price + decoy_price

            res = settlement_balance(
                AuthInstance.api_key,
                tokens,
                items2,
                "🤫",
                ask_overwrite=False,
                overwrite_amount=overwrite_amount,
                token_confirmation_idx=1
            )

            if isinstance(res, dict) and res.get("status") != "SUCCESS":
                msg = res.get("message", "Unknown error")
                # Auto adjust amount if server says total amount must be X
                if "Bizz-err.Amount.Total" in msg:
                    try:
                        valid_amount = int(msg.split("=")[1].strip())
                        res2 = settlement_balance(
                            AuthInstance.api_key,
                            tokens,
                            items2,
                            "🤫",
                            ask_overwrite=False,
                            overwrite_amount=valid_amount,
                            token_confirmation_idx=-1
                        )
                        if not (isinstance(res2, dict) and res2.get("status") != "SUCCESS"):
                            await q.message.reply_text("✅ Pulsa + Decoy V2 berhasil (adjusted). Cek paket di menu 2.", reply_markup=main_kb())
                            return
                        await send_long(q.message, f"❌ Gagal Pulsa+DecoyV2 (adjusted).\n```json\n{json.dumps(res2, indent=2)[:3000]}\n```", parse_mode="Markdown", reply_markup=main_kb())
                        return
                    except Exception:
                        pass

                await send_long(q.message, f"❌ Gagal Pulsa+DecoyV2.\n```json\n{json.dumps(res, indent=2)[:3000]}\n```", parse_mode="Markdown", reply_markup=main_kb())
                return

            await q.message.reply_text("✅ Pulsa + Decoy V2 terkirim. Cek paket kamu di menu 2.", reply_markup=main_kb())
            return
        elif method == "qris":
            qris_b64 = settlement_qris(
                AuthInstance.api_key,
                tokens,
                items,
                payment_for,
                ask_overwrite=False,
                overwrite_amount=price,
            )
            if not qris_b64:
                await q.message.reply_text("❌ Gagal membuat transaksi QRIS.", reply_markup=main_kb())
                return
            qris_url = f"https://ki-ar-kod.netlify.app/?data={qris_b64}"
            await q.message.reply_text(
                "✅ QRIS dibuat.\n\n"
                "Buka link ini untuk lihat QR:\n"
                f"{qris_url}\n\n"
                "Setelah bayar, cek paket kamu di menu 2.",
                reply_markup=main_kb()
            )
        else:
            await q.message.reply_text("❌ Metode tidak dikenal.", reply_markup=main_kb())
    except Exception as e:
        await q.message.reply_text(f"❌ Error pembayaran: {type(e).__name__}: {e}", reply_markup=main_kb())


def build_app() -> Application:
    app = Application.builder().token(TELEGRAM_TOKEN).build()
    app.add_handler(CommandHandler("start", on_start))
    app.add_handler(CommandHandler("menu", on_menu))

    app.add_handler(CallbackQueryHandler(on_click, pattern=r"^m:"))
    app.add_handler(CallbackQueryHandler(on_acc, pattern=r"^acc:"))

    app.add_handler(CallbackQueryHandler(on_pay, pattern=r"^pay:"))

    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))
    return app

def main():
    logger.info("Starting SUNSET Telegram Bot")
    build_app().run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
