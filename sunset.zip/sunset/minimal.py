import os
import shutil

dst = "minimal_app"

files = [
    ("main.py", f"{dst}/main.py"),
    (".env", f"{dst}/.env"),

    ("app/service/git.py", f"{dst}/app/service/git.py"),
    ("app/service/auth.py", f"{dst}/app/service/auth.py"),

    ("app/menus/util.py", f"{dst}/app/menus/util.py"),
    ("app/menus/account.py", f"{dst}/app/menus/account.py"),
    ("app/menus/package.py", f"{dst}/app/menus/package.py"),
    ("app/menus/purchase.py", f"{dst}/app/menus/purchase.py"),

    ("app/client/engsel.py", f"{dst}/app/client/engsel.py"),
    ("app/client/famplan.py", f"{dst}/app/client/famplan.py"),
    ("app/client/registration.py", f"{dst}/app/client/registration.py"),

    ("app/client/purchase/balance.py", f"{dst}/app/client/purchase/balance.py"),
    ("app/client/purchase/ewallet.py", f"{dst}/app/client/purchase/ewallet.py"),
    ("app/client/purchase/qris.py", f"{dst}/app/client/purchase/qris.py"),

    ("app/type_dict.py", f"{dst}/app/type_dict.py")
]

for src, dest in files:
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    if os.path.exists(src):
        shutil.copy(src, dest)
        print(f"Copied: {src}")
    else:
        print(f"NOT FOUND: {src}")

print("\nSelesai! Semua file telah disalin ke 'minimal_app'")