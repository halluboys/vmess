try:
    import banner
    banner.load("banner.png", globals())
except Exception:
    pass
